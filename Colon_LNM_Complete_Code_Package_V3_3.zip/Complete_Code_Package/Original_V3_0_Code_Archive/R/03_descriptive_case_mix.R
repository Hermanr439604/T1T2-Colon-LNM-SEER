# ============================================================
# 03. TEMPORAL SPLIT, DESCRIPTIVE DATA, CASE-MIX DRIFT
# ============================================================
seer_split <- cohort_final %>% mutate(
  cohort = factor(case_when(
    year_dx %in% development_years ~ "Development (2018-2021)",
    year_dx == final_temporal_year ~ "Temporal evaluation (2022)"),
    levels=c("Development (2018-2021)","Temporal evaluation (2022)"))
)
if (any(is.na(seer_split$cohort))) stop("Unassigned cohort records detected.")
development_data <- seer_split %>% filter(year_dx %in% development_years) %>% droplevels()
temporal_data <- seer_split %>% filter(year_dx == final_temporal_year) %>% droplevels()
if (length(intersect(development_data$patient_id, temporal_data$patient_id))) stop("Patient overlap between development and 2022 cohorts.")

cohort_summary <- seer_split %>% group_by(cohort) %>% summarise(N=n(), Events=sum(lnm_num), LNM_rate=mean(lnm_num), .groups="drop")
annual_summary <- seer_split %>% group_by(year_dx) %>% summarise(N=n(), Events=sum(lnm_num), LNM_rate=mean(lnm_num),
                                                                 Age_median=median(age), Tumor_size_median=median(tumor_size_mm),
                                                                 T2_percent=mean(t_stage=="T2"), .groups="drop")
case_mix_2022 <- case_mix_smd(development_data, temporal_data, "2018-2021", "2022")
rolling_case_mix <- bind_rows(lapply(rolling_test_years, function(y) {
  tr <- seer_split %>% filter(year_dx < y, year_dx >= min(analysis_years))
  te <- seer_split %>% filter(year_dx == y)
  if (!nrow(tr) || !nrow(te)) return(NULL)
  case_mix_smd(tr, te, paste0(min(tr$year_dx),"-",max(tr$year_dx)), as.character(y))
}))

# Availability audit for secondary variables
secondary_availability <- seer_split %>% group_by(cohort) %>% summarise(
  N=n(), PNI_known_n=sum(pni_group %in% c("Absent","Present")), PNI_known_pct=mean(pni_group %in% c("Absent","Present")),
  CEA_known_n=sum(cea_group %in% c("Negative/normal","Positive/elevated")), CEA_known_pct=mean(cea_group %in% c("Negative/normal","Positive/elevated")), .groups="drop")

save_csv(cohort_summary,"cohort_summary.csv","03_descriptive")
save_csv(annual_summary,"annual_summary.csv","03_descriptive")
save_csv(case_mix_2022,"case_mix_2018_2021_vs_2022.csv","03_descriptive")
save_csv(rolling_case_mix,"rolling_case_mix_smd.csv","03_descriptive")
save_csv(secondary_availability,"secondary_variable_availability.csv","03_descriptive")
