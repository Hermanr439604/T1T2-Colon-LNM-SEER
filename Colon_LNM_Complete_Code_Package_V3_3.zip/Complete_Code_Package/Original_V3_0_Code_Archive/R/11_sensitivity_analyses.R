# ============================================================
# 11. SENSITIVITY ANALYSES - SAME FIXED-KNOT PRIMARY SPECIFICATION
# ============================================================
fit_sensitivity <- function(dev_src,val_src,label,combine_histology=FALSE) {
  tryCatch({
    d <- prepare_model_data(dev_src,combine_histology); v <- prepare_model_data(val_src,combine_histology); v <- align_factor_levels(d,v)
    mod <- fit_lrm_safe(make_primary_formula(FALSE),d)
    ev <- evaluate_model_on_data(mod,v,label)
    cbind(data.frame(Analysis=label,Development_N=nrow(d),Development_events=sum(d$lnm_num),Validation_N=nrow(v),Validation_events=sum(v$lnm_num),Status="Success",Message=""),ev$summary[,-1,drop=FALSE])
  },error=function(e) data.frame(Analysis=label,Development_N=nrow(dev_src),Development_events=sum(dev_src$lnm_num,na.rm=TRUE),Validation_N=nrow(val_src),Validation_events=sum(val_src$lnm_num,na.rm=TRUE),Status="Failed",Message=conditionMessage(e)))
}

pre150_dev <- cohort_pre150 %>% filter(year_dx %in% development_years)
pre150_val <- cohort_pre150 %>% filter(year_dx==final_temporal_year)

n_stage_outcome <- function(data) data %>% mutate(
  n_stage_clean=str_trim(as.character(n_stage_raw)),
  lnm_num=case_when(n_stage_clean=="N0"~0L,n_stage_clean %in% c("N1a","N1b","N2a","N2b")~1L,TRUE~NA_integer_)
) %>% filter(!is.na(lnm_num)) %>% select(-n_stage_clean)

q99 <- as.numeric(quantile(cohort_final$tumor_size_mm,0.99,na.rm=TRUE))
sensitivity_results <- bind_rows(
  fit_sensitivity(development_data,temporal_data,"Primary analysis: tumor size <=150 mm"),
  fit_sensitivity(development_data%>%filter(nodes_examined>=12),temporal_data%>%filter(nodes_examined>=12),">=12 lymph nodes examined"),
  fit_sensitivity(development_data%>%filter(site_group!="Overlapping/NOS")%>%droplevels(),temporal_data%>%filter(site_group!="Overlapping/NOS")%>%droplevels(),"Exclude overlapping/NOS site"),
  fit_sensitivity(development_data,temporal_data,"Combine special histology",TRUE),
  fit_sensitivity(n_stage_outcome(development_data),n_stage_outcome(temporal_data),"N-stage-defined LNM"),
  fit_sensitivity(pre150_dev,pre150_val,"Include tumors >150 mm"),
  fit_sensitivity(development_data%>%filter(tumor_size_mm<=q99),temporal_data%>%filter(tumor_size_mm<=q99),paste0("Tumor size <=99th percentile (",round(q99,1)," mm)"))
)
save_csv(sensitivity_results,"sensitivity_analyses.csv","07_sensitivity")
