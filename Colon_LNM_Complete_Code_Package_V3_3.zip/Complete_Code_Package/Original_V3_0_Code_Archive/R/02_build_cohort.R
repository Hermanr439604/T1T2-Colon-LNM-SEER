# ============================================================
# 02. COHORT CONSTRUCTION - FROZEN V2.2 RULES
# ============================================================
extract_site_code <- function(x) str_extract(as.character(x), "^C18\\.[0-9]")

seer_work <- seer_raw %>% mutate(
  row_id = row_number(),
  year_dx = suppressWarnings(as.integer(year_dx_raw)),
  age = case_when(str_detect(age_single_raw, "^90\\+") ~ 90, TRUE ~ parse_number(age_single_raw)),
  primary_site_code = extract_site_code(primary_site_raw),
  histology_code = suppressWarnings(as.integer(histology_code_raw)),
  surgery_code = suppressWarnings(as.integer(surgery_primary_raw)),
  nodes_examined = suppressWarnings(as.integer(nodes_examined_raw)),
  nodes_positive = suppressWarnings(as.integer(nodes_positive_raw)),
  tumor_size_mm = suppressWarnings(as.integer(tumor_size_raw)),
  grade_path_n = case_when(grade_pathological_raw %in% c("1","2","3","4") ~ as.integer(grade_pathological_raw), TRUE ~ NA_integer_),
  t_stage_chr = case_when(str_starts(t_stage_raw, "T1") ~ "T1", str_starts(t_stage_raw, "T2") ~ "T2", TRUE ~ NA_character_),
  m_stage = case_when(m_stage_raw %in% c("M0", "M0(i+)") ~ "M0", TRUE ~ NA_character_)
)

flow <- tibble(step_order=0L, selection_step="Database-level SEER export", remaining_n=nrow(seer_work))
add_flow <- function(dat, order, label) {
  flow <<- bind_rows(flow, tibble(step_order=as.integer(order), selection_step=label, remaining_n=nrow(dat)))
  dat
}
eligible_sites <- c("C18.0","C18.2","C18.3","C18.4","C18.5","C18.6","C18.7","C18.8","C18.9")
eligible_histologies <- c(8140,8480,8481,8490)

c1 <- seer_work %>% filter(year_dx %in% analysis_years, primary_site_code %in% eligible_sites, t_stage_chr %in% c("T1","T2"), m_stage=="M0")
add_flow(c1,1,"2018-2022, colon primary site, T1-T2, M0")
c2 <- c1 %>% filter(!is.na(age), age>=18); add_flow(c2,2,"Age >=18 years")
c3 <- c2 %>% filter(trimws(first_malignant_primary)=="Yes"); add_flow(c3,3,"First malignant primary")
c4 <- c3 %>% filter(histology_code %in% eligible_histologies); add_flow(c4,4,"Eligible adenocarcinoma histology")
c5 <- c4 %>% filter(!is.na(surgery_code), between(surgery_code,20,90)); add_flow(c5,5,"Surgery of primary site")
c6 <- c5 %>% filter(!is.na(nodes_examined), between(nodes_examined,1,90)); add_flow(c6,6,"At least one regional node examined")
c7 <- c6 %>% filter(!is.na(nodes_positive), between(nodes_positive,0,90)); add_flow(c7,7,"Known positive regional-node count")
c8 <- c7 %>% filter(!is.na(tumor_size_mm), between(tumor_size_mm,1,989)); add_flow(c8,8,"Known tumor size")
cohort_pre150_raw <- c8 %>% filter(grade_path_n %in% 1:4); add_flow(cohort_pre150_raw,9,"Known pathological grade")
cohort_final_raw <- cohort_pre150_raw %>% filter(tumor_size_mm <= main_tumor_size_max_mm); add_flow(cohort_final_raw,10,paste0("Tumor size 1-",main_tumor_size_max_mm," mm"))

flow <- flow %>% arrange(step_order) %>% mutate(excluded_n=lag(remaining_n)-remaining_n, excluded_n=if_else(step_order==0,NA_integer_,excluded_n))

recode_analysis_variables <- function(data) {
  data %>% mutate(
    lnm_num = if_else(nodes_positive>0,1L,0L),
    lnm = factor(if_else(lnm_num==1,"Yes","No"), levels=c("No","Yes")),
    age_group4 = factor(case_when(age<50~"<50", age<=64~"50-64", age<=74~"65-74", age>=75~"75+"), levels=c("<50","50-64","65-74","75+")),
    sex = factor(trimws(sex_raw), levels=c("Female","Male")),
    race_group = factor(case_when(
      trimws(race_raw)=="White"~"White", trimws(race_raw)=="Black"~"Black",
      trimws(race_raw)=="Asian or Pacific Islander"~"Asian or Pacific Islander",
      trimws(race_raw)=="American Indian/Alaska Native"~"American Indian/Alaska Native", TRUE~"Unknown"),
      levels=c("White","Black","Asian or Pacific Islander","American Indian/Alaska Native","Unknown")),
    site_group = factor(case_when(
      primary_site_code %in% c("C18.0","C18.2","C18.3","C18.4")~"Right-sided colon",
      primary_site_code %in% c("C18.5","C18.6","C18.7")~"Left-sided colon",
      primary_site_code %in% c("C18.8","C18.9")~"Overlapping/NOS"),
      levels=c("Right-sided colon","Left-sided colon","Overlapping/NOS")),
    histology_group = factor(case_when(
      histology_code==8140~"Adenocarcinoma", histology_code %in% c(8480,8481)~"Mucinous adenocarcinoma",
      histology_code==8490~"Signet-ring cell carcinoma"),
      levels=c("Adenocarcinoma","Mucinous adenocarcinoma","Signet-ring cell carcinoma")),
    grade_group = factor(case_when(grade_path_n %in% c(1,2)~"Well/moderately differentiated", grade_path_n %in% c(3,4)~"Poorly/undifferentiated"),
                         levels=c("Well/moderately differentiated","Poorly/undifferentiated")),
    tumor_size_group = factor(case_when(tumor_size_mm<=20~"<=20 mm", tumor_size_mm<=50~"21-50 mm", tumor_size_mm>50~">50 mm"),
                              levels=c("<=20 mm","21-50 mm",">50 mm")),
    t_stage = factor(t_stage_chr, levels=c("T1","T2")),
    nodes_examined_adequacy = factor(if_else(nodes_examined>=12,">=12","<12"), levels=c("<12",">=12")),
    cea_group = factor(case_when(
      str_detect(str_to_lower(replace_na(cea_raw,"")),"negative|normal")~"Negative/normal",
      str_detect(str_to_lower(replace_na(cea_raw,"")),"positive|elevated")~"Positive/elevated",
      TRUE~"Unknown/not assessed"), levels=c("Negative/normal","Positive/elevated","Unknown/not assessed")),
    pni_group = factor(case_when(
      str_detect(str_to_lower(replace_na(pni_raw,"")),"not identified|not present")~"Absent",
      str_detect(str_to_lower(replace_na(pni_raw,"")),"identified|present")~"Present",
      TRUE~"Unknown/not assessed"), levels=c("Absent","Present","Unknown/not assessed"))
  )
}

cohort_pre150 <- recode_analysis_variables(cohort_pre150_raw)
cohort_final <- recode_analysis_variables(cohort_final_raw)

if (anyDuplicated(cohort_final$patient_id)) stop("Duplicate patient IDs in final cohort.")
if (any(cohort_final$nodes_positive > cohort_final$nodes_examined, na.rm=TRUE)) stop("Positive nodes > examined nodes detected.")
if (any(cohort_final$tumor_size_mm<1 | cohort_final$tumor_size_mm>main_tumor_size_max_mm)) stop("Tumor-size rule failed.")

save_csv(flow, "cohort_selection_flow.csv", "02_cohort")
saveRDS(cohort_final, file.path(output_root,"02_cohort","cohort_final.rds"))
saveRDS(cohort_pre150, file.path(output_root,"02_cohort","cohort_pre150_sensitivity.rds"))
