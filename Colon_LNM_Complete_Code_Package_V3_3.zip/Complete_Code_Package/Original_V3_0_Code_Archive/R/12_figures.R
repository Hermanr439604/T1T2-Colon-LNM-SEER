# ============================================================
# 12. V3.0 FIGURES
# Main emphasis: study design, temporal stability, model complexity, calibration.
# ============================================================
# Figure 1: cohort flow with final temporal split.
flow_plot_data <- flow %>% mutate(y=rev(seq_len(n())),label=paste0(selection_step,"\nN = ",scales::comma(remaining_n)))
p1 <- ggplot(flow_plot_data,aes(0,y))+
  geom_label(aes(label=label),size=3,label.size=.35,fill="white")+
  geom_segment(data=flow_plot_data%>%filter(step_order<max(step_order)),aes(x=0,xend=0,y=y-.32,yend=y-.68),arrow=grid::arrow(length=grid::unit(.10,"inches")))+
  annotate("label",x=-.55,y=.2,label=paste0("Development\n2018-2021\nN = ",comma(nrow(development_data))),size=3)+
  annotate("label",x=.55,y=.2,label=paste0("Temporal evaluation\n2022\nN = ",comma(nrow(temporal_data))),size=3)+
  xlim(-1,1)+ylim(0,max(flow_plot_data$y)+.5)+theme_void()+labs(title="Study cohort and temporal design")
save_plot(p1,"Figure_1_Cohort_and_Temporal_Design",8,12)

# Figure 2: rolling temporal transportability.
roll_ok <- rolling_temporal_performance %>% filter(Status=="Success")
p2a <- ggplot(annual_summary,aes(year_dx,LNM_rate))+geom_line()+geom_point(size=2)+scale_y_continuous(labels=percent_format())+labs(x="Diagnosis year",y="Observed LNM rate",title="A. Outcome prevalence")+theme_pub()
p2b <- ggplot(roll_ok,aes(Test_year,AUC))+geom_line()+geom_point(size=2)+geom_errorbar(aes(ymin=AUC_lower,ymax=AUC_upper),width=.08)+geom_hline(yintercept=.5,linetype=2)+labs(x="Test year",y="AUC",title="B. Rolling discrimination")+theme_pub()
p2c <- ggplot(roll_ok,aes(Test_year,Calibration_slope))+geom_line()+geom_point(size=2)+geom_hline(yintercept=1,linetype=2)+labs(x="Test year",y="Calibration slope",title="C. Rolling calibration")+theme_pub()
p2 <- p2a+p2b+p2c+plot_layout(ncol=3)
save_plot(p2,"Figure_2_Rolling_Temporal_Transportability",13,4.5)

# Figure 3: model benchmark ladder in final 2022 cohort.
bench_long <- model_benchmark_performance %>% filter(Model %in% c("M0","M1","M2","M3")) %>%
  select(Model,Label,Temporal_AUC,Temporal_Brier,Temporal_slope) %>%
  pivot_longer(cols=c(Temporal_AUC,Temporal_Brier,Temporal_slope),names_to="Metric",values_to="Value") %>%
  mutate(
    Metric=recode(Metric,Temporal_AUC="AUC",Temporal_Brier="Brier score",Temporal_slope="Calibration slope"),
    Label=factor(Label, levels=rev(unname(benchmark_model_labels[c("M0","M1","M2","M3")])) )
  )
p3 <- ggplot(bench_long,aes(Value,Label))+geom_point(size=2.5)+facet_wrap(~Metric,scales="free_x")+
  labs(x=NULL,y=NULL,title="Model-complexity benchmark in the 2022 cohort")+theme_pub()+theme(legend.position="none")
save_plot(p3,"Figure_3_Model_Benchmark_Ladder",11,6)

# Figure 4: final 2022 performance.
roc_df <- data.frame(specificity=rev(final_2022_eval$roc$specificities),sensitivity=rev(final_2022_eval$roc$sensitivities))
p4a <- ggplot(roc_df,aes(1-specificity,sensitivity))+geom_line(linewidth=1)+geom_abline(slope=1,intercept=0,linetype=2)+coord_equal()+labs(x="1 - Specificity",y="Sensitivity",title="A. Discrimination")+theme_pub()
p4b <- ggplot(final_2022_calibration_curve,aes(p,observed))+geom_ribbon(aes(ymin=lower,ymax=upper),alpha=.2)+geom_line(linewidth=1)+geom_abline(slope=1,intercept=0,linetype=2)+coord_equal()+labs(x="Predicted probability",y="Observed probability",title="B. Flexible calibration")+theme_pub()
p4c <- ggplot(final_2022_deciles,aes(group))+geom_line(aes(y=predicted,linetype="Predicted"))+geom_point(aes(y=predicted))+geom_line(aes(y=observed,linetype="Observed"))+geom_point(aes(y=observed))+scale_y_continuous(labels=percent_format())+labs(x="Predicted-risk decile",y="LNM probability",linetype=NULL,title="C. Risk stratification")+theme_pub()
p4 <- p4a+p4b+p4c+plot_layout(ncol=3)
save_plot(p4,"Figure_4_Final_2022_Performance",13,4.5)

# Supplement S1: fixed-knot RCS relative-effect curves.
dd_fig <- datadist(development_model_data[, setdiff(all.vars(formula(primary_model)), "lnm_num"), drop=FALSE]); assign("dd_fig",dd_fig,envir=.GlobalEnv); old <- options(datadist="dd_fig")
age_pred <- as.data.frame(Predict(primary_model,age,ref.zero=TRUE,fun=exp,conf.int=.95))
size_pred <- as.data.frame(Predict(primary_model,tumor_size_mm,ref.zero=TRUE,fun=exp,conf.int=.95))
sp1 <- ggplot(age_pred,aes(age,yhat))+geom_ribbon(aes(ymin=lower,ymax=upper),alpha=.2)+geom_line()+geom_hline(yintercept=1,linetype=2)+labs(x="Age, years",y="Adjusted odds ratio",title="Age")+theme_pub()
sp2 <- ggplot(size_pred,aes(tumor_size_mm,yhat))+geom_ribbon(aes(ymin=lower,ymax=upper),alpha=.2)+geom_line()+geom_hline(yintercept=1,linetype=2)+labs(x="Tumor size, mm",y="Adjusted odds ratio",title="Tumor size")+theme_pub()
save_plot(sp1+sp2,"Supplementary_Figure_S1_RCS_Relative_Effects",12,5,subdir="09_figures_supplement")
options(old); if (exists("dd_fig",envir=.GlobalEnv)) rm("dd_fig",envir=.GlobalEnv)

# Supplement S2: sensitivity AUC.
sens_ok <- sensitivity_results %>% filter(Status=="Success")
sp3 <- ggplot(sens_ok,aes(reorder(Analysis,AUC),AUC))+geom_point()+geom_errorbar(aes(ymin=AUC_lower,ymax=AUC_upper),width=.15)+coord_flip()+labs(x=NULL,y="2022 AUC",title="Sensitivity analyses")+theme_pub()
save_plot(sp3,"Supplementary_Figure_S2_Sensitivity_AUC",8,5,subdir="09_figures_supplement")

# Supplement S3: bootstrap calibration.
cal_df <- as.data.frame(bootstrap_calibration)
if (all(c("predy","calibrated.corrected") %in% names(cal_df))) {
  sp4 <- ggplot(cal_df,aes(predy,calibrated.corrected))+geom_line()+geom_abline(slope=1,intercept=0,linetype=2)+coord_equal()+labs(x="Predicted probability",y="Bootstrap-corrected observed probability",title="Internal bootstrap calibration")+theme_pub()
  save_plot(sp4,"Supplementary_Figure_S3_Bootstrap_Calibration",6,6,subdir="09_figures_supplement")
}

# Supplement S4: descriptive DCA, deliberately not a main figure.
if (run_dca) {
  dca_thresholds <- seq(.05,.40,by=.01); y <- final_2022_eval$outcome; p <- final_2022_eval$probability; n <- length(y); prev <- mean(y)
  dca <- bind_rows(lapply(dca_thresholds,function(t){
    pred <- p>=t; tp<-sum(pred & y==1); fp<-sum(pred & y==0)
    data.frame(Threshold=t,Model=tp/n-(fp/n)*(t/(1-t)),Treat_all=prev-(1-prev)*(t/(1-t)),Treat_none=0)
  })) %>% pivot_longer(c(Model,Treat_all,Treat_none),names_to="Strategy",values_to="Net_benefit")
  sp5 <- ggplot(dca,aes(Threshold,Net_benefit,linetype=Strategy))+geom_line()+labs(x="Threshold probability",y="Net benefit",title="Exploratory decision-curve analysis")+theme_pub()
  save_plot(sp5,"Supplementary_Figure_S4_Exploratory_DCA",7,5,subdir="09_figures_supplement")
  save_csv(dca,"exploratory_DCA_data.csv","06_secondary")
}
