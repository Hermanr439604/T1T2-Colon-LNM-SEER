# ============================================================
# 00. UTILITIES, PACKAGES, PATHS, COMMON FUNCTIONS
# ============================================================
required_packages <- c(
  "readr", "dplyr", "tidyr", "stringr", "forcats", "broom",
  "rms", "pROC", "ggplot2", "patchwork", "openxlsx", "scales", "digest"
)
missing_packages <- required_packages[!required_packages %in% rownames(installed.packages())]
if (length(missing_packages) > 0) install.packages(missing_packages, dependencies = TRUE)

suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tidyr); library(stringr)
  library(forcats); library(broom); library(rms); library(pROC)
  library(ggplot2); library(patchwork); library(openxlsx); library(scales)
  library(digest)
})

output_root <- file.path(project_dir, "outputs", analysis_version)
output_dirs <- c(
  "01_audit", "02_cohort", "03_descriptive", "04_models",
  "05_validation", "06_secondary", "07_sensitivity",
  "08_figures_main", "09_figures_supplement", "10_tables", "11_reproducibility"
)
dir.create(output_root, recursive = TRUE, showWarnings = FALSE)
for (d in output_dirs) dir.create(file.path(output_root, d), recursive = TRUE, showWarnings = FALSE)

raw_csv_path <- file.path(project_dir, "data", raw_csv_name)
if (!file.exists(raw_csv_path)) {
  stop("Raw SEER CSV not found: ", raw_csv_path,
       "\nPlace the original V2.2 raw CSV in the data/ folder without renaming it, or edit raw_csv_name in config.R.")
}

log_file <- file.path(output_root, "11_reproducibility", "V3_0_run_log.txt")
cat("V3.0 run started: ", format(Sys.time()), "\n", file = log_file)

save_csv <- function(x, name, subdir = "10_tables") {
  readr::write_csv(x, file.path(output_root, subdir, name), na = "")
}

save_rds <- function(x, name, subdir = "04_models") {
  saveRDS(x, file.path(output_root, subdir, name))
}

save_plot <- function(p, name, width = 8, height = 6, dpi = 600, subdir = "08_figures_main") {
  stub <- file.path(output_root, subdir, name)
  ggsave(paste0(stub, ".pdf"), p, width = width, height = height, bg = "white")
  ggsave(paste0(stub, ".png"), p, width = width, height = height, dpi = dpi, bg = "white")
}

theme_pub <- function(base_size = 11) {
  theme_classic(base_size = base_size) +
    theme(
      plot.title = element_text(face = "bold"),
      axis.title = element_text(face = "bold"),
      legend.position = "bottom",
      strip.background = element_blank(),
      strip.text = element_text(face = "bold")
    )
}

make_primary_formula <- function(include_race = FALSE, include_pni = FALSE, include_cea = FALSE) {
  age_txt <- paste(age_knots, collapse = ",")
  size_txt <- paste(tumor_size_knots, collapse = ",")
  terms <- c(
    sprintf("rcs(age, c(%s))", age_txt),
    if (include_race) "race_model",
    "site_model", "histology_model", "grade_model",
    sprintf("rcs(tumor_size_mm, c(%s))", size_txt),
    "t_stage",
    if (include_pni) "pni_model",
    if (include_cea) "cea_model"
  )
  as.formula(paste("lnm_num ~", paste(terms, collapse = " + ")))
}

make_linear_formula <- function() {
  lnm_num ~ age_10 + site_model + histology_model + grade_model + tumor_size_10 + t_stage
}

make_categorical_formula <- function() {
  lnm_num ~ age_group4 + site_model + histology_model + grade_model + tumor_size_group + t_stage
}

get_probability <- function(model, new_data) {
  lp <- predict(model, newdata = as.data.frame(new_data), type = "lp")
  as.numeric(plogis(lp))
}

calibration_metrics <- function(outcome, probability) {
  ok <- is.finite(outcome) & is.finite(probability)
  y <- outcome[ok]
  p <- pmin(pmax(probability[ok], 1e-6), 1 - 1e-6)
  lp <- qlogis(p)
  if (length(unique(y)) < 2) {
    return(data.frame(Brier = NA_real_, Scaled_Brier = NA_real_,
                      Calibration_intercept = NA_real_, Calibration_slope = NA_real_,
                      Eavg = NA_real_, Emax = NA_real_))
  }
  intercept_fit <- glm(y ~ offset(lp), family = binomial())
  slope_fit <- glm(y ~ lp, family = binomial())
  brier <- mean((y - p)^2)
  null_brier <- mean(y) * (1 - mean(y))
  scaled_brier <- ifelse(null_brier > 0, 1 - brier / null_brier, NA_real_)
  flexible_fit <- try(glm(y ~ splines::ns(lp, df = 3), family = binomial()), silent = TRUE)
  if (inherits(flexible_fit, "try-error")) {
    eavg <- emax <- NA_real_
  } else {
    pcal <- as.numeric(predict(flexible_fit, type = "response"))
    e <- abs(pcal - p)
    eavg <- mean(e, na.rm = TRUE); emax <- max(e, na.rm = TRUE)
  }
  data.frame(
    Brier = brier,
    Scaled_Brier = scaled_brier,
    Calibration_intercept = unname(coef(intercept_fit)[1]),
    Calibration_slope = unname(coef(slope_fit)[2]),
    Eavg = eavg,
    Emax = emax
  )
}

performance_from_predictions <- function(outcome, probability, label = "", with_boot_ci = FALSE) {
  ok <- is.finite(outcome) & is.finite(probability)
  y <- outcome[ok]; p <- probability[ok]
  if (length(unique(y)) < 2) stop("Performance evaluation requires both outcome classes.")
  roc_obj <- pROC::roc(y, p, quiet = TRUE, direction = "<")
  auc_ci <- as.numeric(pROC::ci.auc(roc_obj))
  cal <- calibration_metrics(y, p)
  out <- data.frame(
    Analysis = label,
    N = length(y), Events = sum(y == 1), LNM_rate = mean(y),
    AUC = as.numeric(pROC::auc(roc_obj)), AUC_lower = auc_ci[1], AUC_upper = auc_ci[3],
    cal, stringsAsFactors = FALSE
  )
  if (with_boot_ci) {
    set.seed(random_seed + length(y))
    B <- performance_ci_boot_repetitions
    boot_mat <- matrix(NA_real_, nrow = B, ncol = 5,
                       dimnames = list(NULL, c("Brier", "Intercept", "Slope", "Eavg", "Emax")))
    for (b in seq_len(B)) {
      idx <- sample.int(length(y), replace = TRUE)
      if (length(unique(y[idx])) < 2) next
      m <- calibration_metrics(y[idx], p[idx])
      boot_mat[b, ] <- c(m$Brier, m$Calibration_intercept, m$Calibration_slope, m$Eavg, m$Emax)
    }
    q <- function(z) quantile(z, c(.025, .975), na.rm = TRUE, names = FALSE)
    ci_b <- q(boot_mat[,"Brier"]); ci_i <- q(boot_mat[,"Intercept"]); ci_s <- q(boot_mat[,"Slope"])
    out$Brier_lower <- ci_b[1]; out$Brier_upper <- ci_b[2]
    out$Calibration_intercept_lower <- ci_i[1]; out$Calibration_intercept_upper <- ci_i[2]
    out$Calibration_slope_lower <- ci_s[1]; out$Calibration_slope_upper <- ci_s[2]
  }
  list(summary = out, roc = roc_obj, probability = p, outcome = y)
}

evaluate_model_on_data <- function(model, data, label = "", with_boot_ci = FALSE) {
  prob <- get_probability(model, data)
  performance_from_predictions(data$lnm_num, prob, label, with_boot_ci)
}

fit_lrm_safe <- function(formula, data, x = TRUE, y = TRUE) {
  # Restrict datadist to predictors actually used by this model. This avoids
  # failures from unrelated raw/optional variables with all-missing values.
  dd_vars <- setdiff(all.vars(formula), "lnm_num")
  dd <- rms::datadist(data[, dd_vars, drop = FALSE])
  old <- options(datadist = "dd_temp_v3")
  assign("dd_temp_v3", dd, envir = .GlobalEnv)
  on.exit({options(old); if (exists("dd_temp_v3", envir = .GlobalEnv)) rm("dd_temp_v3", envir = .GlobalEnv)}, add = TRUE)
  rms::lrm(formula, data = data, x = x, y = y)
}

compare_auc_delong <- function(eval_a, eval_b) {
  pROC::roc.test(eval_a$roc, eval_b$roc, paired = TRUE, method = "delong")$p.value
}

calibration_curve <- function(outcome, probability, grid_n = 120) {
  d <- data.frame(y = outcome, p = pmin(pmax(probability, 1e-6), 1 - 1e-6))
  d$lp <- qlogis(d$p)
  fit <- glm(y ~ splines::ns(lp, df = 3), data = d, family = binomial())
  grid <- data.frame(p = seq(max(0.001, min(d$p)), min(0.999, max(d$p)), length.out = grid_n))
  grid$lp <- qlogis(grid$p)
  pr <- predict(fit, newdata = grid, type = "link", se.fit = TRUE)
  grid$observed <- plogis(pr$fit)
  grid$lower <- plogis(pr$fit - 1.96 * pr$se.fit)
  grid$upper <- plogis(pr$fit + 1.96 * pr$se.fit)
  grid
}

risk_deciles <- function(outcome, probability, groups = 10) {
  tibble(y = outcome, p = probability) %>%
    mutate(group = ntile(p, groups)) %>%
    group_by(group) %>%
    summarise(n = n(), predicted = mean(p), observed = mean(y), events = sum(y), .groups = "drop")
}

smd_numeric <- function(x1, x2) {
  den <- sqrt((var(x1, na.rm=TRUE) + var(x2, na.rm=TRUE))/2)
  if (!is.finite(den) || den == 0) return(NA_real_)
  (mean(x2, na.rm=TRUE) - mean(x1, na.rm=TRUE))/den
}

smd_binary <- function(x1, x2) {
  p1 <- mean(x1, na.rm=TRUE); p2 <- mean(x2, na.rm=TRUE)
  den <- sqrt((p1*(1-p1) + p2*(1-p2))/2)
  if (!is.finite(den) || den == 0) return(NA_real_)
  (p2-p1)/den
}

case_mix_smd <- function(train, test, train_label, test_label) {
  out <- list()
  for (v in c("age", "tumor_size_mm", "nodes_examined")) {
    out[[length(out)+1]] <- data.frame(Variable=v, Level="", SMD=smd_numeric(train[[v]], test[[v]]))
  }
  for (v in c("sex", "site_group", "histology_group", "grade_group", "t_stage")) {
    levs <- union(unique(as.character(train[[v]])), unique(as.character(test[[v]])))
    levs <- levs[!is.na(levs)]
    for (lv in levs) {
      out[[length(out)+1]] <- data.frame(
        Variable=v, Level=lv,
        SMD=smd_binary(as.character(train[[v]])==lv, as.character(test[[v]])==lv)
      )
    }
  }
  bind_rows(out) %>% mutate(Train=train_label, Test=test_label, Abs_SMD=abs(SMD), Flag_gt_0_10=Abs_SMD>0.10)
}

assert_equal <- function(actual, expected, label) {
  if (!identical(as.integer(actual), as.integer(expected))) {
    msg <- paste0("Freeze check failed for ", label, ": actual=", actual, ", expected=", expected)
    if (strict_freeze_checks) stop(msg) else warning(msg)
  }
}
