# ============================================================
# 06. INTERNAL VALIDATION OF PRIMARY M3 MODEL
# ============================================================
set.seed(random_seed)
dd_internal <- datadist(development_model_data[, setdiff(all.vars(formula(primary_model)), "lnm_num"), drop=FALSE]); assign("dd_internal",dd_internal,envir=.GlobalEnv); old_dd <- options(datadist="dd_internal")
internal_validate <- rms::validate(primary_model, method="boot", B=bootstrap_repetitions)
internal_validate_matrix <- as.matrix(unclass(internal_validate))
internal_validation_raw <- data.frame(Index=rownames(internal_validate_matrix), internal_validate_matrix, row.names=NULL, check.names=FALSE)

# Translate corrected Dxy to corrected C-statistic when available.
internal_validation_summary <- data.frame(Metric=character(), Value=numeric())
if ("Dxy" %in% rownames(internal_validate_matrix) && "index.corrected" %in% colnames(internal_validate_matrix)) {
  internal_validation_summary <- bind_rows(internal_validation_summary,
    data.frame(Metric="Optimism-corrected C-statistic", Value=(internal_validate_matrix["Dxy","index.corrected"]+1)/2))
}
for (metric in c("R2","Intercept","Slope","Emax","D")) {
  if (metric %in% rownames(internal_validate_matrix) && "index.corrected" %in% colnames(internal_validate_matrix))
    internal_validation_summary <- bind_rows(internal_validation_summary, data.frame(Metric=paste0("Corrected ",metric),Value=internal_validate_matrix[metric,"index.corrected"]))
}
# Bootstrap calibration object for supplementary figure.
set.seed(random_seed)
bootstrap_calibration <- rms::calibrate(primary_model, method="boot", B=bootstrap_repetitions)
options(old_dd); if (exists("dd_internal",envir=.GlobalEnv)) rm("dd_internal",envir=.GlobalEnv)

save_csv(internal_validation_raw,"internal_bootstrap_validate_raw.csv","05_validation")
save_csv(internal_validation_summary,"internal_bootstrap_summary.csv","05_validation")
save_rds(bootstrap_calibration,"bootstrap_calibration_object.rds","05_validation")
