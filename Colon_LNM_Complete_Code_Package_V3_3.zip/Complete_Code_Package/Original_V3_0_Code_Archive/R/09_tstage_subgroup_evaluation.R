# ============================================================
# 09. T1 / T2 SUBGROUP PERFORMANCE IN 2022 - NO REFITTING
# ============================================================
tstage_subgroup_results <- list()
for (stage in c("T1","T2")) {
  idx <- as.character(temporal_model_data$t_stage)==stage
  ev <- performance_from_predictions(temporal_model_data$lnm_num[idx], final_2022_eval$probability[idx],
                                     paste0("2022 subgroup: ",stage), with_boot_ci=TRUE)
  tstage_subgroup_results[[stage]] <- ev$summary
}
tstage_subgroup_performance <- bind_rows(tstage_subgroup_results)
save_csv(tstage_subgroup_performance,"T1_T2_subgroup_2022_performance.csv","05_validation")
