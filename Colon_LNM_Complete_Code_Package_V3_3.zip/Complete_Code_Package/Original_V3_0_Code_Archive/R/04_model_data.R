# ============================================================
# 04. MODEL-DATA PREPARATION AND FROZEN FACTOR DEFINITIONS
# ============================================================
prepare_model_data <- function(data, combine_special_histology = FALSE) {
  x <- as.data.frame(data) %>% mutate(
    age_10 = age/10,
    tumor_size_10 = tumor_size_mm/10,
    sex = factor(as.character(sex), levels=c("Female","Male")),
    race_model = factor(as.character(race_group), levels=c("White","Black","Asian or Pacific Islander","American Indian/Alaska Native","Unknown")),
    site_model = factor(as.character(site_group), levels=c("Right-sided colon","Left-sided colon","Overlapping/NOS")),
    grade_model = factor(as.character(grade_group), levels=c("Well/moderately differentiated","Poorly/undifferentiated")),
    t_stage = factor(as.character(t_stage), levels=c("T1","T2")),
    age_group4 = factor(as.character(age_group4), levels=c("<50","50-64","65-74","75+")),
    tumor_size_group = factor(as.character(tumor_size_group), levels=c("<=20 mm","21-50 mm",">50 mm")),
    pni_model = factor(ifelse(as.character(pni_group) %in% c("Absent","Present"), as.character(pni_group), NA_character_), levels=c("Absent","Present")),
    cea_model = factor(ifelse(as.character(cea_group) %in% c("Negative/normal","Positive/elevated"), as.character(cea_group), NA_character_), levels=c("Negative/normal","Positive/elevated"))
  )
  if (combine_special_histology) {
    x$histology_model <- factor(ifelse(as.character(x$histology_group)=="Adenocarcinoma","Adenocarcinoma","Special histology"),
                                levels=c("Adenocarcinoma","Special histology"))
  } else {
    x$histology_model <- factor(as.character(x$histology_group), levels=c("Adenocarcinoma","Mucinous adenocarcinoma","Signet-ring cell carcinoma"))
  }
  x
}

align_factor_levels <- function(train, test) {
  vars <- c("sex","race_model","site_model","histology_model","grade_model","t_stage","age_group4","tumor_size_group","pni_model","cea_model")
  for (v in vars) if (v %in% names(train) && v %in% names(test)) test[[v]] <- factor(as.character(test[[v]]), levels=levels(train[[v]]))
  test
}

development_model_data <- prepare_model_data(development_data)
temporal_model_data <- prepare_model_data(temporal_data)
temporal_model_data <- align_factor_levels(development_model_data, temporal_model_data)

primary_complete_vars <- c("lnm_num","age","site_model","histology_model","grade_model","tumor_size_mm","t_stage")
if (anyNA(development_model_data[primary_complete_vars]) || anyNA(temporal_model_data[primary_complete_vars])) stop("Missing primary-model data after frozen cohort construction.")

knots_table <- bind_rows(
  data.frame(Variable="age", Knot_number=seq_along(age_knots), Knot_value=age_knots),
  data.frame(Variable="tumor_size_mm", Knot_number=seq_along(tumor_size_knots), Knot_value=tumor_size_knots)
)
save_csv(knots_table,"V3_0_FIXED_RCS_KNOTS.csv","04_models")
