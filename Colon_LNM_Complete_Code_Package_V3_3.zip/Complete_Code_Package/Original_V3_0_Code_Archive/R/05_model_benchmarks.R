# ============================================================
# 05. MODEL BENCHMARK LADDER
# Primary model is M3 by protocol; 2022 comparisons are benchmarks, not model selection.
# ============================================================
benchmark_formulas <- list(
  M0 = lnm_num ~ t_stage,
  M1 = make_categorical_formula(),
  M2 = make_linear_formula(),
  M3 = make_primary_formula(include_race=FALSE),
  M4 = make_primary_formula(include_race=TRUE)
)
benchmark_models <- list()
benchmark_dev <- list(); benchmark_2022 <- list()
for (nm in names(benchmark_formulas)) {
  mod <- fit_lrm_safe(benchmark_formulas[[nm]], development_model_data)
  benchmark_models[[nm]] <- mod
  benchmark_dev[[nm]] <- evaluate_model_on_data(mod, development_model_data, paste0(nm,": ",benchmark_model_labels[[nm]]))
  benchmark_2022[[nm]] <- evaluate_model_on_data(mod, temporal_model_data, paste0(nm,": ",benchmark_model_labels[[nm]]))
  save_rds(mod, paste0(nm,"_model.rds"))
}
model_benchmark_performance <- bind_rows(lapply(names(benchmark_models), function(nm) {
  d <- benchmark_dev[[nm]]$summary; v <- benchmark_2022[[nm]]$summary
  data.frame(Model=nm, Label=benchmark_model_labels[[nm]],
             Development_AUC=d$AUC, Development_Brier=d$Brier, Development_slope=d$Calibration_slope,
             Temporal_AUC=v$AUC, Temporal_AUC_lower=v$AUC_lower, Temporal_AUC_upper=v$AUC_upper,
             Temporal_Brier=v$Brier, Temporal_scaled_Brier=v$Scaled_Brier,
             Temporal_intercept=v$Calibration_intercept, Temporal_slope=v$Calibration_slope,
             Temporal_Eavg=v$Eavg, Temporal_Emax=v$Emax)
}))

primary_model <- benchmark_models$M3
race_model <- benchmark_models$M4
primary_dev_eval <- benchmark_dev$M3
primary_2022_eval_initial <- benchmark_2022$M3

# Pairwise discrimination comparisons against M3 in 2022 (descriptive benchmark only).
benchmark_delong <- bind_rows(lapply(c("M0","M1","M2","M4"), function(nm) {
  data.frame(Comparison=paste(nm,"vs M3"), P_value=compare_auc_delong(benchmark_2022[[nm]],benchmark_2022$M3))
}))

# Nonlinearity tests from the prespecified M3 model.
an <- as.matrix(anova(primary_model)); rn <- trimws(rownames(an)); pcol <- if ("P" %in% colnames(an)) "P" else grep("^P$|Pr",colnames(an),value=TRUE)[1]
get_anova_p <- function(term, nonlinear=FALSE) {
  i <- which(rn==term)[1]; if (is.na(i)) return(NA_real_)
  if (nonlinear) {i<-i+1; if (i>nrow(an) || trimws(rownames(an)[i])!="Nonlinear") return(NA_real_)}
  as.numeric(an[i,pcol])
}
nonlinearity_results <- data.frame(
  Variable=c("Age","Age","Tumor size","Tumor size"), Test=c("Overall","Nonlinear","Overall","Nonlinear"),
  P_value=c(get_anova_p("age"),get_anova_p("age",TRUE),get_anova_p("tumor_size_mm"),get_anova_p("tumor_size_mm",TRUE))
)

save_csv(model_benchmark_performance,"model_benchmark_ladder.csv","04_models")
save_csv(benchmark_delong,"model_benchmark_delong_vs_M3.csv","04_models")
save_csv(nonlinearity_results,"primary_model_nonlinearity.csv","04_models")
