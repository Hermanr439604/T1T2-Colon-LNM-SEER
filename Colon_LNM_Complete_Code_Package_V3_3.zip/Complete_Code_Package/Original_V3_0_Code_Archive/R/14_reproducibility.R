# ============================================================
# 14. REPRODUCIBILITY MANIFEST
# ============================================================
capture.output(sessionInfo(),file=file.path(output_root,"11_reproducibility","R_sessionInfo_V3_0.txt"))

# Hash all generated result files except the manifest itself.
all_files <- list.files(output_root,recursive=TRUE,full.names=TRUE)
all_files <- all_files[!grepl("SHA256_manifest",all_files)]
root_norm <- normalizePath(output_root, winslash="/", mustWork=TRUE)
file_norm <- normalizePath(all_files, winslash="/", mustWork=TRUE)
relative_paths <- substring(file_norm, nchar(root_norm)+2)
manifest <- data.frame(
  relative_path=relative_paths,
  bytes=file.info(all_files)$size,
  SHA256=vapply(all_files,digest::digest,character(1),algo="sha256",file=TRUE),
  stringsAsFactors=FALSE
)
readr::write_csv(manifest,file.path(output_root,"11_reproducibility","SHA256_manifest_V3_0.csv"))
cat("V3.0 run completed: ",format(Sys.time()),"\n",file=log_file,append=TRUE)
