# ============================================================
# 01. IMPORT AND RAW-DATA AUDIT
# ============================================================
seer_raw_original <- readr::read_csv(
  raw_csv_path, col_types = cols(.default = col_character()),
  na = c("", "NA"), trim_ws = TRUE, show_col_types = FALSE, name_repair = "unique"
)

rename_map <- c(
  "Patient ID" = "patient_id",
  "Age recode with <1 year olds and 90+" = "age_group_5y_raw",
  "Age recode with single ages and 90+" = "age_single_raw",
  "Sequence number" = "sequence_number",
  "First malignant primary indicator" = "first_malignant_primary",
  "Year of diagnosis" = "year_dx_raw",
  "Sex" = "sex_raw",
  "Race recode (W, B, AI, API)" = "race_raw",
  "Origin recode NHIA (Hispanic, Non-Hisp)" = "hispanic_origin_raw",
  "Race and origin recode (NHW, NHB, NHAIAN, NHAPI, Hispanic)" = "race_origin_raw",
  "Marital status at diagnosis" = "marital_status_raw",
  "Primary Site - labeled" = "primary_site_raw",
  "Site recode ICD-O-3/WHO 2008" = "site_recode_raw",
  "Histologic Type ICD-O-3" = "histology_code_raw",
  "Grade Clinical (2018+)" = "grade_clinical_raw",
  "Grade Pathological (2018+)" = "grade_pathological_raw",
  "Tumor Size Summary (2016+)" = "tumor_size_raw",
  "Derived EOD 2018 T Recode (2018+)" = "t_stage_raw",
  "Derived EOD 2018 N Recode (2018+)" = "n_stage_raw",
  "Derived EOD 2018 M Recode (2018+)" = "m_stage_raw",
  "Derived EOD 2018 Stage Group Recode (2018+)" = "stage_group_raw",
  "Regional nodes examined (1988+)" = "nodes_examined_raw",
  "Regional nodes positive (1988+)" = "nodes_positive_raw",
  "RX Summ--Surg Prim Site (1998+)" = "surgery_primary_raw",
  "Reason no cancer-directed surgery" = "reason_no_surgery_raw",
  "Radiation recode" = "radiation_raw",
  "Chemotherapy recode (yes, no/unk)" = "chemotherapy_raw",
  "CEA Pretreatment Interpretation Recode (2010+)" = "cea_raw",
  "CA-125 Pretreatment Interpretation Recode (2010+)" = "ca125_raw",
  "Tumor Deposits Recode (2010+)" = "tumor_deposits_raw",
  "Perineural Invasion Recode (2010+)" = "pni_raw",
  "Survival months" = "survival_months_raw",
  "Vital status recode (study cutoff used)" = "vital_status_raw",
  "SEER cause-specific death classification" = "cause_specific_death_raw"
)
seer_raw <- seer_raw_original
for (old in names(rename_map)) if (old %in% names(seer_raw)) names(seer_raw)[names(seer_raw)==old] <- rename_map[[old]]

required_raw_variables <- c(
  "patient_id", "age_single_raw", "first_malignant_primary", "year_dx_raw",
  "sex_raw", "race_raw", "marital_status_raw", "primary_site_raw",
  "histology_code_raw", "grade_pathological_raw", "tumor_size_raw",
  "t_stage_raw", "n_stage_raw", "m_stage_raw", "nodes_examined_raw",
  "nodes_positive_raw", "surgery_primary_raw", "pni_raw"
)
missing_required <- setdiff(required_raw_variables, names(seer_raw))
if (length(missing_required)) stop("Missing required SEER variables: ", paste(missing_required, collapse=", "))

# Dictionary is restricted to fields physically present in the source export.
analysis_names_from_original <- names(seer_raw)
variable_dictionary <- data.frame(
  order=seq_along(names(seer_raw_original)), original=names(seer_raw_original),
  analysis=analysis_names_from_original, stringsAsFactors=FALSE
)

# Optional fields are created as NA so downstream code remains deterministic.
for (v in c("cea_raw", "ca125_raw", "tumor_deposits_raw")) if (!v %in% names(seer_raw)) seer_raw[[v]] <- NA_character_
raw_audit <- lapply(names(seer_raw), function(v) {
  x <- as.character(seer_raw[[v]])
  data.frame(variable=v, total_n=length(x), missing_n=sum(is.na(x)),
             missing_percent=100*mean(is.na(x)), unique_n=length(unique(na.omit(x))),
             examples=paste(head(unique(na.omit(x)), 15), collapse=" | "))
}) %>% bind_rows()

openxlsx::write.xlsx(
  list(Variable_dictionary=variable_dictionary, Raw_audit=raw_audit),
  file.path(output_root, "01_audit", "01_raw_data_audit.xlsx"), overwrite=TRUE
)
saveRDS(seer_raw, file.path(output_root, "01_audit", "raw_renamed.rds"))
