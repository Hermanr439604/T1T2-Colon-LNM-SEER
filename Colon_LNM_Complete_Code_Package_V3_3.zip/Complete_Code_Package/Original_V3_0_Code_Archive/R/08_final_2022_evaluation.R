# ============================================================
# 08. FINAL PROTOCOL-LOCKED 2022 EVALUATION
# NOTE: historically 2022 results were seen in V2.2; V3.0 does not use 2022
# for coefficient estimation, knot selection, predictor selection, or recalibration.
# ============================================================
final_2022_eval <- evaluate_model_on_data(primary_model, temporal_model_data, "Primary M3: 2018-2021 -> 2022", with_boot_ci=TRUE)
final_2022_performance <- final_2022_eval$summary
final_2022_predictions <- data.frame(patient_id=temporal_data$patient_id, year_dx=temporal_data$year_dx,
                                     t_stage=temporal_data$t_stage, lnm_num=temporal_model_data$lnm_num,
                                     predicted=final_2022_eval$probability)
final_2022_calibration_curve <- calibration_curve(final_2022_eval$outcome,final_2022_eval$probability)
final_2022_deciles <- risk_deciles(final_2022_eval$outcome,final_2022_eval$probability)

save_csv(final_2022_performance,"final_2022_performance.csv","05_validation")
save_csv(final_2022_predictions,"final_2022_predictions.csv","05_validation")
save_csv(final_2022_calibration_curve,"final_2022_calibration_curve.csv","05_validation")
save_csv(final_2022_deciles,"final_2022_risk_deciles.csv","05_validation")
