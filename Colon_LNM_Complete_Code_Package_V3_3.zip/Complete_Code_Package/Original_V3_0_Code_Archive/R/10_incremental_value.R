# ============================================================
# 10. INCREMENTAL-VALUE EXPERIMENTS: RACE, PNI, OPTIONAL CEA
# ============================================================
# Race: full-cohort M3 vs M4, 2022 benchmark.
race_base <- benchmark_2022$M3; race_plus <- benchmark_2022$M4
race_incremental <- data.frame(
  Base_AUC=race_base$summary$AUC, Race_AUC=race_plus$summary$AUC,
  Delta_AUC=race_plus$summary$AUC-race_base$summary$AUC,
  DeLong_P=compare_auc_delong(race_base,race_plus),
  Base_Brier=race_base$summary$Brier, Race_Brier=race_plus$summary$Brier,
  Delta_Brier=race_plus$summary$Brier-race_base$summary$Brier,
  Base_slope=race_base$summary$Calibration_slope, Race_slope=race_plus$summary$Calibration_slope
)

pni_incremental <- data.frame(Status="Not run")
pni_association <- data.frame(Status="Not run")
if (run_pni_analysis) {
  pni_dev_src <- development_data %>% filter(pni_group %in% c("Absent","Present"))
  pni_val_src <- temporal_data %>% filter(pni_group %in% c("Absent","Present"))
  pni_dev <- prepare_model_data(pni_dev_src); pni_val <- prepare_model_data(pni_val_src); pni_val <- align_factor_levels(pni_dev,pni_val)
  pni_base_model <- fit_lrm_safe(make_primary_formula(FALSE,FALSE),pni_dev)
  pni_plus_model <- fit_lrm_safe(make_primary_formula(FALSE,TRUE),pni_dev)
  pni_base_eval <- evaluate_model_on_data(pni_base_model,pni_val,"PNI-known base")
  pni_plus_eval <- evaluate_model_on_data(pni_plus_model,pni_val,"PNI-known base + PNI")
  pni_incremental <- data.frame(
    Development_N=nrow(pni_dev),Validation_N=nrow(pni_val),Validation_events=sum(pni_val$lnm_num),
    Base_AUC=pni_base_eval$summary$AUC, PNI_AUC=pni_plus_eval$summary$AUC,
    Delta_AUC=pni_plus_eval$summary$AUC-pni_base_eval$summary$AUC,
    DeLong_P=compare_auc_delong(pni_base_eval,pni_plus_eval),
    Base_Brier=pni_base_eval$summary$Brier, PNI_Brier=pni_plus_eval$summary$Brier,
    Delta_Brier=pni_plus_eval$summary$Brier-pni_base_eval$summary$Brier,
    Base_slope=pni_base_eval$summary$Calibration_slope, PNI_slope=pni_plus_eval$summary$Calibration_slope,
    Status="Success"
  )
  # Association model uses flexible continuous terms but is explicitly secondary.
  pni_all <- bind_rows(development_data,temporal_data) %>% filter(pni_group %in% c("Absent","Present")) %>%
    mutate(pni_binary=factor(as.character(pni_group),levels=c("Absent","Present")))
  assoc <- glm(lnm_num ~ splines::ns(age,df=3)+race_group+site_group+histology_group+grade_group+
                 splines::ns(tumor_size_mm,df=3)+t_stage+pni_binary, data=pni_all, family=binomial())
  pni_association <- broom::tidy(assoc,exponentiate=TRUE,conf.int=TRUE) %>% filter(term=="pni_binaryPresent") %>%
    transmute(Contrast="PNI present vs absent",Adjusted_OR=estimate,CI_lower=conf.low,CI_upper=conf.high,P_value=p.value,Status="Success")
  save_rds(pni_base_model,"PNI_known_base_model.rds","06_secondary")
  save_rds(pni_plus_model,"PNI_known_plus_PNI_model.rds","06_secondary")
}

cea_incremental <- data.frame(Status="Not run")
if (run_optional_cea_analysis) {
  cea_dev_src <- development_data %>% filter(cea_group %in% c("Negative/normal","Positive/elevated"))
  cea_val_src <- temporal_data %>% filter(cea_group %in% c("Negative/normal","Positive/elevated"))
  known_fraction <- (nrow(cea_dev_src)+nrow(cea_val_src))/nrow(seer_split)
  if (known_fraction >= minimum_cea_known_fraction && nrow(cea_val_src)>0) {
    cd <- prepare_model_data(cea_dev_src); cv <- prepare_model_data(cea_val_src); cv <- align_factor_levels(cd,cv)
    cb <- fit_lrm_safe(make_primary_formula(FALSE,FALSE,FALSE),cd)
    cp <- fit_lrm_safe(make_primary_formula(FALSE,FALSE,TRUE),cd)
    eb <- evaluate_model_on_data(cb,cv,"CEA-known base"); ep <- evaluate_model_on_data(cp,cv,"CEA-known + CEA")
    cea_incremental <- data.frame(Known_fraction=known_fraction,Base_AUC=eb$summary$AUC,CEA_AUC=ep$summary$AUC,
                                  Delta_AUC=ep$summary$AUC-eb$summary$AUC,DeLong_P=compare_auc_delong(eb,ep),
                                  Base_Brier=eb$summary$Brier,CEA_Brier=ep$summary$Brier,Status="Success")
  } else cea_incremental <- data.frame(Status="Skipped: insufficient CEA availability",Known_fraction=known_fraction)
}

save_csv(race_incremental,"race_incremental_value.csv","06_secondary")
save_csv(pni_incremental,"PNI_incremental_value.csv","06_secondary")
save_csv(pni_association,"PNI_adjusted_association.csv","06_secondary")
save_csv(cea_incremental,"CEA_optional_incremental_value.csv","06_secondary")
