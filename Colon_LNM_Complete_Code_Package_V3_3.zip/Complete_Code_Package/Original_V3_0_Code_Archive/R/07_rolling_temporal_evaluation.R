# ============================================================
# 07. ROLLING-ORIGIN TEMPORAL EVALUATION
# Same M3 specification and the same frozen knots at every origin.
# ============================================================
rolling_results <- list(); rolling_predictions <- list(); rolling_models <- list()
for (test_year in rolling_test_years) {
  train_source <- seer_split %>% filter(year_dx < test_year, year_dx >= min(analysis_years))
  test_source <- seer_split %>% filter(year_dx == test_year)
  if (!nrow(train_source) || !nrow(test_source)) next
  status_row <- tryCatch({
    tr <- prepare_model_data(train_source); te <- prepare_model_data(test_source); te <- align_factor_levels(tr,te)
    f <- make_primary_formula(FALSE)
    mod <- fit_lrm_safe(f,tr)
    ev <- evaluate_model_on_data(mod,te,paste0(min(train_source$year_dx),"-",max(train_source$year_dx)," -> ",test_year))
    rolling_models[[as.character(test_year)]] <<- mod
    rolling_predictions[[as.character(test_year)]] <<- data.frame(patient_id=test_source$patient_id,year=test_year,lnm_num=te$lnm_num,predicted=ev$probability)
    cbind(data.frame(Train_start=min(train_source$year_dx),Train_end=max(train_source$year_dx),Test_year=test_year,
                     Train_N=nrow(tr),Train_events=sum(tr$lnm_num),Status="Success",Message=""),ev$summary)
  }, error=function(e) {
    data.frame(Train_start=min(train_source$year_dx),Train_end=max(train_source$year_dx),Test_year=test_year,
               Train_N=nrow(train_source),Train_events=sum(train_source$lnm_num),Status="Failed",Message=conditionMessage(e),
               Analysis="",N=nrow(test_source),Events=sum(test_source$lnm_num),LNM_rate=mean(test_source$lnm_num),
               AUC=NA,AUC_lower=NA,AUC_upper=NA,Brier=NA,Scaled_Brier=NA,Calibration_intercept=NA,Calibration_slope=NA,Eavg=NA,Emax=NA)
  })
  rolling_results[[as.character(test_year)]] <- status_row
}
rolling_temporal_performance <- bind_rows(rolling_results)
rolling_prediction_data <- bind_rows(rolling_predictions)
save_csv(rolling_temporal_performance,"rolling_temporal_performance.csv","05_validation")
save_csv(rolling_prediction_data,"rolling_temporal_predictions.csv","05_validation")
