# ============================================================
# 13. TABLE EXPORTS AND V3.0 RESULTS FREEZE
# ============================================================
# Simple main baseline table designed for manuscript drafting.
baseline_table <- seer_split %>% group_by(cohort) %>% summarise(
  N=n(), LNM_n=sum(lnm_num), LNM_pct=100*mean(lnm_num), Age_median=median(age),
  Female_pct=100*mean(sex=="Female"), Right_colon_pct=100*mean(site_group=="Right-sided colon"),
  Conventional_adeno_pct=100*mean(histology_group=="Adenocarcinoma"), Poor_grade_pct=100*mean(grade_group=="Poorly/undifferentiated"),
  T2_pct=100*mean(t_stage=="T2"), Tumor_size_median=median(tumor_size_mm), Nodes_examined_median=median(nodes_examined), .groups="drop")

# Computational coefficients of the primary RCS model.
coef_vec <- coef(primary_model)
primary_coefficients <- data.frame(Term=names(coef_vec),Coefficient=as.numeric(coef_vec),stringsAsFactors=FALSE)
model_information <- data.frame(
  Metric=c("Development N","Development events","Model coefficients including intercept","Model df excluding intercept","Events per fitted df (descriptive only)"),
  Value=c(nrow(development_model_data),sum(development_model_data$lnm_num),length(coef_vec),length(coef_vec)-1,sum(development_model_data$lnm_num)/(length(coef_vec)-1))
)

# Freeze checks.
assert_equal(nrow(cohort_final),expected_counts$total_n,"total N")
assert_equal(sum(cohort_final$lnm_num),expected_counts$total_events,"total events")
assert_equal(nrow(development_data),expected_counts$development_n,"development N")
assert_equal(sum(development_data$lnm_num),expected_counts$development_events,"development events")
assert_equal(nrow(temporal_data),expected_counts$temporal_n,"2022 N")
assert_equal(sum(temporal_data$lnm_num),expected_counts$temporal_events,"2022 events")
primary_vars <- all.vars(formula(primary_model))
if ("race_model" %in% primary_vars || "pni_model" %in% primary_vars || "cea_model" %in% primary_vars) stop("Primary model contamination: secondary variable entered M3.")
if (!all(sort(unique(development_data$year_dx)) == development_years)) stop("Development years changed.")
if (!all(unique(temporal_data$year_dx) == final_temporal_year)) stop("Final temporal year changed.")

freeze_summary <- data.frame(
  Item=c("Analysis version","Total N","Total LNM events","Development years","Development N","Development events","Final temporal year","2022 N","2022 events","Primary formula","Age knots","Tumor-size knots","2022 AUC","2022 Brier","2022 calibration intercept","2022 calibration slope"),
  Value=c(analysis_version,nrow(cohort_final),sum(cohort_final$lnm_num),paste(development_years,collapse="-"),nrow(development_data),sum(development_data$lnm_num),final_temporal_year,nrow(temporal_data),sum(temporal_data$lnm_num),
          paste(deparse(formula(primary_model)),collapse=" "),paste(age_knots,collapse=", "),paste(tumor_size_knots,collapse=", "),
          final_2022_performance$AUC,final_2022_performance$Brier,final_2022_performance$Calibration_intercept,final_2022_performance$Calibration_slope), stringsAsFactors=FALSE)

freeze_book <- list(
  Freeze=freeze_summary,
  Cohort=cohort_summary,
  Annual=annual_summary,
  Baseline=baseline_table,
  CaseMix2022=case_mix_2022,
  RollingCaseMix=rolling_case_mix,
  ModelBenchmarks=model_benchmark_performance,
  BenchmarkDeLong=benchmark_delong,
  Nonlinearity=nonlinearity_results,
  Bootstrap=internal_validation_summary,
  RollingTemporal=rolling_temporal_performance,
  Final2022=final_2022_performance,
  RiskDeciles2022=final_2022_deciles,
  T1T2=tstage_subgroup_performance,
  RaceAddedValue=race_incremental,
  PNIAddedValue=pni_incremental,
  PNIAssociation=pni_association,
  CEAAddedValue=cea_incremental,
  Sensitivity=sensitivity_results,
  RCSKnots=knots_table,
  PrimaryCoefficients=primary_coefficients,
  ModelInformation=model_information,
  SecondaryAvailability=secondary_availability
)
openxlsx::write.xlsx(freeze_book,file.path(project_dir,"V3_0_FINAL_RESULTS.xlsx"),overwrite=TRUE)
openxlsx::write.xlsx(freeze_book,file.path(output_root,"10_tables","V3_0_FINAL_RESULTS.xlsx"),overwrite=TRUE)
writeLines(paste(freeze_summary$Item,freeze_summary$Value,sep=": "),file.path(project_dir,"V3_0_ANALYSIS_FREEZE.txt"))
save_csv(baseline_table,"Main_Table_1_Baseline.csv","10_tables")
save_csv(model_benchmark_performance,"Main_Table_2_Model_Benchmark.csv","10_tables")
save_csv(final_2022_performance,"Main_Table_3_Final_2022_Performance.csv","10_tables")
