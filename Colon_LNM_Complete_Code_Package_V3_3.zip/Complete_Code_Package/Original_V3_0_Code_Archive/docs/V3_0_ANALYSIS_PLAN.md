# V3.0 analysis plan

## Primary scientific question
How much stable lymph-node-metastasis risk information is available from routinely captured SEER clinicopathologic variables in contemporary T1–T2 colon adenocarcinoma, and does additional model complexity materially improve prediction?

## Primary model (M3)
Race-free logistic regression using fixed restricted cubic splines for age and tumor size plus tumor site, histology, pathological grade, and T stage.

## Main upgrades over V2.2
1. Fixed knots explicitly carried through every model run.
2. Benchmark ladder: T stage only -> categorical -> linear -> RCS -> RCS + race.
3. Rolling-origin temporal evaluation.
4. Protocol-locked 2018–2021 -> 2022 evaluation without recalibration.
5. T1/T2 subgroup performance without refitting.
6. Case-mix drift using standardized mean differences.
7. PNI as an added-value experiment rather than a headline predictor.
8. Nomogram removed from the main analysis; DCA is supplementary/descriptive.
9. Single V3_0_FINAL_RESULTS.xlsx is the manuscript numeric source of truth.

## Important interpretation boundary
This is a pathology-informed / clinicopathologic risk-stratification study. It is not a validated preoperative rule and must not be described as a stand-alone tool to omit colectomy or regional nodal assessment.

## Historical validation caveat
The 2022 outcomes were already seen during the V2.2 project. V3.0 prevents any *new* coefficient estimation, predictor selection, knot selection, or recalibration using 2022; this should be described as a protocol-locked temporal re-evaluation rather than pretending the 2022 data were never previously inspected.
