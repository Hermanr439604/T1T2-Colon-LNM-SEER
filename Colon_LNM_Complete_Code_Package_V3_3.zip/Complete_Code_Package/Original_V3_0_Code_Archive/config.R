# ============================================================
# V3.0 CONFIGURATION
# T1-T2 colon adenocarcinoma / pathological LNM
# ============================================================

analysis_version <- "V3_0"
raw_csv_name <- "SEER_T1T2_colon_LNM_2018_2022_PNI_raw.csv"

# Reproducibility
random_seed <- 20260715
bootstrap_repetitions <- 1000
performance_ci_boot_repetitions <- 500

# Frozen V2.2 cohort/model definitions
analysis_years <- 2018:2022
development_years <- 2018:2021
final_temporal_year <- 2022
main_tumor_size_max_mm <- 150

# IMPORTANT: Explicitly frozen knots from V2.2. These are NOT re-estimated in
# rolling-origin analyses or sensitivity analyses.
age_knots <- c(46, 62, 72, 86)
tumor_size_knots <- c(4, 20, 33, 65)

# Optional exploratory modules
run_pni_analysis <- TRUE
run_optional_cea_analysis <- FALSE
minimum_cea_known_fraction <- 0.60
run_dca <- TRUE

# Final locked checks against the V2.2 source-of-truth cohort.
# Set strict_freeze_checks <- FALSE only when deliberately analysing a new export.
strict_freeze_checks <- TRUE
expected_counts <- list(
  total_n = 14498L,
  total_events = 2210L,
  development_n = 11490L,
  development_events = 1756L,
  temporal_n = 3008L,
  temporal_events = 454L
)

# Rolling temporal evaluation. The earliest window can fail if a very rare
# factor level is absent from a small training year; failures are recorded rather
# than silently changing the model.
rolling_test_years <- 2019:2022

# Main manuscript model ladder
benchmark_model_labels <- c(
  M0 = "T stage only",
  M1 = "Categorical clinicopathologic benchmark",
  M2 = "Linear clinicopathologic model",
  M3 = "Fixed-knot RCS clinicopathologic model (primary)",
  M4 = "Primary model + race (exploratory)"
)
