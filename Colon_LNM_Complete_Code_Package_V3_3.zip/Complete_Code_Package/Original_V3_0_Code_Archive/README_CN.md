# T1–T2 结肠癌 LNM｜V3.0 R 代码包

这是基于 V2.2 frozen analysis 重构的模块化 V3.0 管线。核心目的不是“硬把 AUC 做高”，而是系统回答：**常规 SEER 临床病理变量的预测能力、复杂模型的增量价值、跨年份稳定性，以及 T1/T2 中的稳健性。**

## 一、你只需要做什么

1. 把原始 SEER CSV 放进 `data/` 文件夹。默认文件名：`SEER_T1T2_colon_LNM_2018_2022_PNI_raw.csv`。
2. 双击 `T1T2_Colon_LNM_V3_0.Rproj` 用 RStudio 打开。
3. 打开并检查 `config.R`。一般不要改 cohort、knots 和 primary formula。
4. 运行 `RUN_V3_0.R`。
5. 最终以根目录生成的 `V3_0_FINAL_RESULTS.xlsx` 作为论文所有数字的唯一来源。

## 二、V3.0 主要分析

- 原始数据审计与 V2.2 队列完整复现
- 2018–2021 development / 2022 temporal evaluation
- 模型阶梯：M0 T-stage only；M1 categorical；M2 linear；M3 fixed-knot RCS primary；M4 M3+race
- M3 1000 次 bootstrap internal validation
- rolling-origin temporal evaluation：2018→2019、2018–2019→2020、2018–2020→2021、2018–2021→2022（若早期训练集缺失极罕见因子水平，程序会记录 failed，而不是悄悄改模型）
- case-mix drift：SMD
- 2022 final performance：AUC、Brier、scaled Brier、calibration intercept/slope、Eavg/Emax、risk deciles
- T1 / T2 subgroup performance（不重新建模）
- race added value
- PNI added value + adjusted association
- CEA availability audit；CEA added-value 模块默认关闭
- 6 组 sensitivity analyses
- 新版主图：cohort/design、rolling temporal、model benchmark、2022 final performance
- Supplement：RCS curves、sensitivity AUC、bootstrap calibration、descriptive DCA
- SHA256 manifest + sessionInfo + freeze audit

## 三、关键冻结设定

Primary model：
`lnm_num ~ RCS(age) + site + histology + grade + RCS(tumor size) + T stage`

固定 knots：
- Age：46, 62, 72, 86 years
- Tumor size：4, 20, 33, 65 mm

Primary model 不含 race、PNI、CEA。

## 四、为什么把 knots 写死

V2.2 的 knots 已经冻结。如果 rolling validation 每次都用 `rcs(age, 4)` 重新自动找 knots，那么 2019、2020、2021、2022 实际上比较的是不同 spline specification。V3.0 因此显式使用固定 knots，保证真正比较同一个模型结构。

## 五、2022 的表述

V3.0 当前运行中，2022 不参与 coefficient fitting、predictor selection、knot selection 或 recalibration。但是我们历史上已经在 V2.2 看过 2022 结果，因此论文中不应虚构为“从未看过的完全 untouched external validation”。更准确的表述是 protocol-locked temporal re-evaluation / temporal evaluation。

## 六、如果第一次运行失败

优先检查：
- CSV 文件名和路径；
- SEER 导出变量名是否与 V2.2 相同；
- R 包安装是否成功；
- rolling 2018→2019 若因某个极罕见 histology level 在 2018 缺失而失败，不要修改主模型，查看 `rolling_temporal_performance.csv` 的 Message。后续累计年份窗口仍可正常评价。

## 七、不要做的事情

不要为了提高 AUC 临时加入 XGBoost、RF、LASSO；不要根据 2022 表现调 knots/删变量；不要把 Youden threshold 当临床 cutoff；不要把 DCA 当作已经证明临床决策效用；不要把模型描述成可直接决定是否省略 colectomy/lymphadenectomy。
