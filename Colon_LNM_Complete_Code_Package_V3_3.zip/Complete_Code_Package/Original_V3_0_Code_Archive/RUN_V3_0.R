# ============================================================
# RUN ALL V3.0 ANALYSES
# ============================================================
rm(list = ls())
gc()
options(stringsAsFactors = FALSE, scipen = 999)

project_dir <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
if (!file.exists(file.path(project_dir, "config.R"))) {
  stop("Run this script from the V3.0 package root (open the .Rproj first).")
}
source(file.path(project_dir, "config.R"))
set.seed(random_seed)

scripts <- c(
  "00_utils.R",
  "01_import_audit.R",
  "02_build_cohort.R",
  "03_descriptive_case_mix.R",
  "04_model_data.R",
  "05_model_benchmarks.R",
  "06_internal_validation.R",
  "07_rolling_temporal_evaluation.R",
  "08_final_2022_evaluation.R",
  "09_tstage_subgroup_evaluation.R",
  "10_incremental_value.R",
  "11_sensitivity_analyses.R",
  "12_figures.R",
  "13_tables_and_freeze.R",
  "14_reproducibility.R"
)

for (s in scripts) {
  message("\n==================== ", s, " ====================")
  source(file.path(project_dir, "R", s), local = .GlobalEnv)
}
message("\nV3.0 pipeline completed. See outputs/ and V3_0_FINAL_RESULTS.xlsx")
