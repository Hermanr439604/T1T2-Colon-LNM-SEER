# Optional: create a project-local package environment after the pipeline runs successfully.
if (!requireNamespace("renv", quietly = TRUE)) install.packages("renv")
renv::init(bare = TRUE)
renv::snapshot()
