# ============================================================================
# V2.2 SUPPLEMENTARY EXPORT PATCH
# T1-T2 colon adenocarcinoma and lymph node metastasis
#
# PURPOSE
#   Export publication-ready supplementary tables and a complete aggregated
#   analysis audit workbook from the successfully completed V2.2 pipeline.
#
# IMPORTANT
#   - This patch does NOT refit any model.
#   - This patch does NOT change the cohort, predictions, figures, or results.
#   - It loads only objects already saved by MASTER PIPELINE V2.2.
#   - It does NOT export patient-level SEER records for journal submission.
#
# Run after MASTER_PIPELINE_T1T2_COLON_LNM_FINAL_V2_2.R has completed.
# ============================================================================

rm(list = ls())
gc()

options(stringsAsFactors = FALSE)
options(scipen = 999)

# ----------------------------------------------------------------------------
# 0. USER SETTINGS
# ----------------------------------------------------------------------------

project_dir <- "C:/Users/Administrator/Desktop/Final_Colon"
output_root <- file.path(project_dir, "Outputs_V2_2")
export_dir <- file.path(output_root, "09_supplementary_exports")

dir.create(export_dir, showWarnings = FALSE, recursive = TRUE)

required_packages <- c(
  "openxlsx",
  "dplyr",
  "tidyr",
  "pROC",
  "rms",
  "Hmisc"
)

missing_packages <- required_packages[
  !required_packages %in% rownames(installed.packages())
]

if (length(missing_packages) > 0) {
  install.packages(missing_packages, dependencies = TRUE)
}

library(openxlsx)
library(dplyr)
library(tidyr)
library(pROC)
library(rms)
library(Hmisc)

# ----------------------------------------------------------------------------
# 1. PATHS AND SAFETY CHECKS
# ----------------------------------------------------------------------------

paths <- list(
  descriptive = file.path(
    output_root,
    "03_tables",
    "01_descriptive_tables_final.xlsx"
  ),
  model = file.path(
    output_root,
    "03_tables",
    "02_model_development_and_validation_final.xlsx"
  ),
  secondary = file.path(
    output_root,
    "03_tables",
    "03_sensitivity_and_secondary_analyses_final.xlsx"
  ),
  raw_audit = file.path(
    output_root,
    "07_logs",
    "01_initial_raw_data_audit.xlsx"
  ),
  cleaning_audit = file.path(
    output_root,
    "07_logs",
    "02_final_cohort_cleaning_audit.xlsx"
  ),
  pipeline_summary = file.path(
    output_root,
    "07_logs",
    "Final_pipeline_summary.xlsx"
  ),
  analysis_notes = file.path(
    output_root,
    "07_logs",
    "V2_2_analysis_notes.txt"
  ),
  session_info = file.path(
    output_root,
    "07_logs",
    "R_sessionInfo.txt"
  ),
  primary_model = file.path(
    output_root,
    "08_models",
    "Primary_race_free_RCS_model_tumor_size_le150.rds"
  ),
  race_model = file.path(
    output_root,
    "08_models",
    "Exploratory_race_inclusive_RCS_model_tumor_size_le150.rds"
  ),
  development_predictions = file.path(
    output_root,
    "02_clean_data",
    "Development_data_final_predictions.rds"
  ),
  validation_predictions = file.path(
    output_root,
    "02_clean_data",
    "Validation_data_final_predictions.rds"
  )
)

missing_paths <- names(paths)[
  !vapply(paths, file.exists, logical(1))
]

if (length(missing_paths) > 0) {
  stop(
    "The following required V2.2 outputs are missing:\n",
    paste(
      paste0(missing_paths, ": ", unlist(paths[missing_paths])),
      collapse = "\n"
    )
  )
}

primary_model <- readRDS(paths$primary_model)
race_model <- readRDS(paths$race_model)
development_data <- readRDS(paths$development_predictions)
validation_data <- readRDS(paths$validation_predictions)

required_prediction_variables <- c(
  "lnm_num",
  "final_pred",
  "age",
  "tumor_size_mm",
  "site_model",
  "histology_model",
  "grade_model",
  "t_stage"
)

missing_prediction_variables <- setdiff(
  required_prediction_variables,
  names(validation_data)
)

if (length(missing_prediction_variables) > 0) {
  stop(
    "Validation prediction object is missing: ",
    paste(missing_prediction_variables, collapse = ", ")
  )
}

primary_formula_text <- paste(
  deparse(formula(primary_model)),
  collapse = " "
)

if (grepl("race_model", primary_formula_text, fixed = TRUE)) {
  stop("Safety check failed: race is present in the primary model formula.")
}

# ----------------------------------------------------------------------------
# 2. HELPERS
# ----------------------------------------------------------------------------

safe_read_sheet <- function(file, sheet) {
  available_sheets <- getSheetNames(file)

  if (!sheet %in% available_sheets) {
    return(
      data.frame(
        Note = paste0(
          "Sheet '", sheet, "' was not found in ", basename(file), "."
        ),
        stringsAsFactors = FALSE
      )
    )
  }

  read.xlsx(
    file,
    sheet = sheet,
    check.names = FALSE,
    detectDates = TRUE
  )
}

safe_divide <- function(numerator, denominator) {
  ifelse(
    is.na(denominator) | denominator == 0,
    NA_real_,
    numerator / denominator
  )
}

round_numeric <- function(data, digits = 4) {
  data %>%
    mutate(
      across(
        where(is.numeric),
        ~ round(.x, digits)
      )
    )
}

make_source_manifest <- function(path_list) {
  file_paths <- unlist(path_list, use.names = TRUE)

  data.frame(
    Object = names(file_paths),
    File = basename(file_paths),
    Full_path = unname(file_paths),
    Size_bytes = unname(file.info(file_paths)$size),
    Modified_time = as.character(
      unname(file.info(file_paths)$mtime)
    ),
    MD5 = unname(tools::md5sum(file_paths)),
    stringsAsFactors = FALSE
  )
}

extract_model_coefficients <- function(model) {
  coefficient_vector <- coef(model)
  coefficient_names <- names(coefficient_vector)
  variance_matrix <- as.matrix(vcov(model))

  if (
    !is.null(rownames(variance_matrix)) &&
    all(coefficient_names %in% rownames(variance_matrix))
  ) {
    standard_errors <- sqrt(
      diag(variance_matrix[coefficient_names, coefficient_names, drop = FALSE])
    )
  } else {
    standard_errors <- sqrt(diag(variance_matrix))
    standard_errors <- standard_errors[seq_along(coefficient_vector)]
  }

  z_value <- as.numeric(coefficient_vector) / standard_errors
  p_value <- 2 * pnorm(-abs(z_value))

  data.frame(
    Term = coefficient_names,
    Coefficient = as.numeric(coefficient_vector),
    Standard_error = standard_errors,
    Z_value = z_value,
    P_value = p_value,
    Exp_coefficient = exp(as.numeric(coefficient_vector)),
    Note = ifelse(
      grepl("age|tumor_size_mm", coefficient_names),
      "Spline-basis coefficient; do not interpret as a one-unit odds ratio.",
      "Computational model coefficient."
    ),
    stringsAsFactors = FALSE
  ) %>%
    round_numeric(6)
}

extract_knots <- function(model, data, variable, knot_number = 4) {
  model_knots <- NULL

  if (
    !is.null(model$Design) &&
    !is.null(model$Design$parms) &&
    !is.null(model$Design$parms[[variable]])
  ) {
    model_knots <- suppressWarnings(
      as.numeric(model$Design$parms[[variable]])
    )
  }

  model_knots <- model_knots[is.finite(model_knots)]

  if (length(model_knots) == 0) {
    model_knots <- as.numeric(
      Hmisc::rcspline.eval(
        data[[variable]],
        nk = knot_number,
        knots.only = TRUE
      )
    )
  }

  data.frame(
    Variable = variable,
    Knot_number = seq_along(model_knots),
    Knot_value = model_knots,
    stringsAsFactors = FALSE
  ) %>%
    round_numeric(6)
}

make_reference_table <- function(data) {
  factor_variables <- intersect(
    c(
      "site_model",
      "histology_model",
      "grade_model",
      "t_stage",
      "race_model"
    ),
    names(data)
  )

  bind_rows(
    lapply(
      factor_variables,
      function(variable_name) {
        current_levels <- levels(data[[variable_name]])

        data.frame(
          Variable = variable_name,
          Reference_level = ifelse(
            length(current_levels) > 0,
            current_levels[1],
            NA_character_
          ),
          All_levels = paste(current_levels, collapse = " | "),
          stringsAsFactors = FALSE
        )
      }
    )
  )
}

summarise_risk_distribution <- function(data, cohort_label) {
  probabilities <- as.numeric(data$final_pred)

  quantile_values <- as.numeric(
    quantile(
      probabilities,
      probs = c(0, 0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 1),
      na.rm = TRUE
    )
  )

  data.frame(
    Cohort = cohort_label,
    Metric = c(
      "N",
      "Events",
      "Event rate",
      "Mean predicted risk",
      "Minimum",
      "1st percentile",
      "5th percentile",
      "10th percentile",
      "25th percentile",
      "Median",
      "75th percentile",
      "90th percentile",
      "95th percentile",
      "99th percentile",
      "Maximum"
    ),
    Value = c(
      nrow(data),
      sum(data$lnm_num == 1, na.rm = TRUE),
      mean(data$lnm_num == 1, na.rm = TRUE),
      mean(probabilities, na.rm = TRUE),
      quantile_values
    ),
    stringsAsFactors = FALSE
  ) %>%
    round_numeric(6)
}

calculate_threshold_metrics <- function(data, thresholds) {
  outcome <- as.integer(data$lnm_num)
  probability <- as.numeric(data$final_pred)

  bind_rows(
    lapply(
      thresholds,
      function(threshold) {
        predicted_positive <- probability >= threshold

        tp <- sum(predicted_positive & outcome == 1, na.rm = TRUE)
        fp <- sum(predicted_positive & outcome == 0, na.rm = TRUE)
        tn <- sum(!predicted_positive & outcome == 0, na.rm = TRUE)
        fn <- sum(!predicted_positive & outcome == 1, na.rm = TRUE)

        data.frame(
          Threshold = threshold,
          Predicted_high_risk_n = tp + fp,
          Predicted_high_risk_percent = 100 * (tp + fp) / length(outcome),
          True_positive = tp,
          False_positive = fp,
          True_negative = tn,
          False_negative = fn,
          Sensitivity = safe_divide(tp, tp + fn),
          Specificity = safe_divide(tn, tn + fp),
          Positive_predictive_value = safe_divide(tp, tp + fp),
          Negative_predictive_value = safe_divide(tn, tn + fn),
          Accuracy = safe_divide(tp + tn, length(outcome)),
          Observed_LNM_rate_in_high_risk = safe_divide(tp, tp + fp),
          Observed_LNM_rate_in_low_risk = safe_divide(fn, fn + tn),
          stringsAsFactors = FALSE
        )
      }
    )
  ) %>%
    round_numeric(4)
}

combine_with_section <- function(data_list) {
  bind_rows(
    lapply(
      names(data_list),
      function(section_name) {
        current_data <- data_list[[section_name]]

        if (is.null(current_data) || nrow(current_data) == 0) {
          current_data <- data.frame(
            Note = "No rows available.",
            stringsAsFactors = FALSE
          )
        }

        current_data %>%
          mutate(
            Section = section_name,
            .before = 1
          )
      }
    )
  )
}

sanitize_sheet_name <- function(x) {
  x <- gsub("[\\\\/?*\\[\\]:]", "_", x)
  substr(x, 1, 31)
}

# ----------------------------------------------------------------------------
# 3. LOAD EXISTING AGGREGATED TABLES
# ----------------------------------------------------------------------------

selection_flow <- safe_read_sheet(
  paths$cleaning_audit,
  "Selection_flow"
)

outcome_summary <- safe_read_sheet(
  paths$cleaning_audit,
  "Outcome_summary"
)

key_missingness <- safe_read_sheet(
  paths$cleaning_audit,
  "Key_missingness"
)

variable_dictionary <- safe_read_sheet(
  paths$raw_audit,
  "Variable_dictionary"
)

native_missingness <- safe_read_sheet(
  paths$raw_audit,
  "Native_missingness"
)

cohort_summary <- safe_read_sheet(
  paths$descriptive,
  "Cohort_summary"
)

annual_distribution <- safe_read_sheet(
  paths$descriptive,
  "Annual_distribution"
)

table1_dev_vs_val <- safe_read_sheet(
  paths$descriptive,
  "Table1_dev_vs_val"
)

table2_lnm_vs_nonlnm <- safe_read_sheet(
  paths$descriptive,
  "Table2_LNM_vs_nonLNM"
)

lnm_rate_subgroup <- safe_read_sheet(
  paths$descriptive,
  "LNM_rate_subgroup"
)

candidate_model_performance <- safe_read_sheet(
  paths$model,
  "Candidate_model_performance"
)

delong_comparison <- safe_read_sheet(
  paths$model,
  "Delong_comparison"
)

race_removal_test <- safe_read_sheet(
  paths$model,
  "Race_removal_test"
)

model_definition_audit <- safe_read_sheet(
  paths$model,
  "Model_definition_audit"
)

nonlinearity_tests <- safe_read_sheet(
  paths$model,
  "Nonlinearity_tests"
)

linear_model_or <- safe_read_sheet(
  paths$model,
  "Linear_model_OR"
)

primary_model_anova <- safe_read_sheet(
  paths$model,
  "Primary_race_free_model_ANOVA"
)

bootstrap_validation <- safe_read_sheet(
  paths$model,
  "Bootstrap_validation"
)

optimism_corrected_summary <- safe_read_sheet(
  paths$model,
  "Optimism_corrected_summary"
)

final_performance <- safe_read_sheet(
  paths$model,
  "Final_performance"
)

optimal_cutoff <- safe_read_sheet(
  paths$model,
  "Optimal_cutoff"
)

sensitivity <- safe_read_sheet(
  paths$secondary,
  "Sensitivity"
)

pni_status <- safe_read_sheet(
  paths$secondary,
  "PNI_status"
)

pni_lnm_rates <- safe_read_sheet(
  paths$secondary,
  "PNI_LNM_rates"
)

pni_adjusted_or <- safe_read_sheet(
  paths$secondary,
  "PNI_adjusted_OR"
)

pni_incremental_performance <- safe_read_sheet(
  paths$secondary,
  "PNI_incremental_performance"
)

pni_period_interaction <- safe_read_sheet(
  paths$secondary,
  "PNI_period_interaction"
)

tumor_size_summary <- safe_read_sheet(
  paths$secondary,
  "Tumor_size"
)

calibration_deciles <- safe_read_sheet(
  paths$secondary,
  "Calib_deciles"
)

dca_data <- safe_read_sheet(
  paths$secondary,
  "DCA"
)

pipeline_summary <- safe_read_sheet(
  paths$pipeline_summary,
  getSheetNames(paths$pipeline_summary)[1]
)

# ----------------------------------------------------------------------------
# 4. DERIVED REPRODUCIBILITY TABLES
# ----------------------------------------------------------------------------

primary_coefficients <- extract_model_coefficients(primary_model)
race_model_coefficients <- extract_model_coefficients(race_model)

rcs_knots <- bind_rows(
  extract_knots(primary_model, development_data, "age", 4),
  extract_knots(primary_model, development_data, "tumor_size_mm", 4)
)

reference_levels <- make_reference_table(development_data)

model_specification <- data.frame(
  Item = c(
    "Analysis version",
    "Model family",
    "Outcome",
    "Primary formula",
    "Development years",
    "Temporal validation year",
    "Development N",
    "Development events",
    "Validation N",
    "Validation events",
    "Spline specification",
    "Race use",
    "Bootstrap repetitions"
  ),
  Value = c(
    "V2.2",
    "Binary logistic regression fitted with rms::lrm",
    "Pathological LNM: one or more positive regional lymph nodes",
    primary_formula_text,
    "2018-2021",
    "2022",
    nrow(development_data),
    sum(development_data$lnm_num == 1, na.rm = TRUE),
    nrow(validation_data),
    sum(validation_data$lnm_num == 1, na.rm = TRUE),
    "Four-knot restricted cubic splines for age and tumor size",
    "Excluded from primary model; exploratory comparison only",
    1000
  ),
  stringsAsFactors = FALSE
)

risk_distribution <- bind_rows(
  summarise_risk_distribution(
    development_data,
    "Development cohort (2018-2021)"
  ),
  summarise_risk_distribution(
    validation_data,
    "Temporal validation cohort (2022)"
  )
)

prespecified_thresholds <- c(
  0.05,
  0.10,
  0.15,
  0.20,
  0.25,
  0.30,
  0.35,
  0.40
)

threshold_performance <- calculate_threshold_metrics(
  validation_data,
  prespecified_thresholds
)

pni_combined <- combine_with_section(
  list(
    PNI_status = pni_status,
    PNI_LNM_rates = pni_lnm_rates,
    PNI_adjusted_OR = pni_adjusted_or,
    PNI_incremental_performance = pni_incremental_performance,
    PNI_period_interaction = pni_period_interaction
  )
)

model_comparison_combined <- combine_with_section(
  list(
    Candidate_model_performance = candidate_model_performance,
    Delong_comparison = delong_comparison,
    Race_removal_test = race_removal_test,
    Model_definition_audit = model_definition_audit,
    Nonlinearity_tests = nonlinearity_tests
  )
)

validation_combined <- combine_with_section(
  list(
    Final_performance = final_performance,
    Optimism_corrected_summary = optimism_corrected_summary,
    Optimal_cutoff = optimal_cutoff,
    Risk_distribution = risk_distribution
  )
)

source_manifest <- make_source_manifest(paths)

readme_table <- data.frame(
  Item = c(
    "Purpose",
    "Primary analysis",
    "Patient-level data",
    "Recommended journal upload",
    "Local audit workbook",
    "Reproducibility",
    "Generated on"
  ),
  Description = c(
    "Export complete aggregated supplementary tables from V2.2 without refitting the model.",
    "Race-free RCS logistic model using age, site, histology, grade, tumor size, and T stage.",
    "No patient-level SEER records are included in either workbook. Do not upload the cleaned cohort CSV or RDS files as supplementary material unless SEER and the journal explicitly permit redistribution.",
    "Supplementary_Tables_Submission_V2_2.xlsx",
    "Complete_Analysis_Audit_V2_2.xlsx is primarily for authors, reproducibility checks, and reviewer queries.",
    "Exact formula, spline knots, reference levels, and computational coefficients are included.",
    as.character(Sys.time())
  ),
  stringsAsFactors = FALSE
)

# ----------------------------------------------------------------------------
# 5. WORKBOOK FORMATTING
# ----------------------------------------------------------------------------

style_title <- createStyle(
  fontName = "Times New Roman",
  fontSize = 13,
  textDecoration = "bold",
  fontColour = "#1D3557"
)

style_header <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  textDecoration = "bold",
  fontColour = "#FFFFFF",
  fgFill = "#1D3557",
  halign = "center",
  valign = "center",
  wrapText = TRUE,
  border = "Bottom",
  borderColour = "#FFFFFF"
)

style_body <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  valign = "top",
  wrapText = TRUE
)

style_note <- createStyle(
  fontName = "Times New Roman",
  fontSize = 9,
  fontColour = "#666666",
  valign = "top",
  wrapText = TRUE
)

write_formatted_sheet <- function(
  workbook,
  sheet_name,
  title,
  data,
  note = NULL
) {
  sheet_name <- sanitize_sheet_name(sheet_name)
  addWorksheet(workbook, sheet_name, gridLines = FALSE)

  writeData(workbook, sheet_name, title, startRow = 1, startCol = 1)
  addStyle(
    workbook,
    sheet_name,
    style_title,
    rows = 1,
    cols = 1,
    gridExpand = TRUE
  )

  writeData(
    workbook,
    sheet_name,
    data,
    startRow = 3,
    startCol = 1,
    headerStyle = style_header,
    borders = "rows",
    borderStyle = "thin",
    borderColour = "#D9D9D9",
    keepNA = TRUE,
    na.string = ""
  )

  if (nrow(data) > 0 && ncol(data) > 0) {
    addStyle(
      workbook,
      sheet_name,
      style_body,
      rows = 4:(3 + nrow(data)),
      cols = 1:ncol(data),
      gridExpand = TRUE,
      stack = TRUE
    )

    freezePane(
      workbook,
      sheet_name,
      firstActiveRow = 4,
      firstActiveCol = 1
    )

    setColWidths(
      workbook,
      sheet_name,
      cols = 1:ncol(data),
      widths = "auto"
    )

    # Prevent extreme widths caused by long formulas or notes.
    for (column_index in seq_len(ncol(data))) {
      maximum_text_length <- max(
        nchar(
          c(
            names(data)[column_index],
            as.character(data[[column_index]])
          )
        ),
        na.rm = TRUE
      )

      bounded_width <- min(
        45,
        max(11, maximum_text_length + 2)
      )

      setColWidths(
        workbook,
        sheet_name,
        cols = column_index,
        widths = bounded_width
      )
    }
  }

  if (!is.null(note) && nzchar(note)) {
    note_row <- 5 + nrow(data)
    writeData(workbook, sheet_name, note, startRow = note_row, startCol = 1)
    addStyle(
      workbook,
      sheet_name,
      style_note,
      rows = note_row,
      cols = 1:max(1, ncol(data)),
      gridExpand = TRUE,
      stack = TRUE
    )
  }
}

# ----------------------------------------------------------------------------
# 6. PUBLICATION-READY SUPPLEMENTARY WORKBOOK
# ----------------------------------------------------------------------------

submission_wb <- createWorkbook(
  creator = "V2.2 supplementary export patch"
)

write_formatted_sheet(
  submission_wb,
  "README",
  "Supplementary tables: scope and use",
  readme_table
)

write_formatted_sheet(
  submission_wb,
  "Table_S1_Selection",
  "Supplementary Table S1. Patient selection and cohort audit",
  combine_with_section(
    list(
      Selection_flow = selection_flow,
      Outcome_summary = outcome_summary,
      Key_model_missingness = key_missingness
    )
  ),
  "The primary model uses complete cases for tumor size and pathological grade."
)

write_formatted_sheet(
  submission_wb,
  "Table_S2_LNM_groups",
  "Supplementary Table S2. Detailed characteristics by pathological LNM status",
  table2_lnm_vs_nonlnm
)

write_formatted_sheet(
  submission_wb,
  "Table_S3_Subgroup_rates",
  "Supplementary Table S3. Observed LNM rates across clinicopathologic subgroups",
  lnm_rate_subgroup
)

write_formatted_sheet(
  submission_wb,
  "Table_S4_Model_compare",
  "Supplementary Table S4. Candidate-model comparison and race-removal analysis",
  model_comparison_combined,
  "The race-inclusive model is exploratory; the race-free RCS model is primary."
)

write_formatted_sheet(
  submission_wb,
  "Table_S5_Model_spec",
  "Supplementary Table S5A. Exact primary-model specification",
  model_specification
)

write_formatted_sheet(
  submission_wb,
  "Table_S5_Knots_refs",
  "Supplementary Table S5B. RCS knot locations and factor reference levels",
  combine_with_section(
    list(
      RCS_knots = rcs_knots,
      Factor_reference_levels = reference_levels
    )
  )
)

write_formatted_sheet(
  submission_wb,
  "Table_S5_Coefficients",
  "Supplementary Table S5C. Computational coefficients of the primary RCS model",
  primary_coefficients,
  "Spline-basis coefficients are provided for exact reproduction and should not be interpreted as simple one-unit odds ratios."
)

write_formatted_sheet(
  submission_wb,
  "Table_S6_Validation",
  "Supplementary Table S6. Primary-model performance and bootstrap validation",
  validation_combined
)

write_formatted_sheet(
  submission_wb,
  "Table_S7_Calibration",
  "Supplementary Table S7. Calibration by predicted-risk decile in temporal validation",
  calibration_deciles
)

write_formatted_sheet(
  submission_wb,
  "Table_S8_Thresholds",
  "Supplementary Table S8. Classification metrics at prespecified risk thresholds",
  threshold_performance,
  "Thresholds are descriptive. No threshold has been prospectively validated for a specific treatment decision."
)

write_formatted_sheet(
  submission_wb,
  "Table_S9_Sensitivity",
  "Supplementary Table S9. Sensitivity analyses of the primary race-free model",
  sensitivity
)

write_formatted_sheet(
  submission_wb,
  "Table_S10_PNI",
  "Supplementary Table S10. Exploratory perineural-invasion analyses",
  pni_combined,
  "PNI analyses use the exploratory race-inclusive complete model in the PNI-known subset. Unknown or unassessed PNI is not classified as absent."
)

submission_file <- file.path(
  export_dir,
  "Supplementary_Tables_Submission_V2_2.xlsx"
)

saveWorkbook(
  submission_wb,
  submission_file,
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 7. COMPLETE AGGREGATED AUTHOR AUDIT WORKBOOK
# ----------------------------------------------------------------------------

complete_tables <- list(
  README = readme_table,
  Source_file_manifest = source_manifest,
  Pipeline_summary = pipeline_summary,
  Variable_dictionary = variable_dictionary,
  Native_missingness = native_missingness,
  Selection_flow = selection_flow,
  Outcome_summary = outcome_summary,
  Key_missingness = key_missingness,
  Cohort_summary = cohort_summary,
  Annual_distribution = annual_distribution,
  Table1_dev_vs_val = table1_dev_vs_val,
  Table2_LNM_vs_nonLNM = table2_lnm_vs_nonlnm,
  LNM_rate_subgroup = lnm_rate_subgroup,
  Candidate_models = candidate_model_performance,
  Delong_comparison = delong_comparison,
  Race_removal_test = race_removal_test,
  Model_definition_audit = model_definition_audit,
  Nonlinearity_tests = nonlinearity_tests,
  Linear_model_OR = linear_model_or,
  Primary_model_ANOVA = primary_model_anova,
  Primary_model_spec = model_specification,
  Primary_coefficients = primary_coefficients,
  Race_model_coefficients = race_model_coefficients,
  RCS_knots = rcs_knots,
  Factor_references = reference_levels,
  Bootstrap_validation = bootstrap_validation,
  Optimism_corrected = optimism_corrected_summary,
  Final_performance = final_performance,
  Risk_distribution = risk_distribution,
  Optimal_cutoff = optimal_cutoff,
  Threshold_performance = threshold_performance,
  Calibration_deciles = calibration_deciles,
  DCA_full = dca_data,
  Sensitivity = sensitivity,
  Tumor_size_summary = tumor_size_summary,
  PNI_status = pni_status,
  PNI_LNM_rates = pni_lnm_rates,
  PNI_adjusted_OR = pni_adjusted_or,
  PNI_incremental = pni_incremental_performance,
  PNI_period_interaction = pni_period_interaction
)

complete_wb <- createWorkbook(
  creator = "V2.2 supplementary export patch"
)

used_sheet_names <- character(0)

for (table_name in names(complete_tables)) {
  proposed_name <- sanitize_sheet_name(table_name)

  if (proposed_name %in% used_sheet_names) {
    suffix_number <- 2
    while (
      sanitize_sheet_name(
        paste0(proposed_name, "_", suffix_number)
      ) %in% used_sheet_names
    ) {
      suffix_number <- suffix_number + 1
    }

    proposed_name <- sanitize_sheet_name(
      paste0(proposed_name, "_", suffix_number)
    )
  }

  used_sheet_names <- c(used_sheet_names, proposed_name)

  write_formatted_sheet(
    complete_wb,
    proposed_name,
    table_name,
    complete_tables[[table_name]]
  )
}

complete_file <- file.path(
  export_dir,
  "Complete_Analysis_Audit_V2_2.xlsx"
)

saveWorkbook(
  complete_wb,
  complete_file,
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 8. SEPARATE MACHINE-READABLE REPRODUCIBILITY EXPORTS
# ----------------------------------------------------------------------------

write.csv(
  primary_coefficients,
  file.path(
    export_dir,
    "Primary_model_computational_coefficients_V2_2.csv"
  ),
  row.names = FALSE,
  na = ""
)

write.csv(
  rcs_knots,
  file.path(
    export_dir,
    "Primary_model_RCS_knots_V2_2.csv"
  ),
  row.names = FALSE,
  na = ""
)

write.csv(
  threshold_performance,
  file.path(
    export_dir,
    "Temporal_validation_threshold_metrics_V2_2.csv"
  ),
  row.names = FALSE,
  na = ""
)

writeLines(
  c(
    "V2.2 supplementary export patch completed.",
    paste0("Generated: ", Sys.time()),
    paste0("Primary formula: ", primary_formula_text),
    paste0("Submission workbook: ", submission_file),
    paste0("Complete audit workbook: ", complete_file),
    "No patient-level SEER records were exported by this patch.",
    "Do not upload the cleaned cohort CSV/RDS files unless redistribution is explicitly permitted."
  ),
  con = file.path(
    export_dir,
    "Supplementary_export_log.txt"
  )
)

cat(
  "\n============================================================\n",
  "V2.2 SUPPLEMENTARY EXPORT PATCH COMPLETED\n",
  "Submission workbook:\n", submission_file, "\n",
  "Complete author audit workbook:\n", complete_file, "\n",
  "No model was refitted and no patient-level data were exported.\n",
  "============================================================\n",
  sep = ""
)
