# ============================================================
# V2.2 FINAL SUPPLEMENTARY TABLES FORMATTING PATCH
# T1-T2 colon adenocarcinoma and lymph node metastasis
#
# Purpose:
#   - Read the completed V2.2 aggregate audit workbook
#   - Produce a publication-ready supplementary workbook
#   - Do NOT refit any model
#   - Do NOT export patient-level SEER data
#
# Input:
#   Outputs_V2_2/09_supplementary_exports/
#     Complete_Analysis_Audit_V2_2.xlsx
#
# Output:
#   Supplementary_Tables_Submission_V2_2_FINAL.xlsx
#   Supplementary_Tables_FINAL_log.txt
# ============================================================

rm(list = ls())
gc()

options(stringsAsFactors = FALSE)
options(scipen = 999)

# ------------------------------------------------------------
# 0. USER SETTINGS
# ------------------------------------------------------------

project_dir <- "C:/Users/Administrator/Desktop/Final_Colon"

export_dir <- file.path(
  project_dir,
  "Outputs_V2_2",
  "09_supplementary_exports"
)

audit_path <- file.path(
  export_dir,
  "Complete_Analysis_Audit_V2_2.xlsx"
)

output_path <- file.path(
  export_dir,
  "Supplementary_Tables_Submission_V2_2_FINAL.xlsx"
)

log_path <- file.path(
  export_dir,
  "Supplementary_Tables_FINAL_log.txt"
)

if (!file.exists(audit_path)) {
  stop(
    "Complete audit workbook was not found:\n",
    audit_path
  )
}

if (!requireNamespace("openxlsx", quietly = TRUE)) {
  install.packages("openxlsx", dependencies = TRUE)
}

library(openxlsx)

# ------------------------------------------------------------
# 1. HELPERS
# ------------------------------------------------------------

read_audit_sheet <- function(sheet_name) {
  read.xlsx(
    audit_path,
    sheet = sheet_name,
    startRow = 2,
    check.names = FALSE,
    na.strings = c("", "NA")
  )
}

clean_empty_rows <- function(data) {
  if (nrow(data) == 0) return(data)

  keep <- apply(
    data,
    1,
    function(x) {
      any(
        !is.na(x) &
          trimws(as.character(x)) != ""
      )
    }
  )

  data[keep, , drop = FALSE]
}

format_p_value <- function(x) {
  numeric_x <- suppressWarnings(as.numeric(x))

  ifelse(
    is.na(numeric_x),
    "",
    ifelse(
      numeric_x < 0.001,
      "<0.001",
      sprintf("%.3f", numeric_x)
    )
  )
}

format_fixed <- function(x, digits = 3) {
  numeric_x <- suppressWarnings(as.numeric(x))

  ifelse(
    is.na(numeric_x),
    "",
    formatC(
      numeric_x,
      digits = digits,
      format = "f"
    )
  )
}

format_ci <- function(lower, upper, digits = 3) {
  paste0(
    format_fixed(lower, digits),
    "-",
    format_fixed(upper, digits)
  )
}

title_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 13,
  textDecoration = "bold",
  halign = "left",
  valign = "center",
  fontColour = "#FFFFFF",
  fgFill = "#1D3557",
  wrapText = TRUE
)

section_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 11,
  textDecoration = "bold",
  halign = "left",
  valign = "center",
  fgFill = "#DCEAF4",
  fontColour = "#000000",
  wrapText = TRUE
)

header_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  textDecoration = "bold",
  halign = "center",
  valign = "center",
  fgFill = "#E9ECEF",
  border = "TopBottomLeftRight",
  borderColour = "#808080",
  wrapText = TRUE
)

body_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  valign = "center",
  border = "TopBottomLeftRight",
  borderColour = "#B8B8B8",
  wrapText = TRUE
)

note_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 9,
  textDecoration = "italic",
  fontColour = "#4A4A4A",
  wrapText = TRUE,
  valign = "top"
)

percent_style <- createStyle(
  numFmt = "0.0%",
  fontName = "Times New Roman",
  fontSize = 10
)

decimal3_style <- createStyle(
  numFmt = "0.000",
  fontName = "Times New Roman",
  fontSize = 10
)

integer_style <- createStyle(
  numFmt = "#,##0",
  fontName = "Times New Roman",
  fontSize = 10
)

add_title <- function(
  wb,
  sheet,
  title,
  n_cols
) {
  writeData(
    wb,
    sheet,
    x = title,
    startRow = 1,
    startCol = 1,
    colNames = FALSE
  )

  if (n_cols > 1) {
    mergeCells(
      wb,
      sheet,
      cols = 1:n_cols,
      rows = 1
    )
  }

  addStyle(
    wb,
    sheet,
    style = title_style,
    rows = 1,
    cols = 1:n_cols,
    gridExpand = TRUE
  )

  setRowHeights(
    wb,
    sheet,
    rows = 1,
    heights = 30
  )
}

write_section <- function(
  wb,
  sheet,
  title,
  data,
  start_row,
  note = NULL
) {
  data <- clean_empty_rows(data)
  n_cols <- max(1, ncol(data))

  writeData(
    wb,
    sheet,
    x = title,
    startRow = start_row,
    startCol = 1,
    colNames = FALSE
  )

  if (n_cols > 1) {
    mergeCells(
      wb,
      sheet,
      cols = 1:n_cols,
      rows = start_row
    )
  }

  addStyle(
    wb,
    sheet,
    style = section_style,
    rows = start_row,
    cols = 1:n_cols,
    gridExpand = TRUE
  )

  header_row <- start_row + 1
  data_row <- start_row + 2

  writeData(
    wb,
    sheet,
    x = data,
    startRow = header_row,
    startCol = 1,
    colNames = TRUE,
    rowNames = FALSE,
    keepNA = FALSE
  )

  addStyle(
    wb,
    sheet,
    style = header_style,
    rows = header_row,
    cols = 1:n_cols,
    gridExpand = TRUE
  )

  if (nrow(data) > 0) {
    addStyle(
      wb,
      sheet,
      style = body_style,
      rows = data_row:(data_row + nrow(data) - 1),
      cols = 1:n_cols,
      gridExpand = TRUE
    )
  }

  next_row <- data_row + nrow(data)

  if (!is.null(note) && nzchar(note)) {
    writeData(
      wb,
      sheet,
      x = paste0("Note: ", note),
      startRow = next_row + 1,
      startCol = 1,
      colNames = FALSE
    )

    if (n_cols > 1) {
      mergeCells(
        wb,
        sheet,
        cols = 1:n_cols,
        rows = next_row + 1
      )
    }

    addStyle(
      wb,
      sheet,
      style = note_style,
      rows = next_row + 1,
      cols = 1:n_cols,
      gridExpand = TRUE
    )

    next_row <- next_row + 2
  }

  next_row + 2
}

format_sheet <- function(
  wb,
  sheet,
  text_columns = NULL,
  narrow_columns = NULL
) {
  freezePane(
    wb,
    sheet,
    firstActiveRow = 3,
    firstActiveCol = 1
  )

  pageSetup(
    wb,
    sheet,
    orientation = "landscape",
    fitToWidth = 1,
    fitToHeight = 0,
    paperSize = 9
  )

  setColWidths(
    wb,
    sheet,
    cols = 1:40,
    widths = 13
  )

  if (!is.null(text_columns)) {
    setColWidths(
      wb,
      sheet,
      cols = text_columns,
      widths = 30
    )
  }

  if (!is.null(narrow_columns)) {
    setColWidths(
      wb,
      sheet,
      cols = narrow_columns,
      widths = 10
    )
  }
}

# ------------------------------------------------------------
# 2. READ AGGREGATED OUTPUTS
# ------------------------------------------------------------

selection_flow <- read_audit_sheet("Selection_flow")
outcome_summary <- read_audit_sheet("Outcome_summary")
key_missingness <- read_audit_sheet("Key_missingness")
cohort_summary <- read_audit_sheet("Cohort_summary")

table_lnm <- read_audit_sheet("Table2_LNM_vs_nonLNM")
subgroup_rates <- read_audit_sheet("LNM_rate_subgroup")

candidate_models <- read_audit_sheet("Candidate_models")
delong_comparison <- read_audit_sheet("Delong_comparison")
race_removal <- read_audit_sheet("Race_removal_test")
model_audit <- read_audit_sheet("Model_definition_audit")
nonlinearity <- read_audit_sheet("Nonlinearity_tests")

primary_spec <- read_audit_sheet("Primary_model_spec")
primary_coefficients <- read_audit_sheet("Primary_coefficients")
rcs_knots <- read_audit_sheet("RCS_knots")
factor_references <- read_audit_sheet("Factor_references")

final_performance <- read_audit_sheet("Final_performance")
optimism_corrected <- read_audit_sheet("Optimism_corrected")
risk_distribution <- read_audit_sheet("Risk_distribution")
optimal_cutoff <- read_audit_sheet("Optimal_cutoff")

calibration_deciles <- read_audit_sheet("Calibration_deciles")
threshold_performance <- read_audit_sheet("Threshold_performance")
sensitivity <- read_audit_sheet("Sensitivity")

pni_status <- read_audit_sheet("PNI_status")
pni_rates <- read_audit_sheet("PNI_LNM_rates")
pni_or <- read_audit_sheet("PNI_adjusted_OR")
pni_incremental <- read_audit_sheet("PNI_incremental")
pni_interaction <- read_audit_sheet("PNI_period_interaction")

# ------------------------------------------------------------
# 3. PRESENTATION CLEANING
# ------------------------------------------------------------

if ("P_value" %in% names(primary_coefficients)) {
  primary_coefficients$P_value <-
    format_p_value(primary_coefficients$P_value)
}

spline_term <- grepl(
  "^age('{1,2})?$|^tumor_size_mm('{1,2})?$",
  primary_coefficients$Term
)

primary_coefficients$Note <- ifelse(
  spline_term,
  paste0(
    "Spline-basis coefficient for exact reproduction; ",
    "not interpretable as a simple one-unit odds ratio."
  ),
  "Computational coefficient relative to the stated reference level."
)

if ("Exp_coefficient" %in% names(primary_coefficients)) {
  primary_coefficients$Exp_coefficient[
    spline_term
  ] <- NA
}

# Explicitly correct T stage note
primary_coefficients$Note[
  primary_coefficients$Term == "t_stage=T2"
] <- "Computational coefficient relative to T1."

# Race reference is exploratory only
if ("Variable" %in% names(factor_references)) {
  factor_references$Use <- ifelse(
    factor_references$Variable == "race_model",
    "Exploratory race-inclusive model only",
    "Primary race-free model"
  )
}

if ("P_value" %in% names(pni_or)) {
  pni_or$P_value <- format_p_value(pni_or$P_value)
}

if ("P_value" %in% names(pni_interaction)) {
  pni_interaction$P_value <-
    format_p_value(pni_interaction$P_value)
}

if ("DeLong_P_value" %in% names(pni_incremental)) {
  pni_incremental$DeLong_P_value <-
    format_p_value(pni_incremental$DeLong_P_value)
}

# Compact model-comparison table
candidate_compact <- candidate_models

keep_candidate <- intersect(
  c(
    "Model",
    "Development_AUC",
    "Development_AUC_lower",
    "Development_AUC_upper",
    "Validation_AUC",
    "Validation_AUC_lower",
    "Validation_AUC_upper",
    "Validation_Brier",
    "Validation_calibration_intercept",
    "Validation_calibration_slope"
  ),
  names(candidate_compact)
)

candidate_compact <- candidate_compact[, keep_candidate, drop = FALSE]

# Compact bootstrap table
bootstrap_keep_metrics <- c(
  "Dxy",
  "R2",
  "Intercept",
  "Slope",
  "Emax",
  "B",
  "C-statistic derived from Dxy"
)

bootstrap_compact <- optimism_corrected[
  optimism_corrected$Metric %in% bootstrap_keep_metrics,
  ,
  drop = FALSE
]

bootstrap_keep <- intersect(
  c(
    "Metric",
    "index.orig",
    "optimism",
    "index.corrected",
    "n"
  ),
  names(bootstrap_compact)
)

bootstrap_compact <- bootstrap_compact[, bootstrap_keep, drop = FALSE]

metric_labels <- c(
  "Dxy" = "Somers' Dxy",
  "R2" = "R-squared",
  "Intercept" = "Calibration intercept",
  "Slope" = "Calibration slope",
  "Emax" = "Maximum calibration error (Emax)",
  "B" = "Brier score",
  "C-statistic derived from Dxy" = "C-statistic"
)

bootstrap_compact$Metric <- unname(
  metric_labels[bootstrap_compact$Metric]
)

# Compact PNI tables
pni_rates_compact <- pni_rates
pni_incremental_compact <- pni_incremental

# ------------------------------------------------------------
# 4. CREATE PUBLICATION-READY WORKBOOK
# ------------------------------------------------------------

wb <- createWorkbook(
  creator = "V2.2 supplementary formatting patch"
)

# README
addWorksheet(wb, "README")
readme <- data.frame(
  Item = c(
    "Purpose",
    "Primary analysis",
    "Supplementary structure",
    "Patient-level data",
    "Analysis integrity",
    "Recommended submission",
    "Version"
  ),
  Description = c(
    "Publication-ready aggregated supplementary tables for the V2.2 analysis.",
    paste0(
      "Race-free RCS logistic model using age, tumor site, histology, ",
      "pathological grade, tumor size, and T stage."
    ),
    paste0(
      "S1 selection/audit; S2 LNM-group characteristics; S3 subgroup LNM rates; ",
      "S4 model comparison; S5 exact model specification; S6 validation; ",
      "S7 calibration; S8 thresholds; S9 sensitivity; S10 PNI."
    ),
    paste0(
      "No patient-level SEER records are included. Do not submit cleaned CSV/RDS ",
      "files unless redistribution is explicitly permitted."
    ),
    "This patch does not refit models or change any numerical result.",
    paste0(
      "Submit this workbook with the supplementary figures. Retain the complete ",
      "audit workbook for internal reproducibility."
    ),
    "V2.2 final supplementary tables"
  ),
  stringsAsFactors = FALSE
)

add_title(
  wb,
  "README",
  "Supplementary Tables - V2.2",
  2
)

writeData(
  wb,
  "README",
  readme,
  startRow = 3,
  colNames = TRUE
)

addStyle(
  wb,
  "README",
  header_style,
  rows = 3,
  cols = 1:2,
  gridExpand = TRUE
)

addStyle(
  wb,
  "README",
  body_style,
  rows = 4:(3 + nrow(readme)),
  cols = 1:2,
  gridExpand = TRUE
)

setColWidths(wb, "README", 1, 24)
setColWidths(wb, "README", 2, 90)
setRowHeights(wb, "README", 4:(3 + nrow(readme)), 42)
pageSetup(
  wb,
  "README",
  orientation = "portrait",
  fitToWidth = 1,
  fitToHeight = 1
)

# S1
addWorksheet(wb, "Table_S1_Selection")
add_title(
  wb,
  "Table_S1_Selection",
  "Supplementary Table S1. Patient selection and cohort audit",
  max(
    ncol(selection_flow),
    ncol(outcome_summary),
    ncol(key_missingness),
    ncol(cohort_summary)
  )
)

next_row <- 3
next_row <- write_section(
  wb,
  "Table_S1_Selection",
  "S1A. Sequential patient selection",
  selection_flow,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S1_Selection",
  "S1B. Outcome distribution",
  outcome_summary,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S1_Selection",
  "S1C. Development and temporal-validation cohorts",
  cohort_summary,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S1_Selection",
  "S1D. Missingness in primary-model variables after cohort construction",
  key_missingness,
  next_row,
  note = "All primary-model variables were complete in the final analytic cohort."
)
format_sheet(
  wb,
  "Table_S1_Selection",
  text_columns = c(2)
)

# S2
addWorksheet(wb, "Table_S2_LNM_groups")
add_title(
  wb,
  "Table_S2_LNM_groups",
  "Supplementary Table S2. Detailed characteristics by pathological LNM status",
  ncol(table_lnm)
)
writeData(
  wb,
  "Table_S2_LNM_groups",
  table_lnm,
  startRow = 3,
  colNames = TRUE
)
addStyle(
  wb,
  "Table_S2_LNM_groups",
  header_style,
  rows = 3,
  cols = 1:ncol(table_lnm),
  gridExpand = TRUE
)
addStyle(
  wb,
  "Table_S2_LNM_groups",
  body_style,
  rows = 4:(3 + nrow(table_lnm)),
  cols = 1:ncol(table_lnm),
  gridExpand = TRUE
)
format_sheet(
  wb,
  "Table_S2_LNM_groups",
  text_columns = c(1, 2)
)

# S3
addWorksheet(wb, "Table_S3_Subgroup_rates")
add_title(
  wb,
  "Table_S3_Subgroup_rates",
  "Supplementary Table S3. Observed LNM rates across clinicopathological subgroups",
  ncol(subgroup_rates)
)
writeData(
  wb,
  "Table_S3_Subgroup_rates",
  subgroup_rates,
  startRow = 3,
  colNames = TRUE
)
addStyle(
  wb,
  "Table_S3_Subgroup_rates",
  header_style,
  rows = 3,
  cols = 1:ncol(subgroup_rates),
  gridExpand = TRUE
)
addStyle(
  wb,
  "Table_S3_Subgroup_rates",
  body_style,
  rows = 4:(3 + nrow(subgroup_rates)),
  cols = 1:ncol(subgroup_rates),
  gridExpand = TRUE
)
format_sheet(
  wb,
  "Table_S3_Subgroup_rates",
  text_columns = c(1, 2)
)

# S4
addWorksheet(wb, "Table_S4_Model_compare")
add_title(
  wb,
  "Table_S4_Model_compare",
  "Supplementary Table S4. Candidate-model performance and model simplification",
  max(
    ncol(candidate_compact),
    ncol(delong_comparison),
    ncol(race_removal),
    ncol(model_audit),
    ncol(nonlinearity)
  )
)
next_row <- 3
next_row <- write_section(
  wb,
  "Table_S4_Model_compare",
  "S4A. Candidate-model performance",
  candidate_compact,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S4_Model_compare",
  "S4B. Paired DeLong comparisons in temporal validation",
  delong_comparison,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S4_Model_compare",
  "S4C. Direct race-removal comparison",
  race_removal,
  next_row,
  note = paste0(
    "The race-inclusive model was exploratory. The race-free RCS model ",
    "was retained as the primary model."
  )
)
next_row <- write_section(
  wb,
  "Table_S4_Model_compare",
  "S4D. Model-definition audit",
  model_audit,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S4_Model_compare",
  "S4E. Overall and nonlinear Wald tests",
  nonlinearity,
  next_row
)
format_sheet(
  wb,
  "Table_S4_Model_compare",
  text_columns = c(1, 2, 3)
)

# S5
addWorksheet(wb, "Table_S5_Model_spec")
add_title(
  wb,
  "Table_S5_Model_spec",
  "Supplementary Table S5. Exact specification of the primary race-free RCS model",
  max(
    ncol(primary_spec),
    ncol(rcs_knots),
    ncol(factor_references),
    ncol(primary_coefficients)
  )
)
next_row <- 3
next_row <- write_section(
  wb,
  "Table_S5_Model_spec",
  "S5A. Model formula and analytic specification",
  primary_spec,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S5_Model_spec",
  "S5B. Restricted cubic spline knot locations",
  rcs_knots,
  next_row,
  note = "Knots were estimated in the development cohort."
)
next_row <- write_section(
  wb,
  "Table_S5_Model_spec",
  "S5C. Factor reference levels",
  factor_references,
  next_row,
  note = "The race reference applies only to the exploratory race-inclusive model."
)
next_row <- write_section(
  wb,
  "Table_S5_Model_spec",
  "S5D. Computational coefficients",
  primary_coefficients,
  next_row,
  note = paste0(
    "Spline-basis coefficients are supplied for exact reproduction with ",
    "rms::rcs and should not be interpreted as one-unit odds ratios."
  )
)
format_sheet(
  wb,
  "Table_S5_Model_spec",
  text_columns = c(1, 2, 6, 7)
)

# S6
addWorksheet(wb, "Table_S6_Validation")
add_title(
  wb,
  "Table_S6_Validation",
  "Supplementary Table S6. Primary-model performance, internal validation, and risk distribution",
  max(
    ncol(final_performance),
    ncol(bootstrap_compact),
    ncol(risk_distribution),
    ncol(optimal_cutoff)
  )
)
next_row <- 3
next_row <- write_section(
  wb,
  "Table_S6_Validation",
  "S6A. Development and temporal-validation performance",
  final_performance,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S6_Validation",
  "S6B. Bootstrap optimism correction (1,000 repetitions)",
  bootstrap_compact,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S6_Validation",
  "S6C. Distribution of predicted risk",
  risk_distribution,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S6_Validation",
  "S6D. Data-derived Youden cutoff in temporal validation",
  optimal_cutoff,
  next_row,
  note = paste0(
    "The cutoff is descriptive and has not been prospectively validated ",
    "for a treatment decision."
  )
)
format_sheet(
  wb,
  "Table_S6_Validation",
  text_columns = c(1, 2)
)

# S7
addWorksheet(wb, "Table_S7_Calibration")
add_title(
  wb,
  "Table_S7_Calibration",
  "Supplementary Table S7. Calibration by predicted-risk decile in temporal validation",
  ncol(calibration_deciles)
)
writeData(
  wb,
  "Table_S7_Calibration",
  calibration_deciles,
  startRow = 3,
  colNames = TRUE
)
addStyle(
  wb,
  "Table_S7_Calibration",
  header_style,
  rows = 3,
  cols = 1:ncol(calibration_deciles),
  gridExpand = TRUE
)
addStyle(
  wb,
  "Table_S7_Calibration",
  body_style,
  rows = 4:(3 + nrow(calibration_deciles)),
  cols = 1:ncol(calibration_deciles),
  gridExpand = TRUE
)
format_sheet(wb, "Table_S7_Calibration")

# S8
addWorksheet(wb, "Table_S8_Thresholds")
add_title(
  wb,
  "Table_S8_Thresholds",
  "Supplementary Table S8. Classification metrics at prespecified risk thresholds",
  ncol(threshold_performance)
)
writeData(
  wb,
  "Table_S8_Thresholds",
  threshold_performance,
  startRow = 3,
  colNames = TRUE
)
addStyle(
  wb,
  "Table_S8_Thresholds",
  header_style,
  rows = 3,
  cols = 1:ncol(threshold_performance),
  gridExpand = TRUE
)
addStyle(
  wb,
  "Table_S8_Thresholds",
  body_style,
  rows = 4:(3 + nrow(threshold_performance)),
  cols = 1:ncol(threshold_performance),
  gridExpand = TRUE
)

note_row <- 4 + nrow(threshold_performance)
writeData(
  wb,
  "Table_S8_Thresholds",
  paste0(
    "Note: Thresholds are descriptive. No threshold has been prospectively ",
    "validated for a specific treatment decision."
  ),
  startRow = note_row,
  colNames = FALSE
)
mergeCells(
  wb,
  "Table_S8_Thresholds",
  cols = 1:ncol(threshold_performance),
  rows = note_row
)
addStyle(
  wb,
  "Table_S8_Thresholds",
  note_style,
  rows = note_row,
  cols = 1:ncol(threshold_performance),
  gridExpand = TRUE
)
format_sheet(wb, "Table_S8_Thresholds")

# S9
addWorksheet(wb, "Table_S9_Sensitivity")
add_title(
  wb,
  "Table_S9_Sensitivity",
  "Supplementary Table S9. Sensitivity analyses of the primary race-free model",
  ncol(sensitivity)
)
writeData(
  wb,
  "Table_S9_Sensitivity",
  sensitivity,
  startRow = 3,
  colNames = TRUE
)
addStyle(
  wb,
  "Table_S9_Sensitivity",
  header_style,
  rows = 3,
  cols = 1:ncol(sensitivity),
  gridExpand = TRUE
)
addStyle(
  wb,
  "Table_S9_Sensitivity",
  body_style,
  rows = 4:(3 + nrow(sensitivity)),
  cols = 1:ncol(sensitivity),
  gridExpand = TRUE
)
format_sheet(
  wb,
  "Table_S9_Sensitivity",
  text_columns = c(1, 18, 19)
)

# S10
addWorksheet(wb, "Table_S10_PNI")
add_title(
  wb,
  "Table_S10_PNI",
  "Supplementary Table S10. Exploratory perineural-invasion analyses",
  max(
    ncol(pni_status),
    ncol(pni_rates_compact),
    ncol(pni_or),
    ncol(pni_incremental_compact),
    ncol(pni_interaction)
  )
)
next_row <- 3
next_row <- write_section(
  wb,
  "Table_S10_PNI",
  "S10A. PNI completeness",
  pni_status,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S10_PNI",
  "S10B. Observed LNM rates by PNI status",
  pni_rates_compact,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S10_PNI",
  "S10C. Adjusted PNI association in the pooled PNI-known cohort",
  pni_or,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S10_PNI",
  "S10D. Incremental prediction analysis",
  pni_incremental_compact,
  next_row
)
next_row <- write_section(
  wb,
  "Table_S10_PNI",
  "S10E. PNI-by-period interaction",
  pni_interaction,
  next_row,
  note = paste0(
    "PNI analyses used the exploratory race-inclusive complete model in ",
    "the PNI-known subset. Unknown or unassessed PNI was not classified as absent."
  )
)
format_sheet(
  wb,
  "Table_S10_PNI",
  text_columns = c(1, 2, 15, 16, 17, 37, 39)
)

# ------------------------------------------------------------
# 5. FINAL WORKBOOK SETTINGS AND EXPORT
# ------------------------------------------------------------

for (sheet_name in names(wb)) {
  showGridLines(
    wb,
    sheet = sheet_name,
    showGridLines = FALSE
  )
}

saveWorkbook(
  wb,
  output_path,
  overwrite = TRUE
)

writeLines(
  c(
    "V2.2 final supplementary formatting patch completed.",
    paste0("Generated: ", Sys.time()),
    paste0("Input audit workbook: ", audit_path),
    paste0("Output workbook: ", output_path),
    "No model was refitted.",
    "No patient-level SEER records were exported.",
    paste0(
      "Correction applied: t_stage=T2 is a standard categorical coefficient, ",
      "not a spline-basis coefficient."
    ),
    paste0(
      "Presentation applied: major mixed tables were separated into ",
      "publication-readable subsections."
    )
  ),
  con = log_path
)

cat(
  "\n====================================================\n",
  "FINAL SUPPLEMENTARY TABLES COMPLETED\n",
  "Output: ", output_path, "\n",
  "Log: ", log_path, "\n",
  "No model was refitted.\n",
  "====================================================\n",
  sep = ""
)
