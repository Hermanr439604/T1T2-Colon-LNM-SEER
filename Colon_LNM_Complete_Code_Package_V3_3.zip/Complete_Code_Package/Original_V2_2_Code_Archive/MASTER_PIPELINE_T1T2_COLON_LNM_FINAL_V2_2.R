
# ============================================================
# MASTER PIPELINE V2.2
# T1-T2 colon adenocarcinoma and lymph node metastasis
# Final main cohort excludes tumor size >150 mm
# Primary model: race-free parsimonious RCS logistic model
# Exploratory secondary model: otherwise identical race-inclusive RCS model
# PNI analysis: exploratory secondary analysis in the PNI-known subset
#
# Output strategy:
#   01_raw_data
#   02_clean_data
#   03_tables
#   04_figures_all
#   05_manuscript_figures
#   06_supplementary_figures
#   07_logs
#   08_models
#
# Recommended execution:
#   Open this file in RStudio and run from top to bottom.
# ============================================================

rm(list = ls())
gc()

options(stringsAsFactors = FALSE)
options(scipen = 999)

# ------------------------------------------------------------
# PART 0. USER SETTINGS
# ------------------------------------------------------------

project_dir <- "C:/Users/Administrator/Desktop/Final_Colon"

raw_csv_name <- "SEER_T1T2_colon_LNM_2018_2022_PNI_raw.csv"

analysis_version <- "V2_2"
output_root <- file.path(
  project_dir,
  paste0("Outputs_", analysis_version)
)

bootstrap_repetitions <- 1000

# CEA is not part of the manuscript's main analysis. It is retained only
# as an optional exploratory module and is off by default.
run_optional_cea_analysis <- FALSE

# PNI is analysed only as an exploratory secondary variable because it is
# not part of the prespecified race-free primary model.
run_pni_analysis <- TRUE

set.seed(20260715)

# ------------------------------------------------------------
# PART 0.1. PACKAGES
# ------------------------------------------------------------

required_packages <- c(
  "readr",
  "dplyr",
  "tidyr",
  "stringr",
  "forcats",
  "tableone",
  "broom",
  "rms",
  "splines",
  "pROC",
  "ggplot2",
  "patchwork",
  "openxlsx",
  "scales"
)

missing_packages <- required_packages[
  !required_packages %in% rownames(installed.packages())
]

if (length(missing_packages) > 0) {
  install.packages(
    missing_packages,
    dependencies = TRUE
  )
}

library(readr)
library(dplyr)
library(tidyr)
library(stringr)
library(forcats)
library(tableone)
library(broom)
library(rms)
library(splines)
library(pROC)
library(ggplot2)
library(patchwork)
library(openxlsx)
library(scales)

# ------------------------------------------------------------
# PART 0.2. PROJECT FOLDERS
# ------------------------------------------------------------

if (!dir.exists(project_dir)) {
  stop("Project directory does not exist: ", project_dir)
}

raw_csv_path <- file.path(project_dir, raw_csv_name)

if (!file.exists(raw_csv_path)) {
  stop(
    "Raw CSV was not found. Expected path:\n",
    raw_csv_path
  )
}

# V2.2 writes to an isolated output root so that no V2.1 table or figure
# can be mistaken for a newly generated race-free primary-model result.
dir.create(
  output_root,
  showWarnings = FALSE,
  recursive = TRUE
)

output_dirs <- c(
  "01_raw_data",
  "02_clean_data",
  "03_tables",
  "04_figures_all",
  "05_manuscript_figures",
  "06_supplementary_figures",
  "07_logs",
  "08_models"
)

for (directory_name in output_dirs) {
  dir.create(
    file.path(output_root, directory_name),
    showWarnings = FALSE,
    recursive = TRUE
  )
}

setwd(output_root)

# ------------------------------------------------------------
# PART 0.3. PUBLICATION THEME AND PALETTE
# ------------------------------------------------------------

font_family <- "serif"

palette_main <- c(
  navy = "#1D3557",
  blue = "#457B9D",
  teal = "#2A9D8F",
  vermilion = "#C23B22",
  gold = "#C99700",
  charcoal = "#4A4A4A",
  gray = "#7A7A7A",
  light_blue = "#DCEAF4",
  light_gray = "#E9ECEF"
)

theme_publication <- function(base_size = 12) {
  theme_classic(
    base_size = base_size,
    base_family = font_family
  ) +
    theme(
      plot.title = element_text(
        face = "bold",
        hjust = 0.5,
        size = base_size + 2
      ),
      plot.subtitle = element_text(
        hjust = 0.5,
        color = palette_main["charcoal"],
        size = base_size
      ),
      axis.title = element_text(
        face = "bold",
        size = base_size
      ),
      axis.text = element_text(
        color = "black",
        size = base_size - 1
      ),
      legend.title = element_blank(),
      legend.position = "bottom",
      legend.text = element_text(
        size = base_size - 1
      ),
      strip.background = element_blank(),
      strip.text = element_text(
        face = "bold"
      ),
      plot.margin = margin(10, 12, 10, 10)
    )
}

save_ggplot_all_formats <- function(
  plot_object,
  output_stub,
  width,
  height,
  dpi = 600
) {
  ggsave(
    filename = paste0(output_stub, ".pdf"),
    plot = plot_object,
    width = width,
    height = height,
    bg = "white"
  )

  ggsave(
    filename = paste0(output_stub, ".png"),
    plot = plot_object,
    width = width,
    height = height,
    dpi = dpi,
    bg = "white"
  )

  ggsave(
    filename = paste0(output_stub, ".tiff"),
    plot = plot_object,
    width = width,
    height = height,
    dpi = dpi,
    device = "tiff",
    compression = "lzw",
    bg = "white"
  )
}

copy_figure_set <- function(
  source_stub,
  destination_directory,
  destination_base
) {
  for (extension in c("pdf", "png", "tiff")) {
    source_file <- paste0(source_stub, ".", extension)
    destination_file <- file.path(
      destination_directory,
      paste0(destination_base, ".", extension)
    )

    if (file.exists(source_file)) {
      file.copy(
        from = source_file,
        to = destination_file,
        overwrite = TRUE
      )
    }
  }
}

# ------------------------------------------------------------
# PART 1. IMPORT AND AUDIT RAW DATA
# ------------------------------------------------------------

seer_raw_original <- read_csv(
  file = raw_csv_path,
  col_types = cols(.default = col_character()),
  na = c("", "NA"),
  trim_ws = TRUE,
  show_col_types = FALSE,
  name_repair = "unique"
)

cat(
  "\nRaw records:", nrow(seer_raw_original),
  "\nRaw variables:", ncol(seer_raw_original),
  "\nCompletely duplicated rows:",
  sum(duplicated(seer_raw_original)),
  "\n"
)

rename_map <- c(
  "Patient ID" = "patient_id",
  "Age recode with <1 year olds and 90+" = "age_group_5y_raw",
  "Age recode with single ages and 90+" = "age_single_raw",
  "Sequence number" = "sequence_number",
  "First malignant primary indicator" = "first_malignant_primary",
  "Year of diagnosis" = "year_dx_raw",
  "Sex" = "sex_raw",
  "Race recode (W, B, AI, API)" = "race_raw",
  "Origin recode NHIA (Hispanic, Non-Hisp)" = "hispanic_origin_raw",
  "Race and origin recode (NHW, NHB, NHAIAN, NHAPI, Hispanic)" = "race_origin_raw",
  "Marital status at diagnosis" = "marital_status_raw",
  "Primary Site - labeled" = "primary_site_raw",
  "Site recode ICD-O-3/WHO 2008" = "site_recode_raw",
  "Histologic Type ICD-O-3" = "histology_code_raw",
  "Grade Clinical (2018+)" = "grade_clinical_raw",
  "Grade Pathological (2018+)" = "grade_pathological_raw",
  "Tumor Size Summary (2016+)" = "tumor_size_raw",
  "Derived EOD 2018 T Recode (2018+)" = "t_stage_raw",
  "Derived EOD 2018 N Recode (2018+)" = "n_stage_raw",
  "Derived EOD 2018 M Recode (2018+)" = "m_stage_raw",
  "Derived EOD 2018 Stage Group Recode (2018+)" = "stage_group_raw",
  "Regional nodes examined (1988+)" = "nodes_examined_raw",
  "Regional nodes positive (1988+)" = "nodes_positive_raw",
  "RX Summ--Surg Prim Site (1998+)" = "surgery_primary_raw",
  "Reason no cancer-directed surgery" = "reason_no_surgery_raw",
  "Radiation recode" = "radiation_raw",
  "Chemotherapy recode (yes, no/unk)" = "chemotherapy_raw",
  "CEA Pretreatment Interpretation Recode (2010+)" = "cea_raw",
  "CA-125 Pretreatment Interpretation Recode (2010+)" = "ca125_raw",
  "Tumor Deposits Recode (2010+)" = "tumor_deposits_raw",
  "Perineural Invasion Recode (2010+)" = "pni_raw",
  "Survival months" = "survival_months_raw",
  "Vital status recode (study cutoff used)" = "vital_status_raw",
  "SEER cause-specific death classification" = "cause_specific_death_raw"
)

seer_raw <- seer_raw_original

for (old_name in names(rename_map)) {
  if (old_name %in% names(seer_raw)) {
    names(seer_raw)[names(seer_raw) == old_name] <- rename_map[[old_name]]
  }
}

required_raw_variables <- c(
  "patient_id",
  "age_single_raw",
  "first_malignant_primary",
  "year_dx_raw",
  "sex_raw",
  "race_raw",
  "marital_status_raw",
  "primary_site_raw",
  "histology_code_raw",
  "grade_pathological_raw",
  "tumor_size_raw",
  "t_stage_raw",
  "n_stage_raw",
  "m_stage_raw",
  "nodes_examined_raw",
  "nodes_positive_raw",
  "surgery_primary_raw",
  "pni_raw"
)

missing_required_variables <- setdiff(
  required_raw_variables,
  names(seer_raw)
)

if (length(missing_required_variables) > 0) {
  stop(
    "The following required variables are missing:\n",
    paste(missing_required_variables, collapse = ", ")
  )
}

variable_dictionary <- data.frame(
  variable_order = seq_along(names(seer_raw_original)),
  original_variable = names(seer_raw_original),
  analysis_variable = names(seer_raw),
  stringsAsFactors = FALSE
)

value_examples <- lapply(names(seer_raw), function(variable_name) {
  current_values <- unique(
    na.omit(
      as.character(seer_raw[[variable_name]])
    )
  )

  data.frame(
    variable = variable_name,
    unique_value_n = length(current_values),
    example_values = paste(
      head(current_values, 20),
      collapse = " | "
    ),
    stringsAsFactors = FALSE
  )
}) %>%
  bind_rows()

audit_summary <- lapply(names(seer_raw), function(variable_name) {
  current_values <- as.character(seer_raw[[variable_name]])

  data.frame(
    variable = variable_name,
    total_n = length(current_values),
    native_na_n = sum(is.na(current_values)),
    unique_value_n = length(unique(na.omit(current_values))),
    stringsAsFactors = FALSE
  )
}) %>%
  bind_rows() %>%
  mutate(
    native_na_percent = round(
      native_na_n / total_n * 100,
      2
    )
  )

saveRDS(
  seer_raw_original,
  file.path(
    "01_raw_data",
    "SEER_T1T2_colon_LNM_raw_original.rds"
  )
)

saveRDS(
  seer_raw,
  file.path(
    "01_raw_data",
    "SEER_T1T2_colon_LNM_raw_renamed.rds"
  )
)

write.xlsx(
  list(
    Variable_dictionary = variable_dictionary,
    Value_examples = value_examples,
    Native_missingness = audit_summary
  ),
  file = file.path(
    "07_logs",
    "01_initial_raw_data_audit.xlsx"
  ),
  overwrite = TRUE
)

# ------------------------------------------------------------
# PART 2. FINAL COHORT CLEANING
# Main model rule: tumor size must be 1-150 mm.
# A pre-150-mm dataset is retained for sensitivity analysis.
# ------------------------------------------------------------

extract_site_code <- function(x) {
  str_extract(
    string = as.character(x),
    pattern = "^C18\\.[0-9]"
  )
}

seer_work <- seer_raw %>%
  mutate(
    row_id = row_number(),

    year_dx = suppressWarnings(
      as.integer(year_dx_raw)
    ),

    age = case_when(
      str_detect(age_single_raw, "^90\\+") ~ 90,
      TRUE ~ parse_number(age_single_raw)
    ),

    primary_site_code = extract_site_code(
      primary_site_raw
    ),

    histology_code = suppressWarnings(
      as.integer(histology_code_raw)
    ),

    surgery_code = suppressWarnings(
      as.integer(surgery_primary_raw)
    ),

    nodes_examined = suppressWarnings(
      as.integer(nodes_examined_raw)
    ),

    nodes_positive = suppressWarnings(
      as.integer(nodes_positive_raw)
    ),

    tumor_size_mm = suppressWarnings(
      as.integer(tumor_size_raw)
    ),

    grade_path_n = case_when(
      grade_pathological_raw %in% c(
        "1", "2", "3", "4"
      ) ~ as.integer(grade_pathological_raw),
      TRUE ~ NA_integer_
    ),

    t_stage = case_when(
      str_starts(t_stage_raw, "T1") ~ "T1",
      str_starts(t_stage_raw, "T2") ~ "T2",
      TRUE ~ NA_character_
    ),

    m_stage = case_when(
      m_stage_raw %in% c("M0", "M0(i+)") ~ "M0",
      TRUE ~ NA_character_
    )
  )

selection_flow <- tibble(
  step_order = 0L,
  selection_step = paste0(
    "SEER records after database-level selection",
    "\n(2018-2022, T1-T2, M0 colon cancer)"
  ),
  remaining_n = nrow(seer_work)
)

add_flow_step <- function(
  flow_object,
  data_object,
  step_order,
  step_name
) {
  bind_rows(
    flow_object,
    tibble(
      step_order = as.integer(step_order),
      selection_step = step_name,
      remaining_n = nrow(data_object)
    )
  )
}

eligible_sites <- c(
  "C18.0",
  "C18.2",
  "C18.3",
  "C18.4",
  "C18.5",
  "C18.6",
  "C18.7",
  "C18.8",
  "C18.9"
)

eligible_histologies <- c(
  8140,
  8480,
  8481,
  8490
)

cohort_1 <- seer_work %>%
  filter(
    year_dx %in% 2018:2022,
    primary_site_code %in% eligible_sites,
    t_stage %in% c("T1", "T2"),
    m_stage == "M0"
  )

cohort_2 <- cohort_1 %>%
  filter(
    !is.na(age),
    age >= 18
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_2,
  2,
  "Age 18 years or older"
)

cohort_3 <- cohort_2 %>%
  filter(
    trimws(first_malignant_primary) == "Yes"
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_3,
  3,
  "First malignant primary"
)

cohort_4 <- cohort_3 %>%
  filter(
    histology_code %in% eligible_histologies
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_4,
  4,
  "Eligible adenocarcinoma histology"
)

cohort_5 <- cohort_4 %>%
  filter(
    !is.na(surgery_code),
    between(surgery_code, 20, 90)
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_5,
  5,
  "Surgery of the primary site"
)

cohort_6 <- cohort_5 %>%
  filter(
    !is.na(nodes_examined),
    between(nodes_examined, 1, 90)
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_6,
  6,
  "At least one regional lymph node examined"
)

cohort_7 <- cohort_6 %>%
  filter(
    !is.na(nodes_positive),
    between(nodes_positive, 0, 90)
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_7,
  7,
  "Known number of positive regional lymph nodes"
)

cohort_8 <- cohort_7 %>%
  filter(
    !is.na(tumor_size_mm),
    between(tumor_size_mm, 1, 989)
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_8,
  8,
  "Known tumor size"
)

cohort_pre150 <- cohort_8 %>%
  filter(
    grade_path_n %in% c(1, 2, 3, 4)
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_pre150,
  9,
  "Known pathological grade"
)

cohort_final_raw <- cohort_pre150 %>%
  filter(
    tumor_size_mm <= 150
  )

selection_flow <- add_flow_step(
  selection_flow,
  cohort_final_raw,
  10,
  "Tumor size 1-150 mm"
)

selection_flow <- selection_flow %>%
  arrange(step_order) %>%
  mutate(
    excluded_n = lag(remaining_n) - remaining_n,
    excluded_n = if_else(
      step_order == 0,
      NA_integer_,
      excluded_n
    )
  )

recode_analysis_variables <- function(data) {
  data %>%
    mutate(
      lnm_num = if_else(
        nodes_positive > 0,
        1L,
        0L
      ),

      lnm = factor(
        if_else(
          lnm_num == 1,
          "Yes",
          "No"
        ),
        levels = c("No", "Yes")
      ),

      age_group4 = case_when(
        age < 50 ~ "<50",
        age >= 50 & age <= 64 ~ "50-64",
        age >= 65 & age <= 74 ~ "65-74",
        age >= 75 ~ "75+",
        TRUE ~ NA_character_
      ),

      age_group4 = factor(
        age_group4,
        levels = c(
          "<50",
          "50-64",
          "65-74",
          "75+"
        )
      ),

      sex = factor(
        trimws(sex_raw),
        levels = c(
          "Female",
          "Male"
        )
      ),

      race_group = case_when(
        trimws(race_raw) == "White" ~
          "White",

        trimws(race_raw) == "Black" ~
          "Black",

        trimws(race_raw) ==
          "Asian or Pacific Islander" ~
          "Asian or Pacific Islander",

        trimws(race_raw) ==
          "American Indian/Alaska Native" ~
          "American Indian/Alaska Native",

        TRUE ~ "Unknown"
      ),

      race_group = factor(
        race_group,
        levels = c(
          "White",
          "Black",
          "Asian or Pacific Islander",
          "American Indian/Alaska Native",
          "Unknown"
        )
      ),

      marital_group = case_when(
        trimws(marital_status_raw) ==
          "Married (including common law)" ~
          "Married",

        trimws(marital_status_raw) %in% c(
          "Single (never married)",
          "Divorced",
          "Widowed",
          "Separated",
          "Unmarried or Domestic Partner"
        ) ~ "Unmarried",

        TRUE ~ "Unknown"
      ),

      marital_group = factor(
        marital_group,
        levels = c(
          "Married",
          "Unmarried",
          "Unknown"
        )
      ),

      site_group = case_when(
        primary_site_code %in% c(
          "C18.0",
          "C18.2",
          "C18.3",
          "C18.4"
        ) ~ "Right-sided colon",

        primary_site_code %in% c(
          "C18.5",
          "C18.6",
          "C18.7"
        ) ~ "Left-sided colon",

        primary_site_code %in% c(
          "C18.8",
          "C18.9"
        ) ~ "Overlapping/NOS",

        TRUE ~ NA_character_
      ),

      site_group = factor(
        site_group,
        levels = c(
          "Right-sided colon",
          "Left-sided colon",
          "Overlapping/NOS"
        )
      ),

      histology_group = case_when(
        histology_code == 8140 ~
          "Adenocarcinoma",

        histology_code %in% c(
          8480,
          8481
        ) ~ "Mucinous adenocarcinoma",

        histology_code == 8490 ~
          "Signet-ring cell carcinoma",

        TRUE ~ NA_character_
      ),

      histology_group = factor(
        histology_group,
        levels = c(
          "Adenocarcinoma",
          "Mucinous adenocarcinoma",
          "Signet-ring cell carcinoma"
        )
      ),

      grade_group = case_when(
        grade_path_n %in% c(1, 2) ~
          "Well/moderately differentiated",

        grade_path_n %in% c(3, 4) ~
          "Poorly/undifferentiated",

        TRUE ~ NA_character_
      ),

      grade_group = factor(
        grade_group,
        levels = c(
          "Well/moderately differentiated",
          "Poorly/undifferentiated"
        )
      ),

      tumor_size_group = case_when(
        tumor_size_mm <= 20 ~
          "<=20 mm",

        tumor_size_mm >= 21 &
          tumor_size_mm <= 50 ~
          "21-50 mm",

        tumor_size_mm > 50 ~
          ">50 mm",

        TRUE ~ NA_character_
      ),

      tumor_size_group = factor(
        tumor_size_group,
        levels = c(
          "<=20 mm",
          "21-50 mm",
          ">50 mm"
        )
      ),

      t_stage = factor(
        t_stage,
        levels = c(
          "T1",
          "T2"
        )
      ),

      nodes_examined_adequacy = factor(
        if_else(
          nodes_examined >= 12,
          ">=12",
          "<12"
        ),
        levels = c(
          "<12",
          ">=12"
        )
      ),

      cea_group = case_when(
        str_detect(
          str_to_lower(
            replace_na(cea_raw, "")
          ),
          "negative|normal"
        ) ~ "Negative/normal",

        str_detect(
          str_to_lower(
            replace_na(cea_raw, "")
          ),
          "positive|elevated"
        ) ~ "Positive/elevated",

        TRUE ~ "Unknown/not assessed"
      ),

      cea_group = factor(
        cea_group,
        levels = c(
          "Negative/normal",
          "Positive/elevated",
          "Unknown/not assessed"
        )
      ),

      pni_group = case_when(
        str_detect(
          str_to_lower(
            replace_na(pni_raw, "")
          ),
          "not identified|not present"
        ) ~ "Absent",

        str_detect(
          str_to_lower(
            replace_na(pni_raw, "")
          ),
          "identified|present"
        ) ~ "Present",

        TRUE ~ "Unknown/not assessed"
      ),

      pni_group = factor(
        pni_group,
        levels = c(
          "Absent",
          "Present",
          "Unknown/not assessed"
        )
      )
    )
}

cohort_pre150_analysis <- recode_analysis_variables(
  cohort_pre150
)

cohort_final <- recode_analysis_variables(
  cohort_final_raw
)

# Final cohort integrity checks
if (anyDuplicated(cohort_final$patient_id) > 0) {
  stop("Duplicated patient IDs remain in the final cohort.")
}

if (
  any(
    cohort_final$nodes_positive >
      cohort_final$nodes_examined,
    na.rm = TRUE
  )
) {
  stop(
    "At least one record has more positive lymph nodes than examined lymph nodes."
  )
}

if (
  any(
    cohort_final$tumor_size_mm < 1 |
      cohort_final$tumor_size_mm > 150,
    na.rm = TRUE
  )
) {
  stop("Tumor-size restriction to 1-150 mm was not applied correctly.")
}

key_model_variables <- c(
  "age",
  "race_group",
  "site_group",
  "histology_group",
  "grade_group",
  "tumor_size_mm",
  "t_stage",
  "lnm_num"
)

key_missingness <- cohort_final %>%
  summarise(
    across(
      all_of(key_model_variables),
      ~ sum(is.na(.))
    )
  ) %>%
  pivot_longer(
    cols = everything(),
    names_to = "variable",
    values_to = "missing_n"
  )

if (any(key_missingness$missing_n > 0)) {
  stop(
    "Missing values remain in final model variables."
  )
}

outcome_summary <- tibble(
  Outcome = c(
    "Total cohort",
    "No lymph node metastasis",
    "Lymph node metastasis"
  ),
  N = c(
    nrow(cohort_final),
    sum(cohort_final$lnm_num == 0),
    sum(cohort_final$lnm_num == 1)
  ),
  Percent = c(
    100,
    round(
      mean(cohort_final$lnm_num == 0) * 100,
      2
    ),
    round(
      mean(cohort_final$lnm_num == 1) * 100,
      2
    )
  )
)

saveRDS(
  cohort_pre150_analysis,
  file.path(
    "02_clean_data",
    "SEER_T1T2_colon_LNM_pre150_sensitivity_cohort.rds"
  )
)

saveRDS(
  cohort_final,
  file.path(
    "02_clean_data",
    "SEER_T1T2_colon_LNM_final_analysis_cohort.rds"
  )
)

write_csv(
  cohort_final,
  file.path(
    "02_clean_data",
    "SEER_T1T2_colon_LNM_final_analysis_cohort.csv"
  ),
  na = ""
)

write.xlsx(
  list(
    Selection_flow = selection_flow,
    Outcome_summary = outcome_summary,
    Key_missingness = key_missingness
  ),
  file = file.path(
    "07_logs",
    "02_final_cohort_cleaning_audit.xlsx"
  ),
  overwrite = TRUE
)

cat(
  "\nFinal cohort:", nrow(cohort_final),
  "\nLNM events:", sum(cohort_final$lnm_num == 1),
  "\nLNM rate:",
  round(mean(cohort_final$lnm_num == 1) * 100, 2),
  "%\n"
)

# ------------------------------------------------------------
# PART 3. TEMPORAL SPLIT AND DESCRIPTIVE TABLES
# ------------------------------------------------------------

seer_split <- cohort_final %>%
  mutate(
    cohort = case_when(
      year_dx %in% 2018:2021 ~
        "Development cohort (2018-2021)",

      year_dx == 2022 ~
        "Temporal validation cohort (2022)",

      TRUE ~ NA_character_
    ),

    cohort = factor(
      cohort,
      levels = c(
        "Development cohort (2018-2021)",
        "Temporal validation cohort (2022)"
      )
    )
  )

if (any(is.na(seer_split$cohort))) {
  stop(
    "Some records could not be assigned to a cohort."
  )
}

development_data <- seer_split %>%
  filter(
    cohort ==
      "Development cohort (2018-2021)"
  ) %>%
  droplevels()

validation_data <- seer_split %>%
  filter(
    cohort ==
      "Temporal validation cohort (2022)"
  ) %>%
  droplevels()

if (
  length(
    intersect(
      development_data$patient_id,
      validation_data$patient_id
    )
  ) > 0
) {
  stop(
    "Development and validation cohorts contain overlapping patient IDs."
  )
}

cohort_summary <- seer_split %>%
  group_by(cohort) %>%
  summarise(
    total_n = n(),
    lnm_n = sum(lnm_num == 1),
    non_lnm_n = sum(lnm_num == 0),
    lnm_percent = round(
      mean(lnm_num == 1) * 100,
      2
    ),
    .groups = "drop"
  )

annual_distribution <- seer_split %>%
  group_by(year_dx) %>%
  summarise(
    total_n = n(),
    lnm_n = sum(lnm_num == 1),
    lnm_percent = round(
      mean(lnm_num == 1) * 100,
      2
    ),
    .groups = "drop"
  )

table1_variables <- c(
  "age",
  "sex",
  "race_group",
  "marital_group",
  "site_group",
  "histology_group",
  "grade_group",
  "tumor_size_mm",
  "t_stage",
  "nodes_examined",
  "lnm"
)

table1_factor_variables <- c(
  "sex",
  "race_group",
  "marital_group",
  "site_group",
  "histology_group",
  "grade_group",
  "t_stage",
  "lnm"
)

table1_nonnormal_variables <- c(
  "age",
  "tumor_size_mm",
  "nodes_examined"
)

table1_object <- CreateTableOne(
  vars = table1_variables,
  strata = "cohort",
  data = seer_split,
  factorVars = table1_factor_variables,
  addOverall = TRUE,
  test = TRUE
)

table1_matrix <- print(
  table1_object,
  showAllLevels = TRUE,
  nonnormal = table1_nonnormal_variables,
  quote = FALSE,
  noSpaces = TRUE,
  printToggle = FALSE,
  test = TRUE,
  smd = TRUE
)

table1_df <- data.frame(
  Characteristic = rownames(table1_matrix),
  table1_matrix,
  row.names = NULL,
  check.names = FALSE
)

table2_variables <- c(
  "age",
  "sex",
  "race_group",
  "marital_group",
  "site_group",
  "histology_group",
  "grade_group",
  "tumor_size_mm",
  "t_stage",
  "nodes_examined"
)

table2_factor_variables <- c(
  "sex",
  "race_group",
  "marital_group",
  "site_group",
  "histology_group",
  "grade_group",
  "t_stage"
)

table2_object <- CreateTableOne(
  vars = table2_variables,
  strata = "lnm",
  data = seer_split,
  factorVars = table2_factor_variables,
  addOverall = TRUE,
  test = TRUE
)

table2_matrix <- print(
  table2_object,
  showAllLevels = TRUE,
  nonnormal = c(
    "age",
    "tumor_size_mm",
    "nodes_examined"
  ),
  quote = FALSE,
  noSpaces = TRUE,
  printToggle = FALSE,
  test = TRUE,
  smd = TRUE
)

table2_df <- data.frame(
  Characteristic = rownames(table2_matrix),
  table2_matrix,
  row.names = NULL,
  check.names = FALSE
)

make_lnm_rate <- function(
  data,
  variable_name,
  variable_label
) {
  data %>%
    group_by(
      .data[[variable_name]]
    ) %>%
    summarise(
      total_n = n(),
      lnm_n = sum(lnm_num == 1),
      lnm_percent = round(
        mean(lnm_num == 1) * 100,
        2
      ),
      .groups = "drop"
    ) %>%
    mutate(
      Variable = variable_label,
      Level = as.character(
        .data[[variable_name]]
      )
    ) %>%
    select(
      Variable,
      Level,
      total_n,
      lnm_n,
      lnm_percent
    )
}

lnm_rate_by_subgroup <- bind_rows(
  make_lnm_rate(
    seer_split,
    "age_group4",
    "Age group"
  ),
  make_lnm_rate(
    seer_split,
    "sex",
    "Sex"
  ),
  make_lnm_rate(
    seer_split,
    "race_group",
    "Race"
  ),
  make_lnm_rate(
    seer_split,
    "site_group",
    "Tumor site"
  ),
  make_lnm_rate(
    seer_split,
    "histology_group",
    "Histology"
  ),
  make_lnm_rate(
    seer_split,
    "grade_group",
    "Pathological grade"
  ),
  make_lnm_rate(
    seer_split,
    "tumor_size_group",
    "Tumor size"
  ),
  make_lnm_rate(
    seer_split,
    "t_stage",
    "T stage"
  )
)

saveRDS(
  seer_split,
  file.path(
    "02_clean_data",
    "SEER_T1T2_colon_LNM_temporal_split_final.rds"
  )
)

saveRDS(
  development_data,
  file.path(
    "02_clean_data",
    "SEER_T1T2_colon_LNM_development_final.rds"
  )
)

saveRDS(
  validation_data,
  file.path(
    "02_clean_data",
    "SEER_T1T2_colon_LNM_validation_final.rds"
  )
)

write.xlsx(
  list(
    Cohort_summary = cohort_summary,
    Annual_distribution = annual_distribution,
    Table1_dev_vs_val = table1_df,
    Table2_LNM_vs_nonLNM = table2_df,
    LNM_rate_subgroup = lnm_rate_by_subgroup
  ),
  file = file.path(
    "03_tables",
    "01_descriptive_tables_final.xlsx"
  ),
  overwrite = TRUE
)

# ------------------------------------------------------------
# PART 4. MODEL DATA PREPARATION
# ------------------------------------------------------------

prepare_model_data <- function(
  data,
  combine_special_histology = FALSE
) {
  data <- as.data.frame(data)

  data <- data %>%
    mutate(
      age_10 = age / 10,
      tumor_size_10 = tumor_size_mm / 10,

      sex = factor(
        as.character(sex),
        levels = c(
          "Female",
          "Male"
        )
      ),

      race_model = factor(
        as.character(race_group),
        levels = c(
          "White",
          "Black",
          "Asian or Pacific Islander",
          "American Indian/Alaska Native",
          "Unknown"
        )
      ),

      site_model = factor(
        as.character(site_group),
        levels = c(
          "Right-sided colon",
          "Left-sided colon",
          "Overlapping/NOS"
        )
      ),

      grade_model = factor(
        as.character(grade_group),
        levels = c(
          "Well/moderately differentiated",
          "Poorly/undifferentiated"
        )
      ),

      t_stage = factor(
        as.character(t_stage),
        levels = c(
          "T1",
          "T2"
        )
      )
    )

  if (combine_special_histology) {
    data <- data %>%
      mutate(
        histology_model = case_when(
          as.character(histology_group) ==
            "Adenocarcinoma" ~
            "Adenocarcinoma",

          as.character(histology_group) %in% c(
            "Mucinous adenocarcinoma",
            "Signet-ring cell carcinoma"
          ) ~ "Special histology",

          TRUE ~ NA_character_
        ),

        histology_model = factor(
          histology_model,
          levels = c(
            "Adenocarcinoma",
            "Special histology"
          )
        )
      )
  } else {
    data <- data %>%
      mutate(
        histology_model = factor(
          as.character(histology_group),
          levels = c(
            "Adenocarcinoma",
            "Mucinous adenocarcinoma",
            "Signet-ring cell carcinoma"
          )
        )
      )
  }

  data <- droplevels(data)

  required_model_variables <- c(
    "lnm_num",
    "age",
    "age_10",
    "sex",
    "race_model",
    "site_model",
    "histology_model",
    "grade_model",
    "tumor_size_mm",
    "tumor_size_10",
    "t_stage"
  )

  missing_model_values <- sapply(
    data[required_model_variables],
    function(x) sum(is.na(x))
  )

  if (any(missing_model_values > 0)) {
    stop(
      "Missing values were introduced in model preparation: ",
      paste(
        names(
          missing_model_values[
            missing_model_values > 0
          ]
        ),
        collapse = ", "
      )
    )
  }

  label(data$age) <-
    "Age at diagnosis, years"
  label(data$race_model) <-
    "Race"
  label(data$site_model) <-
    "Tumor site"
  label(data$histology_model) <-
    "Histology"
  label(data$grade_model) <-
    "Pathological grade"
  label(data$tumor_size_mm) <-
    "Tumor size, mm"
  label(data$t_stage) <-
    "T stage"

  data
}

align_validation_levels <- function(
  development_model_data,
  validation_model_data
) {
  factor_variables <- c(
    "sex",
    "race_model",
    "site_model",
    "histology_model",
    "grade_model",
    "t_stage"
  )

  for (variable_name in factor_variables) {
    validation_model_data[[variable_name]] <- factor(
      as.character(
        validation_model_data[[variable_name]]
      ),
      levels = levels(
        development_model_data[[variable_name]]
      )
    )
  }

  if (
    any(
      sapply(
        validation_model_data[factor_variables],
        function(x) any(is.na(x))
      )
    )
  ) {
    stop(
      "Validation data contain factor levels not represented in development data."
    )
  }

  validation_model_data
}

set_datadist_global <- function(
  data,
  object_name
) {
  dd_object <- datadist(data)

  assign(
    object_name,
    dd_object,
    envir = .GlobalEnv
  )

  options(
    datadist = object_name
  )

  invisible(dd_object)
}

development_model_data <- prepare_model_data(
  development_data
)

validation_model_data <- prepare_model_data(
  validation_data
)

validation_model_data <- align_validation_levels(
  development_model_data,
  validation_model_data
)

# ------------------------------------------------------------
# PART 5. CANDIDATE MODEL COMPARISON
# ------------------------------------------------------------

set_datadist_global(
  development_model_data,
  "dd_candidates"
)

# The primary candidate set is deliberately race-free. Race is evaluated
# separately in an otherwise identical exploratory model.
model_linear <- lrm(
  lnm_num ~
    age_10 +
    site_model +
    histology_model +
    grade_model +
    tumor_size_10 +
    t_stage,
  data = development_model_data,
  x = TRUE,
  y = TRUE
)

model_full_rcs <- lrm(
  lnm_num ~
    rcs(age, 4) +
    race_model +
    site_model +
    histology_model +
    grade_model +
    rcs(tumor_size_mm, 4) +
    t_stage,
  data = development_model_data,
  x = TRUE,
  y = TRUE
)

model_final_rcs <- lrm(
  lnm_num ~
    rcs(age, 4) +
    site_model +
    histology_model +
    grade_model +
    rcs(tumor_size_mm, 4) +
    t_stage,
  data = development_model_data,
  x = TRUE,
  y = TRUE
)

get_probability <- function(
  model,
  new_data
) {
  linear_predictor <- predict(
    model,
    newdata = as.data.frame(new_data),
    type = "lp"
  )

  as.numeric(
    plogis(linear_predictor)
  )
}

calculate_calibration_metrics <- function(
  outcome,
  probability
) {
  probability <- pmin(
    pmax(
      probability,
      0.000001
    ),
    0.999999
  )

  linear_predictor <- qlogis(
    probability
  )

  intercept_model <- glm(
    outcome ~ offset(linear_predictor),
    family = binomial(link = "logit")
  )

  slope_model <- glm(
    outcome ~ linear_predictor,
    family = binomial(link = "logit")
  )

  data.frame(
    Calibration_intercept =
      unname(
        coef(intercept_model)[1]
      ),

    Calibration_slope =
      unname(
        coef(slope_model)[2]
      ),

    Brier_score =
      mean(
        (outcome - probability)^2
      )
  )
}

evaluate_model <- function(
  model,
  development_data,
  validation_data,
  model_name
) {
  development_probability <- get_probability(
    model,
    development_data
  )

  validation_probability <- get_probability(
    model,
    validation_data
  )

  development_roc <- roc(
    response = development_data$lnm_num,
    predictor = development_probability,
    quiet = TRUE
  )

  validation_roc <- roc(
    response = validation_data$lnm_num,
    predictor = validation_probability,
    quiet = TRUE
  )

  development_ci <- as.numeric(
    ci.auc(development_roc)
  )

  validation_ci <- as.numeric(
    ci.auc(validation_roc)
  )

  development_calibration <-
    calculate_calibration_metrics(
      development_data$lnm_num,
      development_probability
    )

  validation_calibration <-
    calculate_calibration_metrics(
      validation_data$lnm_num,
      validation_probability
    )

  list(
    summary = data.frame(
      Model = model_name,

      Development_AUC =
        as.numeric(
          auc(development_roc)
        ),

      Development_AUC_lower =
        development_ci[1],

      Development_AUC_upper =
        development_ci[3],

      Development_Brier =
        development_calibration$Brier_score,

      Development_calibration_intercept =
        development_calibration$Calibration_intercept,

      Development_calibration_slope =
        development_calibration$Calibration_slope,

      Validation_AUC =
        as.numeric(
          auc(validation_roc)
        ),

      Validation_AUC_lower =
        validation_ci[1],

      Validation_AUC_upper =
        validation_ci[3],

      Validation_Brier =
        validation_calibration$Brier_score,

      Validation_calibration_intercept =
        validation_calibration$Calibration_intercept,

      Validation_calibration_slope =
        validation_calibration$Calibration_slope
    ),

    development_probability =
      development_probability,

    validation_probability =
      validation_probability,

    development_roc =
      development_roc,

    validation_roc =
      validation_roc
  )
}

linear_evaluation <- evaluate_model(
  model_linear,
  development_model_data,
  validation_model_data,
  "Race-free linear model"
)

full_rcs_evaluation <- evaluate_model(
  model_full_rcs,
  development_model_data,
  validation_model_data,
  "Race-inclusive RCS model (exploratory)"
)

final_rcs_evaluation <- evaluate_model(
  model_final_rcs,
  development_model_data,
  validation_model_data,
  "Race-free RCS model (primary)"
)

candidate_model_performance <- bind_rows(
  linear_evaluation$summary,
  full_rcs_evaluation$summary,
  final_rcs_evaluation$summary
) %>%
  mutate(
    across(
      where(is.numeric),
      ~ round(.x, 3)
    )
  )

delong_comparison <- data.frame(
  Comparison = c(
    "Race-free linear vs race-inclusive RCS",
    "Race-free linear vs race-free RCS",
    "Race-inclusive RCS vs race-free RCS"
  ),

  P_value = c(
    roc.test(
      linear_evaluation$validation_roc,
      full_rcs_evaluation$validation_roc,
      paired = TRUE,
      method = "delong"
    )$p.value,

    roc.test(
      linear_evaluation$validation_roc,
      final_rcs_evaluation$validation_roc,
      paired = TRUE,
      method = "delong"
    )$p.value,

    roc.test(
      full_rcs_evaluation$validation_roc,
      final_rcs_evaluation$validation_roc,
      paired = TRUE,
      method = "delong"
    )$p.value
  )
) %>%
  mutate(
    P_value = signif(
      P_value,
      4
    )
  )

race_removal_test <- data.frame(
  Race_inclusive_validation_AUC =
    as.numeric(auc(full_rcs_evaluation$validation_roc)),
  Race_free_validation_AUC =
    as.numeric(auc(final_rcs_evaluation$validation_roc)),
  Delta_AUC_race_free_minus_inclusive =
    as.numeric(auc(final_rcs_evaluation$validation_roc)) -
      as.numeric(auc(full_rcs_evaluation$validation_roc)),
  Race_inclusive_validation_Brier =
    full_rcs_evaluation$summary$Validation_Brier,
  Race_free_validation_Brier =
    final_rcs_evaluation$summary$Validation_Brier,
  Race_inclusive_calibration_intercept =
    full_rcs_evaluation$summary$Validation_calibration_intercept,
  Race_free_calibration_intercept =
    final_rcs_evaluation$summary$Validation_calibration_intercept,
  Race_inclusive_calibration_slope =
    full_rcs_evaluation$summary$Validation_calibration_slope,
  Race_free_calibration_slope =
    final_rcs_evaluation$summary$Validation_calibration_slope,
  DeLong_P_value = roc.test(
    full_rcs_evaluation$validation_roc,
    final_rcs_evaluation$validation_roc,
    paired = TRUE,
    method = "delong"
  )$p.value
) %>%
  mutate(
    across(
      where(is.numeric),
      ~ signif(.x, 6)
    )
  )

# Interpretable secondary linear logistic model

linear_glm <- glm(
  lnm_num ~
    age_10 +
    site_model +
    histology_model +
    grade_model +
    tumor_size_10 +
    t_stage,
  data = development_model_data,
  family = binomial(link = "logit")
)

linear_model_or <- tidy(
  linear_glm,
  exponentiate = TRUE,
  conf.int = TRUE
) %>%
  filter(
    term != "(Intercept)"
  ) %>%
  transmute(
    Term = term,
    OR = estimate,
    CI_lower = conf.low,
    CI_upper = conf.high,
    P_value = p.value
  ) %>%
  mutate(
    across(
      c(
        OR,
        CI_lower,
        CI_upper
      ),
      ~ round(.x, 3)
    ),
    P_value = signif(
      P_value,
      4
    )
  )

# Nonlinearity testing is derived from the final rms::lrm model
# in Part 6 so that the reported P values match the fitted RCS model.

# ------------------------------------------------------------
# PART 6. FINAL MODEL, BOOTSTRAP, PERFORMANCE
# ------------------------------------------------------------

set_datadist_global(
  development_model_data,
  "dd_main"
)

# Primary model used for all main-manuscript performance estimates and figures.
final_model <- lrm(
  lnm_num ~
    rcs(age, 4) +
    site_model +
    histology_model +
    grade_model +
    rcs(tumor_size_mm, 4) +
    t_stage,
  data = development_model_data,
  x = TRUE,
  y = TRUE
)

# Otherwise identical race-inclusive model retained only for exploratory
# secondary comparison. It is not used to generate the main nomogram, ROC,
# calibration, DCA, RCS curves, bootstrap validation, or sensitivity plots.
race_inclusive_model <- lrm(
  lnm_num ~
    rcs(age, 4) +
    race_model +
    site_model +
    histology_model +
    grade_model +
    rcs(tumor_size_mm, 4) +
    t_stage,
  data = development_model_data,
  x = TRUE,
  y = TRUE
)

primary_model_variables <- all.vars(
  formula(final_model)
)

race_inclusive_model_variables <- all.vars(
  formula(race_inclusive_model)
)

if ("race_model" %in% primary_model_variables) {
  stop(
    "V2.2 model-definition audit failed: race is present in the primary model."
  )
}

if (!("race_model" %in% race_inclusive_model_variables)) {
  stop(
    "V2.2 model-definition audit failed: race is absent from the exploratory race-inclusive model."
  )
}

model_definition_audit <- data.frame(
  Model = c(
    "Primary race-free RCS model",
    "Exploratory race-inclusive RCS model"
  ),
  Includes_race = c(
    "race_model" %in% primary_model_variables,
    "race_model" %in% race_inclusive_model_variables
  ),
  Variables = c(
    paste(primary_model_variables, collapse = " | "),
    paste(race_inclusive_model_variables, collapse = " | ")
  ),
  stringsAsFactors = FALSE
)

final_model_anova_matrix <- as.matrix(
  anova(final_model)
)

final_model_anova <- data.frame(
  Term = rownames(
    final_model_anova_matrix
  ),
  final_model_anova_matrix,
  row.names = NULL,
  check.names = FALSE
)

race_inclusive_anova_matrix <- as.matrix(
  anova(race_inclusive_model)
)

race_inclusive_model_anova <- data.frame(
  Term = rownames(race_inclusive_anova_matrix),
  race_inclusive_anova_matrix,
  row.names = NULL,
  check.names = FALSE
)

# Extract overall and nonlinear P values directly from the final
# restricted cubic spline model. This keeps Figure 2, the tables,
# and the final model ANOVA fully consistent.
anova_term_names <- trimws(
  rownames(final_model_anova_matrix)
)

anova_p_column <- if (
  "P" %in% colnames(final_model_anova_matrix)
) {
  "P"
} else {
  grep(
    pattern = "^P$|Pr",
    x = colnames(final_model_anova_matrix),
    value = TRUE
  )[1]
}

extract_final_anova_p <- function(
  term_name,
  nonlinear = FALSE
) {
  term_index <- which(
    anova_term_names == term_name
  )[1]

  if (is.na(term_index)) {
    return(NA_real_)
  }

  if (isTRUE(nonlinear)) {
    nonlinear_index <- term_index + 1

    if (
      nonlinear_index >
        nrow(final_model_anova_matrix) ||
      trimws(
        rownames(final_model_anova_matrix)[
          nonlinear_index
        ]
      ) != "Nonlinear"
    ) {
      return(NA_real_)
    }

    term_index <- nonlinear_index
  }

  as.numeric(
    final_model_anova_matrix[
      term_index,
      anova_p_column
    ]
  )
}

nonlinearity_results <- data.frame(
  Variable = c(
    "Age",
    "Age",
    "Tumor size",
    "Tumor size"
  ),
  Test = c(
    "Overall",
    "Nonlinear",
    "Overall",
    "Nonlinear"
  ),
  P_value = c(
    extract_final_anova_p(
      "age",
      nonlinear = FALSE
    ),
    extract_final_anova_p(
      "age",
      nonlinear = TRUE
    ),
    extract_final_anova_p(
      "tumor_size_mm",
      nonlinear = FALSE
    ),
    extract_final_anova_p(
      "tumor_size_mm",
      nonlinear = TRUE
    )
  )
) %>%
  mutate(
    P_value = signif(
      P_value,
      4
    )
  )

set.seed(20260715)

bootstrap_validation <- validate(
  final_model,
  method = "boot",
  B = bootstrap_repetitions
)

# rms::validate objects retain a matrix structure after unclassing.
# Using as.data.frame() directly may flatten the object into one column.
bootstrap_validation_matrix <- unclass(
  bootstrap_validation
)

if (!is.matrix(bootstrap_validation_matrix)) {
  bootstrap_validation_matrix <- as.matrix(
    bootstrap_validation
  )
}

if (
  is.null(
    rownames(bootstrap_validation_matrix)
  ) ||
  is.null(
    colnames(bootstrap_validation_matrix)
  )
) {
  stop(
    "Bootstrap validation output could not be converted to a labelled matrix."
  )
}

bootstrap_validation_df <- data.frame(
  Metric = rownames(
    bootstrap_validation_matrix
  ),
  bootstrap_validation_matrix,
  row.names = NULL,
  check.names = FALSE
)

bootstrap_summary_columns <- intersect(
  c(
    "index.orig",
    "training",
    "test",
    "optimism",
    "index.corrected",
    "n"
  ),
  colnames(
    bootstrap_validation_matrix
  )
)

optimism_corrected_summary <-
  bootstrap_validation_df %>%
  filter(
    Metric %in% c(
      "Dxy",
      "R2",
      "Intercept",
      "Slope",
      "Emax",
      "D",
      "U",
      "Q",
      "B",
      "g",
      "gp"
    )
  ) %>%
  select(
    Metric,
    all_of(
      bootstrap_summary_columns
    )
  )

if (
  "Dxy" %in%
    rownames(
      bootstrap_validation_matrix
    )
) {
  dxy_row <- bootstrap_validation_matrix[
    "Dxy",
    ,
    drop = FALSE
  ]

  c_statistic_row <- dxy_row

  # Convert Dxy-based indices to C-statistics.
  # For index.orig, training, test, and index.corrected:
  #   C = Dxy / 2 + 0.5
  # For optimism (a difference):
  #   optimism_C = optimism_Dxy / 2
  c_value_columns <- intersect(
    c(
      "index.orig",
      "training",
      "test",
      "index.corrected"
    ),
    colnames(c_statistic_row)
  )

  c_statistic_row[
    1,
    c_value_columns
  ] <- c_statistic_row[
    1,
    c_value_columns
  ] / 2 + 0.5

  if (
    "optimism" %in%
      colnames(c_statistic_row)
  ) {
    c_statistic_row[
      1,
      "optimism"
    ] <- c_statistic_row[
      1,
      "optimism"
    ] / 2
  }

  c_statistic_df <- data.frame(
    Metric =
      "C-statistic derived from Dxy",
    c_statistic_row,
    row.names = NULL,
    check.names = FALSE
  ) %>%
    select(
      Metric,
      all_of(
        bootstrap_summary_columns
      )
    )

  optimism_corrected_summary <-
    bind_rows(
      optimism_corrected_summary,
      c_statistic_df
    )
}

development_model_data$final_pred <-
  get_probability(
    final_model,
    development_model_data
  )

validation_model_data$final_pred <-
  get_probability(
    final_model,
    validation_model_data
  )

final_validation_roc <- roc(
  validation_model_data$lnm_num,
  validation_model_data$final_pred,
  quiet = TRUE
)

optimal_cutoff <- coords(
  final_validation_roc,
  x = "best",
  best.method = "youden",
  ret = c(
    "threshold",
    "sensitivity",
    "specificity",
    "ppv",
    "npv"
  ),
  transpose = FALSE
)

optimal_cutoff_df <- as.data.frame(
  optimal_cutoff
)

rownames(optimal_cutoff_df) <- NULL

final_development_roc <- roc(
  development_model_data$lnm_num,
  development_model_data$final_pred,
  quiet = TRUE
)

final_development_auc_ci <- as.numeric(
  ci.auc(final_development_roc)
)

final_validation_auc_ci <- as.numeric(
  ci.auc(final_validation_roc)
)

final_performance <- bind_rows(
  calculate_calibration_metrics(
    development_model_data$lnm_num,
    development_model_data$final_pred
  ) %>%
    mutate(
      Cohort = "Development cohort",
      AUC = as.numeric(
        auc(final_development_roc)
      ),
      AUC_lower = final_development_auc_ci[1],
      AUC_upper = final_development_auc_ci[3]
    ),

  calculate_calibration_metrics(
    validation_model_data$lnm_num,
    validation_model_data$final_pred
  ) %>%
    mutate(
      Cohort = "Temporal validation cohort",
      AUC = as.numeric(
        auc(final_validation_roc)
      ),
      AUC_lower = final_validation_auc_ci[1],
      AUC_upper = final_validation_auc_ci[3]
    )
) %>%
  select(
    Cohort,
    AUC,
    AUC_lower,
    AUC_upper,
    Calibration_intercept,
    Calibration_slope,
    Brier_score
  ) %>%
  mutate(
    across(
      where(is.numeric),
      ~ round(.x, 3)
    )
  )

saveRDS(
  final_model,
  file.path(
    "08_models",
    "Primary_race_free_RCS_model_tumor_size_le150.rds"
  )
)

saveRDS(
  race_inclusive_model,
  file.path(
    "08_models",
    "Exploratory_race_inclusive_RCS_model_tumor_size_le150.rds"
  )
)

saveRDS(
  development_model_data,
  file.path(
    "02_clean_data",
    "Development_data_final_predictions.rds"
  )
)

saveRDS(
  validation_model_data,
  file.path(
    "02_clean_data",
    "Validation_data_final_predictions.rds"
  )
)

# ------------------------------------------------------------
# PART 7. SENSITIVITY ANALYSES
# ------------------------------------------------------------

fit_sensitivity_model <- function(
  development_source,
  validation_source,
  model_name,
  combine_special_histology = FALSE
) {
  tryCatch(
    {
      current_development <-
        prepare_model_data(
          development_source,
          combine_special_histology =
            combine_special_histology
        )

      current_validation <-
        prepare_model_data(
          validation_source,
          combine_special_histology =
            combine_special_histology
        )

      current_validation <-
        align_validation_levels(
          current_development,
          current_validation
        )

      set_datadist_global(
        current_development,
        "dd_sensitivity"
      )

      current_model <- lrm(
        lnm_num ~
          rcs(age, 4) +
          site_model +
          histology_model +
          grade_model +
          rcs(tumor_size_mm, 4) +
          t_stage,
        data = current_development,
        x = TRUE,
        y = TRUE
      )

      current_evaluation <- evaluate_model(
        current_model,
        current_development,
        current_validation,
        model_name
      )

      current_evaluation$summary %>%
        mutate(
          Development_n =
            nrow(current_development),
          Development_events =
            sum(
              current_development$lnm_num == 1
            ),
          Validation_n =
            nrow(current_validation),
          Validation_events =
            sum(
              current_validation$lnm_num == 1
            ),
          Status = "Success",
          Message = ""
        ) %>%
        select(
          Model,
          Development_n,
          Development_events,
          everything()
        )
    },
    error = function(error_object) {
      data.frame(
        Model = model_name,
        Development_n =
          nrow(development_source),
        Development_events =
          sum(
            development_source$lnm_num == 1,
            na.rm = TRUE
          ),
        Development_AUC = NA_real_,
        Development_AUC_lower = NA_real_,
        Development_AUC_upper = NA_real_,
        Development_Brier = NA_real_,
        Development_calibration_intercept =
          NA_real_,
        Development_calibration_slope =
          NA_real_,
        Validation_n =
          nrow(validation_source),
        Validation_events =
          sum(
            validation_source$lnm_num == 1,
            na.rm = TRUE
          ),
        Validation_AUC = NA_real_,
        Validation_AUC_lower = NA_real_,
        Validation_AUC_upper = NA_real_,
        Validation_Brier = NA_real_,
        Validation_calibration_intercept =
          NA_real_,
        Validation_calibration_slope =
          NA_real_,
        Status = "Failed",
        Message = conditionMessage(
          error_object
        ),
        stringsAsFactors = FALSE
      )
    }
  )
}

pre150_split <- cohort_pre150_analysis %>%
  mutate(
    cohort = case_when(
      year_dx %in% 2018:2021 ~
        "Development",
      year_dx == 2022 ~
        "Validation",
      TRUE ~ NA_character_
    )
  )

pre150_development <- pre150_split %>%
  filter(
    cohort == "Development"
  ) %>%
  droplevels()

pre150_validation <- pre150_split %>%
  filter(
    cohort == "Validation"
  ) %>%
  droplevels()

n_stage_outcome <- function(data) {
  data %>%
    mutate(
      n_stage_clean = str_trim(
        as.character(n_stage_raw)
      ),

      lnm_num = case_when(
        n_stage_clean == "N0" ~ 0L,

        n_stage_clean %in% c(
          "N1a",
          "N1b",
          "N2a",
          "N2b"
        ) ~ 1L,

        # N1c represents tumor deposits without positive
        # regional lymph nodes and is not a valid positive
        # LNM definition. Generic N1 is excluded because its
        # nodal meaning is ambiguous in these records.
        TRUE ~ NA_integer_
      )
    ) %>%
    filter(
      !is.na(lnm_num)
    ) %>%
    select(
      -n_stage_clean
    )
}

tumor_size_q99 <- as.numeric(
  quantile(
    cohort_final$tumor_size_mm,
    probs = 0.99,
    na.rm = TRUE
  )
)

if (
  length(tumor_size_q99) != 1 ||
  !is.finite(tumor_size_q99)
) {
  stop(
    "The 99th percentile of tumor size was not calculated as a single finite value."
  )
}

sensitivity_results <- bind_rows(
  fit_sensitivity_model(
    development_data,
    validation_data,
    "Main analysis: tumor size <=150 mm"
  ),

  fit_sensitivity_model(
    development_data %>%
      filter(
        nodes_examined >= 12
      ),
    validation_data %>%
      filter(
        nodes_examined >= 12
      ),
    "At least 12 lymph nodes examined"
  ),

  fit_sensitivity_model(
    development_data %>%
      filter(
        site_group != "Overlapping/NOS"
      ) %>%
      droplevels(),
    validation_data %>%
      filter(
        site_group != "Overlapping/NOS"
      ) %>%
      droplevels(),
    "Excluding overlapping/NOS site"
  ),

  fit_sensitivity_model(
    development_data,
    validation_data,
    "Combined special histology",
    combine_special_histology = TRUE
  ),

  fit_sensitivity_model(
    n_stage_outcome(
      development_data
    ),
    n_stage_outcome(
      validation_data
    ),
    "N-stage-defined LNM"
  ),

  fit_sensitivity_model(
    pre150_development,
    pre150_validation,
    "Full cohort including tumor size >150 mm"
  ),

  fit_sensitivity_model(
    development_data %>%
      filter(
        tumor_size_mm <= tumor_size_q99
      ),
    validation_data %>%
      filter(
        tumor_size_mm <= tumor_size_q99
      ),
    paste0(
      "Tumor size <=",
      round(tumor_size_q99, 1),
      " mm"
    )
  )
) %>%
  mutate(
    across(
      where(is.numeric),
      ~ round(.x, 3)
    )
  )

# ------------------------------------------------------------
# PART 7.1. OPTIONAL CEA-ENHANCED ANALYSIS
# ------------------------------------------------------------

cea_analysis_results <- data.frame(
  Status = "Not run"
)

if (isTRUE(run_optional_cea_analysis)) {
  cea_analysis_results <- tryCatch(
    {
      cea_development <- development_data %>%
        filter(
          cea_group %in% c(
            "Negative/normal",
            "Positive/elevated"
          )
        ) %>%
        mutate(
          cea_binary = factor(
            as.character(cea_group),
            levels = c(
              "Negative/normal",
              "Positive/elevated"
            )
          )
        ) %>%
        droplevels()

      cea_validation <- validation_data %>%
        filter(
          cea_group %in% c(
            "Negative/normal",
            "Positive/elevated"
          )
        ) %>%
        mutate(
          cea_binary = factor(
            as.character(cea_group),
            levels = c(
              "Negative/normal",
              "Positive/elevated"
            )
          )
        ) %>%
        droplevels()

      cea_development_model <-
        prepare_model_data(
          cea_development
        )

      cea_validation_model <-
        prepare_model_data(
          cea_validation
        )

      cea_validation_model <-
        align_validation_levels(
          cea_development_model,
          cea_validation_model
        )

      cea_development_model$cea_binary <-
        factor(
          as.character(
            cea_development$cea_binary
          ),
          levels = c(
            "Negative/normal",
            "Positive/elevated"
          )
        )

      cea_validation_model$cea_binary <-
        factor(
          as.character(
            cea_validation$cea_binary
          ),
          levels = levels(
            cea_development_model$cea_binary
          )
        )

      set_datadist_global(
        cea_development_model,
        "dd_cea"
      )

      cea_base_model <- lrm(
        lnm_num ~
          rcs(age, 4) +
          race_model +
          site_model +
          histology_model +
          grade_model +
          rcs(tumor_size_mm, 4) +
          t_stage,
        data = cea_development_model,
        x = TRUE,
        y = TRUE
      )

      cea_enhanced_model <- lrm(
        lnm_num ~
          rcs(age, 4) +
          race_model +
          site_model +
          histology_model +
          grade_model +
          rcs(tumor_size_mm, 4) +
          t_stage +
          cea_binary,
        data = cea_development_model,
        x = TRUE,
        y = TRUE
      )

      cea_base_evaluation <- evaluate_model(
        cea_base_model,
        cea_development_model,
        cea_validation_model,
        "CEA-known subset: base model"
      )

      cea_enhanced_evaluation <- evaluate_model(
        cea_enhanced_model,
        cea_development_model,
        cea_validation_model,
        "CEA-known subset: CEA-enhanced model"
      )

      cea_delong <- roc.test(
        cea_base_evaluation$validation_roc,
        cea_enhanced_evaluation$validation_roc,
        paired = TRUE,
        method = "delong"
      )

      bind_rows(
        cea_base_evaluation$summary,
        cea_enhanced_evaluation$summary
      ) %>%
        mutate(
          Development_n =
            nrow(cea_development_model),
          Validation_n =
            nrow(cea_validation_model),
          Delong_P_value =
            cea_delong$p.value,
          Status = "Success"
        ) %>%
        mutate(
          across(
            where(is.numeric),
            ~ round(.x, 3)
          )
        )
    },
    error = function(error_object) {
      data.frame(
        Status = "Failed",
        Message = conditionMessage(
          error_object
        )
      )
    }
  )
}


# ------------------------------------------------------------
# PART 7.2. EXPLORATORY PNI ANALYSIS
# The PNI analyses use the race-inclusive complete model, as prespecified
# for exploratory secondary analyses. Unknown/not-assessed PNI is never
# combined with PNI-absent.
# ------------------------------------------------------------

pni_status_summary <- data.frame(
  Status = "Not run"
)

pni_lnm_rates <- data.frame(
  Status = "Not run"
)

pni_adjusted_or <- data.frame(
  Status = "Not run"
)

pni_incremental_performance <- data.frame(
  Status = "Not run"
)

pni_period_interaction <- data.frame(
  Status = "Not run"
)

if (isTRUE(run_pni_analysis)) {
  pni_analysis_objects <- tryCatch(
    {
      pni_status_summary_local <- seer_split %>%
        mutate(
          PNI_known = pni_group %in% c(
            "Absent",
            "Present"
          )
        ) %>%
        group_by(cohort) %>%
        summarise(
          Total_n = n(),
          PNI_known_n = sum(PNI_known),
          PNI_known_percent =
            100 * mean(PNI_known),
          PNI_present_n = sum(
            pni_group == "Present"
          ),
          PNI_present_percent_of_known =
            100 * PNI_present_n / PNI_known_n,
          .groups = "drop"
        ) %>%
        mutate(
          across(
            where(is.numeric),
            ~ round(.x, 3)
          )
        )

      pni_known_all <- seer_split %>%
        filter(
          pni_group %in% c(
            "Absent",
            "Present"
          )
        ) %>%
        mutate(
          pni_binary = factor(
            as.character(pni_group),
            levels = c(
              "Absent",
              "Present"
            )
          ),
          analysis_period = factor(
            if_else(
              year_dx == 2022,
              "Validation (2022)",
              "Development (2018-2021)"
            ),
            levels = c(
              "Development (2018-2021)",
              "Validation (2022)"
            )
          )
        ) %>%
        droplevels()

      pni_lnm_rates_local <- pni_known_all %>%
        group_by(
          cohort,
          pni_binary
        ) %>%
        summarise(
          Total_n = n(),
          LNM_n = sum(lnm_num == 1),
          LNM_percent =
            100 * mean(lnm_num == 1),
          .groups = "drop"
        ) %>%
        mutate(
          LNM_percent = round(
            LNM_percent,
            3
          )
        )

      pni_development <- pni_known_all %>%
        filter(
          analysis_period ==
            "Development (2018-2021)"
        ) %>%
        droplevels()

      pni_validation <- pni_known_all %>%
        filter(
          analysis_period ==
            "Validation (2022)"
        ) %>%
        droplevels()

      if (
        nlevels(pni_development$pni_binary) < 2 ||
        nlevels(pni_validation$pni_binary) < 2
      ) {
        stop(
          "Both PNI levels must be represented in the development and validation PNI-known subsets."
        )
      }

      pni_development_model <- prepare_model_data(
        pni_development
      )

      pni_validation_model <- prepare_model_data(
        pni_validation
      )

      pni_validation_model <- align_validation_levels(
        pni_development_model,
        pni_validation_model
      )

      pni_development_model$pni_binary <- factor(
        as.character(pni_development$pni_binary),
        levels = c(
          "Absent",
          "Present"
        )
      )

      pni_validation_model$pni_binary <- factor(
        as.character(pni_validation$pni_binary),
        levels = levels(
          pni_development_model$pni_binary
        )
      )

      set_datadist_global(
        pni_development_model,
        "dd_pni"
      )

      pni_base_model <- lrm(
        lnm_num ~
          rcs(age, 4) +
          race_model +
          site_model +
          histology_model +
          grade_model +
          rcs(tumor_size_mm, 4) +
          t_stage,
        data = pni_development_model,
        x = TRUE,
        y = TRUE
      )

      pni_enhanced_model <- lrm(
        lnm_num ~
          rcs(age, 4) +
          race_model +
          site_model +
          histology_model +
          grade_model +
          rcs(tumor_size_mm, 4) +
          t_stage +
          pni_binary,
        data = pni_development_model,
        x = TRUE,
        y = TRUE
      )

      pni_base_evaluation <- evaluate_model(
        pni_base_model,
        pni_development_model,
        pni_validation_model,
        "PNI-known subset: race-inclusive base model"
      )

      pni_enhanced_evaluation <- evaluate_model(
        pni_enhanced_model,
        pni_development_model,
        pni_validation_model,
        "PNI-known subset: race-inclusive model plus PNI"
      )

      pni_delong <- roc.test(
        pni_base_evaluation$validation_roc,
        pni_enhanced_evaluation$validation_roc,
        paired = TRUE,
        method = "delong"
      )

      pni_incremental_performance_local <- bind_rows(
        pni_base_evaluation$summary,
        pni_enhanced_evaluation$summary
      ) %>%
        mutate(
          Development_n =
            nrow(pni_development_model),
          Development_events =
            sum(pni_development_model$lnm_num == 1),
          Validation_n =
            nrow(pni_validation_model),
          Validation_events =
            sum(pni_validation_model$lnm_num == 1),
          Delta_validation_AUC =
            as.numeric(
              auc(
                pni_enhanced_evaluation$validation_roc
              )
            ) -
            as.numeric(
              auc(
                pni_base_evaluation$validation_roc
              )
            ),
          DeLong_P_value = pni_delong$p.value,
          Status = "Success"
        ) %>%
        mutate(
          across(
            where(is.numeric),
            ~ signif(.x, 6)
          )
        )

      # Adjusted association: flexible age and tumor-size terms, plus all
      # variables in the race-inclusive exploratory complete model.
      pni_association_model <- glm(
        lnm_num ~
          ns(age, df = 3) +
          race_group +
          site_group +
          histology_group +
          grade_group +
          ns(tumor_size_mm, df = 3) +
          t_stage +
          pni_binary,
        data = pni_known_all,
        family = binomial(link = "logit")
      )

      pni_adjusted_or_local <- tidy(
        pni_association_model,
        exponentiate = TRUE,
        conf.int = TRUE
      ) %>%
        filter(
          term == "pni_binaryPresent"
        ) %>%
        transmute(
          Contrast = "PNI present vs absent",
          Adjusted_OR = estimate,
          CI_lower = conf.low,
          CI_upper = conf.high,
          P_value = p.value,
          Analysis =
            "Exploratory race-inclusive complete model"
        ) %>%
        mutate(
          across(
            c(
              Adjusted_OR,
              CI_lower,
              CI_upper
            ),
            ~ round(.x, 3)
          ),
          P_value = signif(
            P_value,
            4
          )
        )

      # Period interaction tests whether the adjusted PNI association differs
      # between the 2018-2021 development period and the 2022 validation year.
      pni_interaction_model <- glm(
        lnm_num ~
          ns(age, df = 3) +
          race_group +
          site_group +
          histology_group +
          grade_group +
          ns(tumor_size_mm, df = 3) +
          t_stage +
          pni_binary * analysis_period,
        data = pni_known_all,
        family = binomial(link = "logit")
      )

      pni_period_interaction_local <- tidy(
        pni_interaction_model,
        exponentiate = TRUE,
        conf.int = TRUE
      ) %>%
        filter(
          str_detect(
            term,
            "pni_binaryPresent:analysis_period"
          )
        ) %>%
        transmute(
          Term = term,
          Interaction_OR = estimate,
          CI_lower = conf.low,
          CI_upper = conf.high,
          P_value = p.value,
          Interpretation =
            "Ratio of the PNI odds ratio in 2022 versus 2018-2021"
        ) %>%
        mutate(
          across(
            c(
              Interaction_OR,
              CI_lower,
              CI_upper
            ),
            ~ round(.x, 3)
          ),
          P_value = signif(
            P_value,
            4
          )
        )

      saveRDS(
        pni_base_model,
        file.path(
          "08_models",
          "Exploratory_PNI_known_race_inclusive_base_model.rds"
        )
      )

      saveRDS(
        pni_enhanced_model,
        file.path(
          "08_models",
          "Exploratory_PNI_enhanced_model.rds"
        )
      )

      list(
        status = pni_status_summary_local,
        rates = pni_lnm_rates_local,
        adjusted_or = pni_adjusted_or_local,
        performance = pni_incremental_performance_local,
        interaction = pni_period_interaction_local
      )
    },
    error = function(error_object) {
      list(
        error = conditionMessage(error_object)
      )
    }
  )

  if ("error" %in% names(pni_analysis_objects)) {
    failure_message <- pni_analysis_objects$error

    pni_status_summary <- data.frame(
      Status = "Failed",
      Message = failure_message
    )
    pni_lnm_rates <- pni_status_summary
    pni_adjusted_or <- pni_status_summary
    pni_incremental_performance <- pni_status_summary
    pni_period_interaction <- pni_status_summary
  } else {
    pni_status_summary <- pni_analysis_objects$status
    pni_lnm_rates <- pni_analysis_objects$rates
    pni_adjusted_or <- pni_analysis_objects$adjusted_or
    pni_incremental_performance <- pni_analysis_objects$performance
    pni_period_interaction <- pni_analysis_objects$interaction
  }
}

# ------------------------------------------------------------
# PART 8. PUBLICATION FIGURES
# ------------------------------------------------------------

options(datadist = "dd_main")

# 8.1 Figure 1: patient selection flowchart

flow_plot_data <- selection_flow %>%
  mutate(
    y = rev(
      seq_len(
        n()
      )
    ),

    label = case_when(
      step_order == 0 ~
        paste0(
          selection_step,
          "\nN = ",
          comma(remaining_n)
        ),

      TRUE ~
        paste0(
          selection_step,
          "\nN = ",
          comma(remaining_n),
          "\nExcluded = ",
          comma(excluded_n)
        )
    )
  )

flowchart_plot <- ggplot(
  flow_plot_data,
  aes(
    x = 0,
    y = y
  )
) +
  geom_label(
    aes(
      label = label
    ),
    size = 3.4,
    family = font_family,
    label.size = 0.45,
    label.padding = grid::unit(
      0.25,
      "lines"
    ),
    fill = "white",
    color = palette_main["charcoal"]
  ) +
  geom_segment(
    data = flow_plot_data %>%
      filter(
        step_order <
          max(step_order)
      ),
    aes(
      x = 0,
      xend = 0,
      y = y - 0.35,
      yend = y - 0.65
    ),
    inherit.aes = FALSE,
    arrow = grid::arrow(
      length = grid::unit(
        0.14,
        "inches"
      )
    ),
    linewidth = 0.65,
    color = palette_main["navy"]
  ) +
  xlim(
    -1,
    1
  ) +
  ylim(
    0.5,
    max(flow_plot_data$y) + 0.5
  ) +
  coord_cartesian(
    clip = "off"
  ) +
  theme_void(
    base_family = font_family
  ) +
  theme(
    plot.margin = margin(
      10,
      30,
      10,
      30
    )
  )

flow_stub <- file.path(
  "04_figures_all",
  "Figure1_patient_selection_flowchart"
)

save_ggplot_all_formats(
  flowchart_plot,
  flow_stub,
  width = 8,
  height = 12
)

# 8.2 Figure 2: RCS curves

age_predict <- as.data.frame(
  Predict(
    final_model,
    age,
    fun = plogis,
    conf.int = 0.95
  )
)

size_predict <- as.data.frame(
  Predict(
    final_model,
    tumor_size_mm,
    fun = plogis,
    conf.int = 0.95
  )
)

age_overall_p <- nonlinearity_results %>%
  filter(
    Variable == "Age",
    Test == "Overall"
  ) %>%
  pull(P_value)

age_nonlinear_p <- nonlinearity_results %>%
  filter(
    Variable == "Age",
    Test == "Nonlinear"
  ) %>%
  pull(P_value)

size_overall_p <- nonlinearity_results %>%
  filter(
    Variable == "Tumor size",
    Test == "Overall"
  ) %>%
  pull(P_value)

size_nonlinear_p <- nonlinearity_results %>%
  filter(
    Variable == "Tumor size",
    Test == "Nonlinear"
  ) %>%
  pull(P_value)

format_p_value <- function(x) {
  ifelse(
    is.na(x),
    "NA",
    ifelse(
      x < 0.001,
      "<0.001",
      sprintf(
        "%.3f",
        x
      )
    )
  )
}

age_rcs_plot <- ggplot(
  age_predict,
  aes(
    x = age,
    y = yhat
  )
) +
  geom_ribbon(
    aes(
      ymin = lower,
      ymax = upper
    ),
    fill = palette_main["light_blue"],
    alpha = 0.8
  ) +
  geom_line(
    color = palette_main["navy"],
    linewidth = 1.15
  ) +
  annotate(
    "text",
    x = Inf,
    y = Inf,
    label = paste0(
      "P-overall ",
      format_p_value(
        age_overall_p
      ),
      "\nP-nonlinear ",
      format_p_value(
        age_nonlinear_p
      )
    ),
    hjust = 1.05,
    vjust = 1.25,
    family = font_family,
    size = 3.8
  ) +
  labs(
    x = "Age at diagnosis, years",
    y = "Adjusted predicted probability",
    title = "Age"
  ) +
  theme_publication(
    base_size = 12
  )

size_rcs_plot <- ggplot(
  size_predict,
  aes(
    x = tumor_size_mm,
    y = yhat
  )
) +
  geom_ribbon(
    aes(
      ymin = lower,
      ymax = upper
    ),
    fill = palette_main["light_blue"],
    alpha = 0.8
  ) +
  geom_line(
    color = palette_main["navy"],
    linewidth = 1.15
  ) +
  annotate(
    "text",
    x = Inf,
    y = Inf,
    label = paste0(
      "P-overall ",
      format_p_value(
        size_overall_p
      ),
      "\nP-nonlinear ",
      format_p_value(
        size_nonlinear_p
      )
    ),
    hjust = 1.05,
    vjust = 1.25,
    family = font_family,
    size = 3.8
  ) +
  labs(
    x = "Tumor size, mm",
    y = "Adjusted predicted probability",
    title = "Tumor size"
  ) +
  theme_publication(
    base_size = 12
  )

rcs_combined_plot <- (
  age_rcs_plot +
    size_rcs_plot
) +
  plot_annotation(
    tag_levels = "A"
  )

rcs_stub <- file.path(
  "04_figures_all",
  "Figure2_RCS_age_and_tumor_size"
)

save_ggplot_all_formats(
  rcs_combined_plot,
  rcs_stub,
  width = 13,
  height = 5.5
)

# 8.3 Figure 3: nomogram
# The display model uses shortened factor labels but the same
# observations, reference groups, spline specification, and
# numerical predictions as the final model.

nomogram_development_data <-
  development_model_data %>%
  mutate(
    site_nomogram = factor(
      case_when(
        as.character(site_model) ==
          "Right-sided colon" ~
          "Right-sided",
        as.character(site_model) ==
          "Left-sided colon" ~
          "Left-sided",
        TRUE ~ "Overlapping/NOS"
      ),
      levels = c(
        "Right-sided",
        "Left-sided",
        "Overlapping/NOS"
      )
    ),

    histology_nomogram = factor(
      case_when(
        as.character(histology_model) ==
          "Adenocarcinoma" ~
          "Adenocarcinoma",
        as.character(histology_model) ==
          "Mucinous adenocarcinoma" ~
          "Mucinous",
        TRUE ~ "Signet-ring"
      ),
      levels = c(
        "Adenocarcinoma",
        "Mucinous",
        "Signet-ring"
      )
    ),

    grade_nomogram = factor(
      case_when(
        as.character(grade_model) ==
          "Well/moderately differentiated" ~
          "Well/moderate",
        TRUE ~ "Poor/undifferentiated"
      ),
      levels = c(
        "Well/moderate",
        "Poor/undifferentiated"
      )
    )
  )

label(nomogram_development_data$age) <-
  "Age at diagnosis, years"
label(nomogram_development_data$site_nomogram) <-
  "Tumor site"
label(nomogram_development_data$histology_nomogram) <-
  "Histology"
label(nomogram_development_data$grade_nomogram) <-
  "Pathological grade"
label(nomogram_development_data$tumor_size_mm) <-
  "Tumor size, mm"
label(nomogram_development_data$t_stage) <-
  "T stage"

set_datadist_global(
  nomogram_development_data,
  "dd_nomogram"
)

nomogram_model <- lrm(
  lnm_num ~
    rcs(age, 4) +
    site_nomogram +
    histology_nomogram +
    grade_nomogram +
    rcs(tumor_size_mm, 4) +
    t_stage,
  data = nomogram_development_data,
  x = TRUE,
  y = TRUE
)

nomogram_prediction_difference <- max(
  abs(
    get_probability(
      final_model,
      development_model_data
    ) -
      get_probability(
        nomogram_model,
        nomogram_development_data
      )
  )
)

if (
  !is.finite(
    nomogram_prediction_difference
  ) ||
  nomogram_prediction_difference > 0.00000001
) {
  stop(
    "The shortened-label nomogram model is not numerically equivalent to the final model."
  )
}

nomogram_object <- nomogram(
  nomogram_model,
  age = c(
    18,
    30,
    40,
    50,
    60,
    70,
    80,
    90
  ),
  tumor_size_mm = c(
    1,
    20,
    40,
    60,
    80,
    100,
    120,
    140,
    150
  ),
  fun = plogis,
  fun.at = c(
    0.05,
    0.10,
    0.15,
    0.20,
    0.30,
    0.40,
    0.50
  ),
  funlabel =
    "Predicted probability of LNM",
  lp = FALSE
)

nomogram_pdf <- file.path(
  "04_figures_all",
  "Figure3_nomogram.pdf"
)

pdf(
  nomogram_pdf,
  width = 12,
  height = 8,
  family = font_family,
  bg = "white"
)

plot(
  nomogram_object,
  xfrac = 0.32,
  cex.axis = 0.75,
  cex.var = 0.88,
  lmgp = 0.25,
  col.grid = gray(0.90)
)

dev.off()

nomogram_png <- file.path(
  "04_figures_all",
  "Figure3_nomogram.png"
)

png(
  nomogram_png,
  width = 4800,
  height = 3200,
  res = 450,
  bg = "white"
)

plot(
  nomogram_object,
  xfrac = 0.32,
  cex.axis = 0.75,
  cex.var = 0.88,
  lmgp = 0.25,
  col.grid = gray(0.90)
)

dev.off()

nomogram_tiff <- file.path(
  "04_figures_all",
  "Figure3_nomogram.tiff"
)

tiff(
  nomogram_tiff,
  width = 4800,
  height = 3200,
  res = 450,
  compression = "lzw",
  bg = "white"
)

plot(
  nomogram_object,
  xfrac = 0.32,
  cex.axis = 0.75,
  cex.var = 0.88,
  lmgp = 0.25,
  col.grid = gray(0.90)
)

dev.off()

saveRDS(
  nomogram_model,
  file.path(
    "08_models",
    "Primary_race_free_nomogram_display_model_short_labels.rds"
  )
)

options(datadist = "dd_main")

# 8.4 Figure 4: ROC, calibration, DCA

validation_roc <- final_validation_roc

validation_auc <- as.numeric(
  auc(validation_roc)
)

validation_auc_ci <- as.numeric(
  ci.auc(validation_roc)
)

roc_plot_data <- data.frame(
  specificity =
    validation_roc$specificities,
  sensitivity =
    validation_roc$sensitivities
) %>%
  mutate(
    one_minus_specificity =
      1 - specificity
  )

roc_plot <- ggplot(
  roc_plot_data,
  aes(
    x = one_minus_specificity,
    y = sensitivity
  )
) +
  geom_line(
    color = palette_main["navy"],
    linewidth = 1.15
  ) +
  geom_abline(
    intercept = 0,
    slope = 1,
    linetype = "dashed",
    color = palette_main["gray"],
    linewidth = 0.8
  ) +
  annotate(
    "text",
    x = 0.58,
    y = 0.17,
    label = paste0(
      "AUC = ",
      sprintf(
        "%.3f",
        validation_auc
      ),
      "\n95% CI: ",
      sprintf(
        "%.3f",
        validation_auc_ci[1]
      ),
      "-",
      sprintf(
        "%.3f",
        validation_auc_ci[3]
      )
    ),
    family = font_family,
    hjust = 0,
    size = 3.8
  ) +
  coord_equal(
    xlim = c(0, 1),
    ylim = c(0, 1)
  ) +
  labs(
    x = "1 - Specificity",
    y = "Sensitivity",
    title = "ROC curve"
  ) +
  theme_publication(
    base_size = 12
  )

build_smooth_calibration <- function(
  outcome,
  probability
) {
  calibration_data <- data.frame(
    outcome = outcome,
    probability = pmin(
      pmax(
        probability,
        0.000001
      ),
      0.999999
    )
  )

  calibration_model <- glm(
    outcome ~ ns(
      probability,
      df = 3
    ),
    data = calibration_data,
    family = binomial(link = "logit")
  )

  prediction_grid <- data.frame(
    probability = seq(
      from = max(
        0.01,
        min(
          calibration_data$probability
        )
      ),
      to = min(
        0.40,
        max(
          calibration_data$probability
        )
      ),
      length.out = 200
    )
  )

  prediction_link <- predict(
    calibration_model,
    newdata = prediction_grid,
    type = "link",
    se.fit = TRUE
  )

  smooth_curve <- prediction_grid %>%
    mutate(
      fitted = plogis(
        prediction_link$fit
      ),
      lower = plogis(
        prediction_link$fit -
          1.96 *
          prediction_link$se.fit
      ),
      upper = plogis(
        prediction_link$fit +
          1.96 *
          prediction_link$se.fit
      )
    )

  deciles <- calibration_data %>%
    mutate(
      decile = ntile(
        probability,
        10
      )
    ) %>%
    group_by(decile) %>%
    summarise(
      mean_predicted =
        mean(probability),
      observed =
        mean(outcome),
      n = n(),
      events =
        sum(outcome),
      .groups = "drop"
    )

  list(
    smooth_curve = smooth_curve,
    deciles = deciles
  )
}

validation_calibration_data <-
  build_smooth_calibration(
    validation_model_data$lnm_num,
    validation_model_data$final_pred
  )

calibration_plot <- ggplot() +
  geom_abline(
    intercept = 0,
    slope = 1,
    linetype = "dashed",
    color = palette_main["gray"],
    linewidth = 0.8
  ) +
  geom_ribbon(
    data =
      validation_calibration_data$smooth_curve,
    aes(
      x = probability,
      ymin = lower,
      ymax = upper
    ),
    fill = palette_main["light_blue"],
    alpha = 0.75
  ) +
  geom_line(
    data =
      validation_calibration_data$smooth_curve,
    aes(
      x = probability,
      y = fitted
    ),
    color = palette_main["navy"],
    linewidth = 1.1
  ) +
  geom_point(
    data =
      validation_calibration_data$deciles,
    aes(
      x = mean_predicted,
      y = observed
    ),
    shape = 21,
    fill = "white",
    color = palette_main["navy"],
    stroke = 1,
    size = 2.8
  ) +
  coord_equal(
    xlim = c(0, 0.36),
    ylim = c(0, 0.36)
  ) +
  labs(
    x = "Predicted probability",
    y = "Observed LNM rate",
    title = "Calibration curve"
  ) +
  theme_publication(
    base_size = 12
  )

calculate_dca <- function(
  outcome,
  probability,
  thresholds
) {
  sample_size <- length(
    outcome
  )

  prevalence <- mean(
    outcome
  )

  lapply(
    thresholds,
    function(threshold) {
      predicted_positive <-
        probability >= threshold

      true_positive <- sum(
        predicted_positive &
          outcome == 1
      )

      false_positive <- sum(
        predicted_positive &
          outcome == 0
      )

      model_net_benefit <-
        true_positive /
        sample_size -
        false_positive /
        sample_size *
        threshold /
        (1 - threshold)

      treat_all_net_benefit <-
        prevalence -
        (1 - prevalence) *
        threshold /
        (1 - threshold)

      data.frame(
        Threshold = threshold,
        `Prediction model` =
          model_net_benefit,
        `Treat all` =
          treat_all_net_benefit,
        `Treat none` = 0,
        check.names = FALSE
      )
    }
  ) %>%
    bind_rows()
}

dca_data <- calculate_dca(
  outcome =
    validation_model_data$lnm_num,
  probability =
    validation_model_data$final_pred,
  thresholds =
    seq(
      0.01,
      0.40,
      by = 0.01
    )
)

dca_long <- dca_data %>%
  pivot_longer(
    cols = c(
      "Prediction model",
      "Treat all",
      "Treat none"
    ),
    names_to = "Strategy",
    values_to = "Net_benefit"
  ) %>%
  mutate(
    Strategy = factor(
      Strategy,
      levels = c(
        "Prediction model",
        "Treat all",
        "Treat none"
      )
    )
  )

dca_plot <- ggplot(
  dca_long,
  aes(
    x = Threshold,
    y = Net_benefit,
    color = Strategy,
    linetype = Strategy
  )
) +
  geom_line(
    linewidth = 1.05
  ) +
  scale_color_manual(
    values = c(
      "Prediction model" =
        palette_main["navy"],
      "Treat all" =
        palette_main["vermilion"],
      "Treat none" =
        palette_main["gray"]
    )
  ) +
  scale_linetype_manual(
    values = c(
      "Prediction model" = "solid",
      "Treat all" = "dashed",
      "Treat none" = "dotdash"
    )
  ) +
  coord_cartesian(
    xlim = c(0.04, 0.35),
    ylim = c(-0.03, 0.12)
  ) +
  labs(
    x = "Threshold probability",
    y = "Net benefit",
    title = "Decision curve analysis"
  ) +
  theme_publication(
    base_size = 12
  )

performance_combined <- (
  roc_plot +
    calibration_plot +
    dca_plot
) +
  plot_annotation(
    tag_levels = "A"
  )

performance_stub <- file.path(
  "04_figures_all",
  "Figure4_model_performance_temporal_validation"
)

save_ggplot_all_formats(
  performance_combined,
  performance_stub,
  width = 18,
  height = 6
)

# 8.5 Supplementary forest plot of the interpretable linear model

forest_labels <- c(
  "age_10" =
    "Age, per 10 years",
  "site_modelLeft-sided colon" =
    "Left-sided colon",
  "site_modelOverlapping/NOS" =
    "Overlapping/NOS site",
  "histology_modelMucinous adenocarcinoma" =
    "Mucinous adenocarcinoma",
  "histology_modelSignet-ring cell carcinoma" =
    "Signet-ring cell carcinoma",
  "grade_modelPoorly/undifferentiated" =
    "Poor/undifferentiated grade",
  "tumor_size_10" =
    "Tumor size, per 10 mm",
  "t_stageT2" =
    "T2 stage"
)

forest_data <- linear_model_or %>%
  mutate(
    Label = if_else(
      Term %in% names(forest_labels),
      unname(
        forest_labels[Term]
      ),
      Term
    )
  ) %>%
  arrange(
    OR
  ) %>%
  mutate(
    Label = factor(
      Label,
      levels = Label
    )
  )

linear_forest_plot <- ggplot(
  forest_data,
  aes(
    x = OR,
    y = Label
  )
) +
  geom_vline(
    xintercept = 1,
    linetype = "dashed",
    color = palette_main["gray"]
  ) +
  geom_segment(
    aes(
      x = CI_lower,
      xend = CI_upper,
      y = Label,
      yend = Label
    ),
    color = palette_main["navy"],
    linewidth = 0.7
  ) +
  geom_point(
    color = palette_main["vermilion"],
    size = 2.4
  ) +
  scale_x_log10() +
  labs(
    x = "Odds ratio (log scale)",
    y = NULL,
    title = "Adjusted associations in the race-free linear model"
  ) +
  theme_publication(
    base_size = 11
  )

forest_stub <- file.path(
  "04_figures_all",
  "Supplementary_Figure_S1_linear_model_forest"
)

save_ggplot_all_formats(
  linear_forest_plot,
  forest_stub,
  width = 8,
  height = 7
)

# 8.6 Supplementary sensitivity AUC forest plot

sensitivity_auc_data <- sensitivity_results %>%
  filter(
    Status == "Success"
  ) %>%
  mutate(
    Model = factor(
      Model,
      levels = rev(
        unique(Model)
      )
    )
  )

sensitivity_auc_plot <- ggplot(
  sensitivity_auc_data,
  aes(
    x = Validation_AUC,
    y = Model
  )
) +
  geom_segment(
    aes(
      x = Validation_AUC_lower,
      xend = Validation_AUC_upper,
      y = Model,
      yend = Model
    ),
    color = palette_main["navy"],
    linewidth = 0.75
  ) +
  geom_point(
    color = palette_main["vermilion"],
    size = 2.6
  ) +
  geom_vline(
    xintercept =
      sensitivity_auc_data$Validation_AUC[
        sensitivity_auc_data$Model ==
          "Main analysis: tumor size <=150 mm"
      ][1],
    linetype = "dashed",
    color = palette_main["gray"]
  ) +
  coord_cartesian(
    xlim = c(0.60, 0.70)
  ) +
  labs(
    x = "AUC in the temporal validation cohort",
    y = NULL,
    title = "Sensitivity analyses"
  ) +
  theme_publication(
    base_size = 11
  )

sensitivity_stub <- file.path(
  "04_figures_all",
  "Supplementary_Figure_S2_sensitivity_AUC"
)

save_ggplot_all_formats(
  sensitivity_auc_plot,
  sensitivity_stub,
  width = 9,
  height = 6
)

# 8.7 Supplementary bootstrap calibration in development cohort

set_datadist_global(
  development_model_data,
  "dd_main"
)

bootstrap_calibration <- calibrate(
  final_model,
  method = "boot",
  B = bootstrap_repetitions
)

bootstrap_calibration_pdf <- file.path(
  "04_figures_all",
  "Supplementary_Figure_S3_bootstrap_calibration.pdf"
)

pdf(
  bootstrap_calibration_pdf,
  width = 7,
  height = 6,
  family = font_family
)

plot(
  bootstrap_calibration,
  xlab = "Predicted probability",
  ylab = "Observed probability",
  subtitles = FALSE,
  col = palette_main["navy"],
  lwd = 2
)

abline(
  0,
  1,
  lty = 2,
  col = palette_main["gray"]
)

dev.off()

bootstrap_calibration_png <- file.path(
  "04_figures_all",
  "Supplementary_Figure_S3_bootstrap_calibration.png"
)

png(
  bootstrap_calibration_png,
  width = 3000,
  height = 2600,
  res = 450,
  bg = "white"
)

plot(
  bootstrap_calibration,
  xlab = "Predicted probability",
  ylab = "Observed probability",
  subtitles = FALSE,
  col = palette_main["navy"],
  lwd = 2
)

abline(
  0,
  1,
  lty = 2,
  col = palette_main["gray"]
)

dev.off()

bootstrap_calibration_tiff <- file.path(
  "04_figures_all",
  "Supplementary_Figure_S3_bootstrap_calibration.tiff"
)

tiff(
  bootstrap_calibration_tiff,
  width = 3000,
  height = 2600,
  res = 450,
  compression = "lzw",
  bg = "white"
)

plot(
  bootstrap_calibration,
  xlab = "Predicted probability",
  ylab = "Observed probability",
  subtitles = FALSE,
  col = palette_main["navy"],
  lwd = 2
)

abline(
  0,
  1,
  lty = 2,
  col = palette_main["gray"]
)

dev.off()

# ------------------------------------------------------------
# PART 9. FIGURE ORGANIZATION
# ------------------------------------------------------------

copy_figure_set(
  source_stub = flow_stub,
  destination_directory =
    "05_manuscript_figures",
  destination_base =
    "Figure_1_Patient_selection"
)

copy_figure_set(
  source_stub = rcs_stub,
  destination_directory =
    "05_manuscript_figures",
  destination_base =
    "Figure_2_RCS_associations"
)

copy_figure_set(
  source_stub = file.path(
    "04_figures_all",
    "Figure3_nomogram"
  ),
  destination_directory =
    "05_manuscript_figures",
  destination_base =
    "Figure_3_Nomogram"
)

copy_figure_set(
  source_stub = performance_stub,
  destination_directory =
    "05_manuscript_figures",
  destination_base =
    "Figure_4_Model_performance"
)

copy_figure_set(
  source_stub = forest_stub,
  destination_directory =
    "06_supplementary_figures",
  destination_base =
    "Supplementary_Figure_S1_Linear_model_forest"
)

copy_figure_set(
  source_stub = sensitivity_stub,
  destination_directory =
    "06_supplementary_figures",
  destination_base =
    "Supplementary_Figure_S2_Sensitivity_AUC"
)

copy_figure_set(
  source_stub = file.path(
    "04_figures_all",
    "Supplementary_Figure_S3_bootstrap_calibration"
  ),
  destination_directory =
    "06_supplementary_figures",
  destination_base =
    "Supplementary_Figure_S3_Bootstrap_calibration"
)

figure_manifest <- data.frame(
  Figure = c(
    "Figure 1",
    "Figure 2",
    "Figure 3",
    "Figure 4",
    "Supplementary Figure S1",
    "Supplementary Figure S2",
    "Supplementary Figure S3"
  ),

  Content = c(
    "Patient selection flowchart",
    "RCS curves for age and tumor size",
    "Primary race-free nomogram",
    "ROC, calibration, and DCA in temporal validation",
    "Adjusted OR forest plot from race-free linear secondary model",
    "Sensitivity-analysis AUC forest plot",
    "Bootstrap calibration in development cohort"
  ),

  Recommended_location = c(
    "Main manuscript",
    "Main manuscript",
    "Main manuscript",
    "Main manuscript",
    "Supplementary material",
    "Supplementary material",
    "Supplementary material"
  ),

  Folder = c(
    rep(
      "05_manuscript_figures",
      4
    ),
    rep(
      "06_supplementary_figures",
      3
    )
  )
)

write.xlsx(
  figure_manifest,
  file = file.path(
    "07_logs",
    "Figure_manifest.xlsx"
  ),
  overwrite = TRUE
)

# ------------------------------------------------------------
# PART 10. FINAL TABLE EXPORTS
# ------------------------------------------------------------

write.xlsx(
  list(
    Candidate_model_performance =
      candidate_model_performance,

    Delong_comparison =
      delong_comparison,

    Race_removal_test =
      race_removal_test,

    Model_definition_audit =
      model_definition_audit,

    Nonlinearity_tests =
      nonlinearity_results,

    Linear_model_OR =
      linear_model_or,

    Primary_race_free_model_ANOVA =
      final_model_anova,

    Exploratory_race_model_ANOVA =
      race_inclusive_model_anova,

    Bootstrap_validation =
      bootstrap_validation_df,

    Optimism_corrected_summary =
      optimism_corrected_summary,

    Final_performance =
      final_performance,

    Optimal_cutoff =
      optimal_cutoff_df
  ),
  file = file.path(
    "03_tables",
    "02_model_development_and_validation_final.xlsx"
  ),
  overwrite = TRUE
)
# ------------------------------------------------------------
# Export sensitivity and secondary analyses
# ------------------------------------------------------------

# 1. Sensitivity analysis results
if (exists("sensitivity_summary")) {
  
  sensitivity_export <- sensitivity_summary
  
} else if (exists("sensitivity_results")) {
  
  if (is.list(sensitivity_results)) {
    sensitivity_export <- dplyr::bind_rows(sensitivity_results)
  } else {
    sensitivity_export <- sensitivity_results
  }
  
} else {
  
  sensitivity_export <- data.frame(
    Note = "Sensitivity analysis results were not found."
  )
}

# 2. Optional CEA analysis
if (exists("cea_analysis_results")) {
  
  if (is.null(cea_analysis_results)) {
    
    cea_export <- data.frame(
      Note = "CEA analysis was not performed."
    )
    
  } else if (is.list(cea_analysis_results)) {
    
    cea_export <- dplyr::bind_rows(cea_analysis_results)
    
  } else {
    
    cea_export <- cea_analysis_results
  }
  
} else {
  
  cea_export <- data.frame(
    Note = "CEA analysis object was not found."
  )
}

# 3. Tumor size distribution

# 先强制整理为纯数值向量，避免 grouped data 或 factor 造成问题
tumor_size_final <- as.numeric(
  as.character(cohort_final$tumor_size_mm)
)

tumor_size_pre150 <- as.numeric(
  as.character(cohort_pre150_analysis$tumor_size_mm)
)

# 单独重新计算 99th percentile，保证它只有一个值
tumor_size_q99_scalar <- as.numeric(
  quantile(
    tumor_size_final,
    probs = 0.99,
    na.rm = TRUE
  )
)

tumor_size_export <- data.frame(
  Metric = c(
    "Minimum",
    "Median",
    "95th percentile",
    "99th percentile",
    "Maximum before 150-mm exclusion",
    "Number excluded above 150 mm"
  ),
  
  Value = c(
    min(
      tumor_size_final,
      na.rm = TRUE
    ),
    
    median(
      tumor_size_final,
      na.rm = TRUE
    ),
    
    as.numeric(
      quantile(
        tumor_size_final,
        probs = 0.95,
        na.rm = TRUE
      )
    ),
    
    tumor_size_q99_scalar,
    
    max(
      tumor_size_pre150,
      na.rm = TRUE
    ),
    
    sum(
      tumor_size_pre150 > 150,
      na.rm = TRUE
    )
  )
)
# 4. Calibration deciles
if (exists("validation_calibration_data") &&
    is.list(validation_calibration_data) &&
    "deciles" %in% names(validation_calibration_data)) {
  
  calibration_deciles_export <- validation_calibration_data$deciles
  
} else {
  
  calibration_deciles_export <- data.frame(
    Note = "Validation calibration decile data were not found."
  )
}

# 5. DCA data
if (exists("dca_data")) {
  
  dca_export <- dca_data
  
} else {
  
  dca_export <- data.frame(
    Note = "DCA data were not found."
  )
}

# 6. Export sensitivity Excel file
write.xlsx(
  list(
    Sensitivity = sensitivity_export,
    PNI_status = pni_status_summary,
    PNI_LNM_rates = pni_lnm_rates,
    PNI_adjusted_OR = pni_adjusted_or,
    PNI_incremental_performance = pni_incremental_performance,
    PNI_period_interaction = pni_period_interaction,
    CEA_analysis = cea_export,
    Tumor_size = tumor_size_export,
    Calib_deciles = calibration_deciles_export,
    DCA = dca_export
  ),
  file = file.path(
    "03_tables",
    "03_sensitivity_and_secondary_analyses_final.xlsx"
  ),
  overwrite = TRUE
)
# ------------------------------------------------------------
# PART 11. SESSION LOG AND COMPLETION
# ------------------------------------------------------------

capture.output(
  sessionInfo(),
  file = file.path(
    "07_logs",
    "R_sessionInfo.txt"
  )
)

pipeline_summary <- data.frame(
  Item = c(
    "Analysis version",
    "Primary model",
    "Final cohort size",
    "Development cohort size",
    "Validation cohort size",
    "Final LNM events",
    "Primary race-free validation AUC",
    "Race-inclusive validation AUC",
    "Delta AUC: race-free minus race-inclusive",
    "DeLong P: race-inclusive vs race-free",
    "Primary validation calibration intercept",
    "Primary validation calibration slope",
    "Primary validation Brier score",
    "Tumor size >150 mm excluded",
    "Bootstrap repetitions",
    "Primary optimism-corrected C-statistic"
  ),

  Value = c(
    analysis_version,
    "Race-free RCS logistic model",
    nrow(cohort_final),
    nrow(development_data),
    nrow(validation_data),
    sum(cohort_final$lnm_num == 1),
    round(
      as.numeric(auc(final_validation_roc)),
      3
    ),
    round(
      as.numeric(
        auc(full_rcs_evaluation$validation_roc)
      ),
      3
    ),
    round(
      as.numeric(auc(final_validation_roc)) -
        as.numeric(
          auc(full_rcs_evaluation$validation_roc)
        ),
      4
    ),
    signif(
      race_removal_test$DeLong_P_value[1],
      4
    ),
    round(
      calculate_calibration_metrics(
        validation_model_data$lnm_num,
        validation_model_data$final_pred
      )$Calibration_intercept,
      3
    ),
    round(
      calculate_calibration_metrics(
        validation_model_data$lnm_num,
        validation_model_data$final_pred
      )$Calibration_slope,
      3
    ),
    round(
      calculate_calibration_metrics(
        validation_model_data$lnm_num,
        validation_model_data$final_pred
      )$Brier_score,
      3
    ),
    sum(
      cohort_pre150_analysis$tumor_size_mm >
        150
    ),
    bootstrap_repetitions,
    if (
      "C-statistic derived from Dxy" %in%
        optimism_corrected_summary$Metric &&
      "index.corrected" %in%
        names(optimism_corrected_summary)
    ) {
      round(
        optimism_corrected_summary[
          optimism_corrected_summary$Metric ==
            "C-statistic derived from Dxy",
          "index.corrected"
        ][1],
        3
      )
    } else {
      NA_real_
    }
  ),
  stringsAsFactors = FALSE
)
write.xlsx(
  pipeline_summary,
  file = file.path(
    "07_logs",
    "Final_pipeline_summary.xlsx"
  ),
  overwrite = TRUE
)

analysis_notes <- c(
  paste0("Analysis version: ", analysis_version),
  "Primary model: race-free RCS logistic regression.",
  "Primary predictors: age, tumor site, histology, pathological grade, tumor size, and T stage.",
  "Age and tumor size use four-knot restricted cubic splines.",
  "Race-inclusive model: exploratory secondary comparison only.",
  "All main figures, primary performance estimates, bootstrap validation, and sensitivity analyses use the race-free model.",
  "PNI analysis: exploratory secondary analysis based on the race-inclusive complete model in the PNI-known subset.",
  "Unknown/not-assessed PNI is not combined with PNI absent.",
  paste0("Raw input: ", raw_csv_path),
  paste0("Output root: ", output_root)
)

writeLines(
  analysis_notes,
  con = file.path(
    "07_logs",
    "V2_2_analysis_notes.txt"
  )
)

cat(
  "\n====================================================\n",
  "MASTER PIPELINE V2.2 COMPLETED\n",
  "Final cohort: ",
  nrow(cohort_final),
  "\nDevelopment cohort: ",
  nrow(development_data),
  "\nTemporal validation cohort: ",
  nrow(validation_data),
  "\nMain manuscript figures: ",
  file.path(
    output_root,
    "05_manuscript_figures"
  ),
  "\nSupplementary figures: ",
  file.path(
    output_root,
    "06_supplementary_figures"
  ),
  "\nFinal tables: ",
  file.path(
    output_root,
    "03_tables"
  ),
  "\n====================================================\n",
  sep = ""
)
